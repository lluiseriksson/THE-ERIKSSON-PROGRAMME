from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile

def build_from_pin(pin, source_dir, title, hashes):
    os.environ.update(TZ="UTC", LC_ALL="C", FORCE_SOURCE_DATE="1", GIT_TERMINAL_PROMPT="0", DEBIAN_FRONTEND="noninteractive")
    root = Path(tempfile.mkdtemp(dir="/content", prefix="programme-pdf-"))
    evidence = root / "evidence"
    evidence.mkdir()
    def run(*cmd, cwd=root, filename=None):
        with (evidence/(filename or "setup.log")).open("ab") as log:
            subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=600)
    def digest(data):
        return hashlib.sha256(data).hexdigest()
    def out(*cmd, cwd=root):
        return subprocess.check_output(cmd, cwd=cwd, timeout=180)
    report = dict(source_sha=pin, inputs=hashes, started_at=datetime.now(timezone.utc).isoformat())
    dest = Path("/content/programme-pdf-proof.zip")
    if dest.exists():
        raise RuntimeError("Existing archive must be reconciled before another run")
    try:
        if not (shutil.which("pdflatex") and shutil.which("pdftoppm") and shutil.which("kpsewhich") and subprocess.run(["kpsewhich","lmodern.sty"],capture_output=True).returncode==0):
            import platform
            distro=platform.freedesktop_os_release()
            suite=distro.get("VERSION_CODENAME","")
            if distro.get("ID")!="ubuntu" or not re.fullmatch("[a-z]+",suite):
                raise RuntimeError("Unknown package source; retain exact source and defer")
            source=root/"ubuntu.list"
            source.write_text("".join("deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://archive.ubuntu.com/ubuntu "+release+" main universe\n" for release in (suite,suite+"-updates",suite+"-security")))
            opts=["-o","Dir::Etc::sourcelist="+str(source),"-o","Dir::Etc::sourceparts=-","-o","Acquire::ForceIPv4=true","-o","Acquire::Retries=1","-o","Acquire::https::Timeout=15"]
            run("apt-get",*opts,"update","-qq")
            run("apt-get",*opts,"install","-y","--no-install-recommends","texlive-latex-recommended","lmodern","poppler-utils")
        pdfs=[]
        for label in ("a","b"):
            clone=root/("clone-"+label)
            run("git","init","-q",str(clone))
            run("git","remote","add","origin","https://github.com/lluiseriksson/THE-ERIKSSON-PROGRAMME.git",cwd=clone)
            run("git","-c","protocol.version=2","fetch","-q","--depth=1","--filter=blob:none","origin",pin,cwd=clone)
            if out("git","rev-parse","FETCH_HEAD",cwd=clone).decode().strip()!=pin:
                raise ValueError("Fetched source commit differs")
            run("git","checkout","FETCH_HEAD","--",source_dir,cwd=clone)
            build=clone/"build"
            build.mkdir()
            for name, expected in hashes.items():
                raw=(clone/source_dir/name).read_bytes()
                if digest(raw)!=expected: raise ValueError(name)
                (build/name).write_bytes(raw)
            for mode, command in (("normal", ["python3"]), ("optimized", ["python3","-O"])):
                run(*command,"verify_education.py",cwd=build,filename=f"pool-{label}-{mode}.json")
                if (evidence/f"pool-{label}-{mode}.json").read_bytes()!=(evidence/"pool-a-normal.json").read_bytes():raise ValueError("Witnesses differ between executions")
            os.environ["SOURCE_DATE_EPOCH"]=out("git","show","-s","--format=%ct",pin,cwd=clone).decode().strip()
            (build/"driver.tex").write_text("\\pdfinfoomitdate=1\\relax\n\\pdftrailerid{}\n\\pdfsuppressptexinfo=15\\relax\n\\input{"+title+".tex}\n")
            for n in range(3):
                run("pdflatex","-no-shell-escape","-halt-on-error","-interaction=nonstopmode","driver.tex",cwd=build,filename=f"build-{label}-pass-{n+1}.txt")
            log=(build/"driver.log").read_bytes()
            (evidence/f"build-{label}.log").write_bytes(log)
            if re.search(rb"undefined references|Reference .*undefined|Citation .*undefined|multiply defined|Rerun to get cross-references right",log,re.I):raise ValueError("Unresolved final TeX references")
            pdfs.append((build/"driver.pdf").read_bytes())
        if pdfs[0]!=pdfs[1] or not pdfs[0].startswith(b"%PDF-"): raise ValueError("The two PDFs differ or are invalid")
        pdf=evidence/"paper.pdf";pdf.write_bytes(pdfs[0])
        (evidence/"toolchain.txt").write_bytes(out("pdflatex","--version"))
        (evidence/"pdfinfo.txt").write_bytes(out("pdfinfo",str(pdf)))
        run("pdftotext","-layout",str(pdf),str(evidence/"paper.txt"))
        pages=evidence/"pages";pages.mkdir()
        run("pdftoppm","-scale-to","1500","-jpeg","-jpegopt","quality=86",str(pdf),str(pages/"page"))
        count=int(re.search(rb"(?m)^Pages:\s+(\d+)",(evidence/"pdfinfo.txt").read_bytes()).group(1))
        if len(list(pages.glob("*.jpg")))!=count: raise ValueError("Rendered page count differs")
        report.update(status="reproduced",pages=count,pdf_sha256=[digest(x) for x in pdfs],pdf_bytes=len(pdfs[0]))
    except Exception as exc:
        report.update(status="failed",error=str(exc))
    report["finished_at"]=datetime.now(timezone.utc).isoformat()
    (evidence/"production.json").write_text(json.dumps(report,indent=2)+"\n")
    with zipfile.ZipFile(dest,"w",zipfile.ZIP_DEFLATED) as z:
        for path in sorted(evidence.rglob("*")):
            if path.is_file(): z.write(path,path.relative_to(evidence))
    print(json.dumps(report,sort_keys=True),flush=True)
    print("archive_sha256",digest(dest.read_bytes()),flush=True)

build_from_pin(*['92811b79e16dd8a1c0b438034520ef8c2626041f', 'audits/education-index-coverage', 'education', {'education.tex': 'd2c7d74368292201870199898a50f6d5452c4077dd7f7ab2dedfe792a22be02d', 'verify_education.py': '4ea891a8c241234d423f62397a99d171d37dc264240441c60ac95ed7c866f8c7', 'index.json': 'a088e464edd5c0c25a8438b39c2bdea868426fbb4d99b46cce048d53fcb5036e', 'replication.json': 'd43785d088ccbc1aff01683aee99f9cba040a65066d2ef78fcbe97a53c773047', 'certificates.json': 'efc7b0d996101ec1bb65fc4544c384ccf195aa9ce6f911f124c6a702c05a0230', 'source.json': 'f5442c7d1cccec2ec43bf2c7762cc2b1dbfee552cdba76ea5274626e6abd15a2', 'publisher-identities.json': 'e272a6f253c3dd32761c0a898aeecf069e8e1637d5a9a3e7c093e56bc334229a', 'linkage.json': 'a74398ea916a3d3a5c1d7b6f83c45e5d7ce4c6141a0e2fd632e207563806972b', 'second-register-files.json': '60ea5a5bffdda6976499b2a9ee50b0abc0688c332bb904a9bbfb28901bc4b8f6', 'second-register-protocol.md': 'fd62916e9d09fe728303576e39a88cb33cf4a85e1f9f24fa216b3a043bca544e', 're-index-verified.py': '44bff2c594506c36945927e5eef0bbd82b9499056bf944629b3495e294053f49', 'education-certify.py': 'b02c17ec200940a58426194afc9ed08cc3a779c69431aed9c17e5ed9d61619ff', 'education-reconciled.py': 'f1ea0e71a24a4224ba01a77bfb763c1be41820f8a79aae8dc4d216334d813232', 'replication-note.md': '37e2d5ad01b581cd71ccd01a03972454a6412aa8e90900d38272a370715b6cd5'}])
