from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile

def build_from_pin(pin, source_dir, title, hashes):
    os.environ.update(TZ="UTC", LC_ALL="C", FORCE_SOURCE_DATE="1", GIT_TERMINAL_PROMPT="0", DEBIAN_FRONTEND="noninteractive")
    root = Path(tempfile.mkdtemp(dir="/content", prefix="programme-pdf-"))
    evidence = root / "evidence"
    evidence.mkdir()
    def run(*cmd, cwd=root, filename=None):
        with (evidence/(filename or "setup.log")).open("ab") as log:
            subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=600)
    def digest(data):
        return hashlib.sha256(data).hexdigest()
    def out(*cmd, cwd=root):
        return subprocess.check_output(cmd, cwd=cwd, timeout=180)
    report = dict(source_sha=pin, inputs=hashes, started_at=datetime.now(timezone.utc).isoformat())
    dest = Path("/content/programme-pdf-proof.zip")
    if dest.exists():
        raise RuntimeError("Existing archive must be reconciled before another run")
    try:
        if not (shutil.which("pdflatex") and shutil.which("pdftoppm") and shutil.which("kpsewhich") and subprocess.run(["kpsewhich","lmodern.sty"],capture_output=True).returncode==0):
            import platform
            distro=platform.freedesktop_os_release()
            suite=distro.get("VERSION_CODENAME","")
            if distro.get("ID")!="ubuntu" or not re.fullmatch("[a-z]+",suite):
                raise RuntimeError("Unknown package source; retain exact source and defer")
            source=root/"ubuntu.list"
            source.write_text("".join("deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://archive.ubuntu.com/ubuntu "+release+" main universe\n" for release in (suite,suite+"-updates",suite+"-security")))
            opts=["-o","Dir::Etc::sourcelist="+str(source),"-o","Dir::Etc::sourceparts=-","-o","Acquire::ForceIPv4=true","-o","Acquire::Retries=1","-o","Acquire::https::Timeout=15"]
            run("apt-get",*opts,"update","-qq")
            run("apt-get",*opts,"install","-y","--no-install-recommends","texlive-latex-recommended","lmodern","poppler-utils")
        pdfs=[]
        for label in ("a","b"):
            clone=root/("clone-"+label)
            run("git","init","-q",str(clone))
            run("git","remote","add","origin","https://github.com/lluiseriksson/THE-ERIKSSON-PROGRAMME.git",cwd=clone)
            run("git","-c","protocol.version=2","fetch","-q","--depth=1","--filter=blob:none","origin",pin,cwd=clone)
            if out("git","rev-parse","FETCH_HEAD",cwd=clone).decode().strip()!=pin:
                raise ValueError("Fetched source commit differs")
            run("git","checkout","FETCH_HEAD","--",source_dir,cwd=clone)
            build=clone/"build"
            build.mkdir()
            for name, expected in hashes.items():
                raw=(clone/source_dir/name).read_bytes()
                if digest(raw)!=expected: raise ValueError(name)
                (build/name).write_bytes(raw)
            for mode, command in (("normal", ["python3"]), ("optimized", ["python3","-O"])):
                run(*command,"verify_carbides.py",cwd=build,filename=f"pool-{label}-{mode}.json")
                if (evidence/f"pool-{label}-{mode}.json").read_bytes()!=(evidence/"pool-a-normal.json").read_bytes():raise ValueError("Witnesses differ between executions")
            os.environ["SOURCE_DATE_EPOCH"]=out("git","show","-s","--format=%ct",pin,cwd=clone).decode().strip()
            (build/"driver.tex").write_text("\\pdfinfoomitdate=1\\relax\n\\pdftrailerid{}\n\\pdfsuppressptexinfo=15\\relax\n\\input{"+title+".tex}\n")
            for n in range(3):
                run("pdflatex","-no-shell-escape","-halt-on-error","-interaction=nonstopmode","driver.tex",cwd=build,filename=f"build-{label}-pass-{n+1}.txt")
            log=(build/"driver.log").read_bytes()
            (evidence/f"build-{label}.log").write_bytes(log)
            if re.search(rb"undefined references|Reference .*undefined|Citation .*undefined|multiply defined|Rerun to get cross-references right",log,re.I):raise ValueError("Unresolved final TeX references")
            pdfs.append((build/"driver.pdf").read_bytes())
        if pdfs[0]!=pdfs[1] or not pdfs[0].startswith(b"%PDF-"): raise ValueError("The two PDFs differ or are invalid")
        pdf=evidence/"paper.pdf";pdf.write_bytes(pdfs[0])
        (evidence/"toolchain.txt").write_bytes(out("pdflatex","--version"))
        (evidence/"pdfinfo.txt").write_bytes(out("pdfinfo",str(pdf)))
        run("pdftotext","-layout",str(pdf),str(evidence/"paper.txt"))
        pages=evidence/"pages";pages.mkdir()
        run("pdftoppm","-scale-to","1500","-jpeg","-jpegopt","quality=86",str(pdf),str(pages/"page"))
        count=int(re.search(rb"(?m)^Pages:\s+(\d+)",(evidence/"pdfinfo.txt").read_bytes()).group(1))
        if len(list(pages.glob("*.jpg")))!=count: raise ValueError("Rendered page count differs")
        report.update(status="reproduced",pages=count,pdf_sha256=[digest(x) for x in pdfs],pdf_bytes=len(pdfs[0]))
    except Exception as exc:
        report.update(status="failed",error=str(exc))
    report["finished_at"]=datetime.now(timezone.utc).isoformat()
    (evidence/"production.json").write_text(json.dumps(report,indent=2)+"\n")
    with zipfile.ZipFile(dest,"w",zipfile.ZIP_DEFLATED) as z:
        for path in sorted(evidence.rglob("*")):
            if path.is_file(): z.write(path,path.relative_to(evidence))
    print(json.dumps(report,sort_keys=True),flush=True)
    print("archive_sha256",digest(dest.read_bytes()),flush=True)

build_from_pin(*['65ed26d3312d18c84141c83433601e5286aa6380', 'audits/strict-carbide-grid', 'carbide-ranking', {'reference-carbides.py': 'ad413d20606172fad324c84c9bd1d4870156dc3c41e5068ade06c9ee5f88ceed', 'reference-errors.json': '61b6059fe69c89046dcd80b638877c0e37ced5d6ae88142ec0a798f10e182e56', 'carbide-ranking.tex': 'd7af42513fce68259fe5dc99f21ee66518f3d68da65dfda2add6caadcfff1ae5', 'verify_carbides.py': '9520becde16853b73a12ac2a91cf1a2cc4410e31d174f910272e904c9b66202d', 'read-table.py': 'b93c9cd057e3433a15fc0d126a9cc198cbbabb4d308799dbfa9ea3a98d1895bc', 'strict-carbides.py': 'ca71f636b03a8f9a1153c3d8b2610ebf80dad1fa515f574390fa3a53ddad829c', 'grid.json': 'c285d40deb66232fb6a9e43a86f11db12461f5c9b7efa762d9ead99f3c7120c8', 'strict-grid.md': '130e8c50b8b3feaba032b1066a7c6d3483644c172c75073c9f0f10e8ed8bdbb7'}])
