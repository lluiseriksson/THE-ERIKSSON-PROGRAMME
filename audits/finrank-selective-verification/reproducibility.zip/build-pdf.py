from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile

def build_from_pin(pin, source_dir, title, hashes):
    os.environ.update(TZ="UTC", LC_ALL="C", FORCE_SOURCE_DATE="1", GIT_TERMINAL_PROMPT="0", DEBIAN_FRONTEND="noninteractive")
    root = Path(tempfile.mkdtemp(dir="/content", prefix="programme-pdf-"))
    evidence = root / "evidence"
    evidence.mkdir()
    def run(*cmd, cwd=root, filename=None):
        with (evidence/(filename or "setup.log")).open("ab") as log:
            subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=600)
    def digest(data):
        return hashlib.sha256(data).hexdigest()
    def out(*cmd, cwd=root):
        return subprocess.check_output(cmd, cwd=cwd, timeout=180)
    report = dict(source_sha=pin, inputs=hashes, started_at=datetime.now(timezone.utc).isoformat())
    dest = Path("/content/programme-pdf-proof.zip")
    if dest.exists():
        raise RuntimeError("Existing archive must be reconciled before another run")
    try:
        if not (shutil.which("pdflatex") and shutil.which("pdftoppm") and shutil.which("kpsewhich") and subprocess.run(["kpsewhich","lmodern.sty"],capture_output=True).returncode==0):
            import platform
            distro=platform.freedesktop_os_release()
            suite=distro.get("VERSION_CODENAME","")
            if distro.get("ID")!="ubuntu" or not re.fullmatch("[a-z]+",suite):
                raise RuntimeError("Unknown package source; retain exact source and defer")
            source=root/"ubuntu.list"
            source.write_text("".join("deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://archive.ubuntu.com/ubuntu "+release+" main universe\n" for release in (suite,suite+"-updates",suite+"-security")))
            opts=["-o","Dir::Etc::sourcelist="+str(source),"-o","Dir::Etc::sourceparts=-","-o","Acquire::ForceIPv4=true","-o","Acquire::Retries=1","-o","Acquire::https::Timeout=15"]
            run("apt-get",*opts,"update","-qq")
            run("apt-get",*opts,"install","-y","--no-install-recommends","texlive-latex-recommended","lmodern","poppler-utils")
        pdfs=[]
        for label in ("a","b"):
            clone=root/("clone-"+label)
            run("git","init","-q",str(clone))
            run("git","remote","add","origin","https://github.com/lluiseriksson/THE-ERIKSSON-PROGRAMME.git",cwd=clone)
            run("git","-c","protocol.version=2","fetch","-q","--depth=1","--filter=blob:none","origin",pin,cwd=clone)
            if out("git","rev-parse","FETCH_HEAD",cwd=clone).decode().strip()!=pin:
                raise ValueError("Fetched source commit differs")
            run("git","checkout","FETCH_HEAD","--",source_dir,cwd=clone)
            build=clone/"build"
            build.mkdir()
            for name, expected in hashes.items():
                raw=(clone/source_dir/name).read_bytes()
                if digest(raw)!=expected: raise ValueError(name)
                (build/name).write_bytes(raw)
            for mode, command in (("normal", ["python3"]), ("optimized", ["python3","-O"])):
                run(*command,"verify_finrank.py",cwd=build,filename=f"pool-{label}-{mode}.json")
                if (evidence/f"pool-{label}-{mode}.json").read_bytes()!=(evidence/"pool-a-normal.json").read_bytes():raise ValueError("Witnesses differ between executions")
            os.environ["SOURCE_DATE_EPOCH"]=out("git","show","-s","--format=%ct",pin,cwd=clone).decode().strip()
            (build/"driver.tex").write_text("\\pdfinfoomitdate=1\\relax\n\\pdftrailerid{}\n\\pdfsuppressptexinfo=15\\relax\n\\input{"+title+".tex}\n")
            for n in range(3):
                run("pdflatex","-no-shell-escape","-halt-on-error","-interaction=nonstopmode","driver.tex",cwd=build,filename=f"build-{label}-pass-{n+1}.txt")
            log=(build/"driver.log").read_bytes()
            (evidence/f"build-{label}.log").write_bytes(log)
            if re.search(rb"undefined references|Reference .*undefined|Citation .*undefined|multiply defined|Rerun to get cross-references right",log,re.I):raise ValueError("Unresolved final TeX references")
            pdfs.append((build/"driver.pdf").read_bytes())
        if pdfs[0]!=pdfs[1] or not pdfs[0].startswith(b"%PDF-"): raise ValueError("The two PDFs differ or are invalid")
        pdf=evidence/"paper.pdf";pdf.write_bytes(pdfs[0])
        (evidence/"toolchain.txt").write_bytes(out("pdflatex","--version"))
        (evidence/"pdfinfo.txt").write_bytes(out("pdfinfo",str(pdf)))
        run("pdftotext","-layout",str(pdf),str(evidence/"paper.txt"))
        pages=evidence/"pages";pages.mkdir()
        run("pdftoppm","-scale-to","1500","-jpeg","-jpegopt","quality=86",str(pdf),str(pages/"page"))
        count=int(re.search(rb"(?m)^Pages:\s+(\d+)",(evidence/"pdfinfo.txt").read_bytes()).group(1))
        if len(list(pages.glob("*.jpg")))!=count: raise ValueError("Rendered page count differs")
        report.update(status="reproduced",pages=count,pdf_sha256=[digest(x) for x in pdfs],pdf_bytes=len(pdfs[0]))
    except Exception as exc:
        report.update(status="failed",error=str(exc))
    report["finished_at"]=datetime.now(timezone.utc).isoformat()
    (evidence/"production.json").write_text(json.dumps(report,indent=2)+"\n")
    with zipfile.ZipFile(dest,"w",zipfile.ZIP_DEFLATED) as z:
        for path in sorted(evidence.rglob("*")):
            if path.is_file(): z.write(path,path.relative_to(evidence))
    print(json.dumps(report,sort_keys=True),flush=True)
    print("archive_sha256",digest(dest.read_bytes()),flush=True)

build_from_pin(*['4a6a97fe12cf3e7b1703adc18b07ac2d2397ab4b', 'audits/finrank-selective-verification', 'finrank', {'response-geometry.py': '4fe9508e4f1477b4aaafebfc9b774cea88e7ac5adbd4328ec7d9db3817f023a0', 'response-flags.py': '398cc0a6e2d3f3844545e4a02727d19131e1eae5853548ea62a18f31522bb253', 'frame-fidelity-final.py': 'f9d149ec2c157862f1b6fd8a897d9abd16516e022d0f00f684ae4682812fd5f6', 'geometry.json': '2c87d99c42597e148e7688d4404aa15124649f5d41a7b9f97e4e81ffae03c006', 'flags.json': 'e8216f54242b82e4a22e2e3c193ae47b3747b08231ecd5357ab6eabfcbcaebd7', 'fidelity.json': 'a094891a1782566ecc9478e7c09501bc34bc117df04da36b94b98a0e7ca1a9a8', 'verify_finrank.py': 'cab052f753f737a7ee44b9e322016a5bef3261787fa3ac03bf924e3a7cf0be25', 'finrank.tex': '036c6dfcd39425a1f1a423f1987de1a5facd3ccbe4d8bc2ef385582cf6dca2ff', 'output-search.json': '2645d801537e2f758957b274d58857137c808af8b11673fc1d4ea72e381af6bc', 'selection-bounds.py': '5cb08938479b40673e5a11652970303722b97156a6614d73424d4d5773330d05', 'selection.json': 'ebc5c7239a447205fa07fe1da4704d52d720c1575d7a9fe5963626bef71a261c', 'source-reference.json': '92984809718add6996fc0d9c44ed65dbb26d51728ceb79a27c290d0353d8fa25', 'method.json': '9c11a642af044bb1a583853813632db3683f60473eca57b897881fd44c500f3d', 'panel-bounds.md': '266bc3a8001002efc6049288a88c33d3e9491fb82acad80d1748f4e2b8376017', 'common-baseline.md': '6f853bc3e77153ca173152531aac8ceae1e0392abb8a2633f97e40fd5b91361e', 'outcome-definition.md': 'ef66d51b92f219a01bc1241ad2b54b14846a3beaf13074b40440d3a41bc0c0cd'}])
