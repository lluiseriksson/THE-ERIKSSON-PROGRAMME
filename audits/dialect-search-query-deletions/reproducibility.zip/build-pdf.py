from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile

def build_from_pin(pin, source_dir, title, hashes):
    os.environ.update(TZ="UTC", LC_ALL="C", FORCE_SOURCE_DATE="1", GIT_TERMINAL_PROMPT="0", DEBIAN_FRONTEND="noninteractive")
    root = Path(tempfile.mkdtemp(dir="/content", prefix="programme-pdf-"))
    evidence = root / "evidence"
    evidence.mkdir()
    def run(*cmd, cwd=root, filename=None):
        with (evidence/(filename or "setup.log")).open("ab") as log:
            subprocess.run(cmd, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, check=True, timeout=600)
    def digest(data):
        return hashlib.sha256(data).hexdigest()
    def out(*cmd, cwd=root):
        return subprocess.check_output(cmd, cwd=cwd, timeout=180)
    report = dict(source_sha=pin, inputs=hashes, started_at=datetime.now(timezone.utc).isoformat())
    dest = Path("/content/programme-pdf-proof.zip")
    if dest.exists():
        raise RuntimeError("Existing archive must be reconciled before another run")
    try:
        if not (shutil.which("pdflatex") and shutil.which("pdftoppm") and shutil.which("kpsewhich") and subprocess.run(["kpsewhich","lmodern.sty"],capture_output=True).returncode==0):
            import platform
            distro=platform.freedesktop_os_release()
            suite=distro.get("VERSION_CODENAME","")
            if distro.get("ID")!="ubuntu" or not re.fullmatch("[a-z]+",suite):
                raise RuntimeError("Unknown package source; retain exact source and defer")
            source=root/"ubuntu.list"
            source.write_text("".join("deb [signed-by=/usr/share/keyrings/ubuntu-archive-keyring.gpg] https://archive.ubuntu.com/ubuntu "+release+" main universe\n" for release in (suite,suite+"-updates",suite+"-security")))
            opts=["-o","Dir::Etc::sourcelist="+str(source),"-o","Dir::Etc::sourceparts=-","-o","Acquire::ForceIPv4=true","-o","Acquire::Retries=1","-o","Acquire::https::Timeout=15"]
            run("apt-get",*opts,"update","-qq")
            run("apt-get",*opts,"install","-y","--no-install-recommends","texlive-latex-recommended","lmodern","poppler-utils")
        pdfs=[]
        for label in ("a","b"):
            clone=root/("clone-"+label)
            run("git","init","-q",str(clone))
            run("git","remote","add","origin","https://github.com/lluiseriksson/THE-ERIKSSON-PROGRAMME.git",cwd=clone)
            run("git","-c","protocol.version=2","fetch","-q","--depth=1","--filter=blob:none","origin",pin,cwd=clone)
            if out("git","rev-parse","FETCH_HEAD",cwd=clone).decode().strip()!=pin:
                raise ValueError("Fetched source commit differs")
            run("git","checkout","FETCH_HEAD","--",source_dir,cwd=clone)
            build=clone/"build"
            build.mkdir()
            for name, expected in hashes.items():
                raw=(clone/source_dir/name).read_bytes()
                if digest(raw)!=expected: raise ValueError(name)
                (build/name).write_bytes(raw)
            for mode, command in (("normal", ["python3"]), ("optimized", ["python3","-O"])):
                run(*command,"verify_query_bounds.py",cwd=build,filename=f"pool-{label}-{mode}.json")
                if (evidence/f"pool-{label}-{mode}.json").read_bytes()!=(evidence/"pool-a-normal.json").read_bytes():raise ValueError("Witnesses differ between executions")
            os.environ["SOURCE_DATE_EPOCH"]=out("git","show","-s","--format=%ct",pin,cwd=clone).decode().strip()
            (build/"driver.tex").write_text("\\pdfinfoomitdate=1\\relax\n\\pdftrailerid{}\n\\pdfsuppressptexinfo=15\\relax\n\\input{"+title+".tex}\n")
            for n in range(3):
                run("pdflatex","-no-shell-escape","-halt-on-error","-interaction=nonstopmode","driver.tex",cwd=build,filename=f"build-{label}-pass-{n+1}.txt")
            log=(build/"driver.log").read_bytes()
            (evidence/f"build-{label}.log").write_bytes(log)
            if re.search(rb"undefined references|Reference .*undefined|Citation .*undefined|multiply defined|Rerun to get cross-references right",log,re.I):raise ValueError("Unresolved final TeX references")
            pdfs.append((build/"driver.pdf").read_bytes())
        if pdfs[0]!=pdfs[1] or not pdfs[0].startswith(b"%PDF-"): raise ValueError("The two PDFs differ or are invalid")
        pdf=evidence/"paper.pdf";pdf.write_bytes(pdfs[0])
        (evidence/"toolchain.txt").write_bytes(out("pdflatex","--version"))
        (evidence/"pdfinfo.txt").write_bytes(out("pdfinfo",str(pdf)))
        run("pdftotext","-layout",str(pdf),str(evidence/"paper.txt"))
        pages=evidence/"pages";pages.mkdir()
        run("pdftoppm","-scale-to","1500","-jpeg","-jpegopt","quality=86",str(pdf),str(pages/"page"))
        count=int(re.search(rb"(?m)^Pages:\s+(\d+)",(evidence/"pdfinfo.txt").read_bytes()).group(1))
        if len(list(pages.glob("*.jpg")))!=count: raise ValueError("Rendered page count differs")
        report.update(status="reproduced",pages=count,pdf_sha256=[digest(x) for x in pdfs],pdf_bytes=len(pdfs[0]))
    except Exception as exc:
        report.update(status="failed",error=str(exc))
    report["finished_at"]=datetime.now(timezone.utc).isoformat()
    (evidence/"production.json").write_text(json.dumps(report,indent=2)+"\n")
    with zipfile.ZipFile(dest,"w",zipfile.ZIP_DEFLATED) as z:
        for path in sorted(evidence.rglob("*")):
            if path.is_file(): z.write(path,path.relative_to(evidence))
    print(json.dumps(report,sort_keys=True),flush=True)
    print("archive_sha256",digest(dest.read_bytes()),flush=True)

build_from_pin(*['50a79917b3ca719fa17e129dfd0cc5d9aec5786e', 'audits/dialect-search-query-deletions', 'query-deletions', {'query-deletions.tex': '504f90bc976634a9b8581c420b819756b7e085e64d0be5e25b0f4664ebed7383', 'verify_query_bounds.py': '702fd972558ce5cf3471c6b717b0402f0abbcb8a28e7329818bc466041d16941', 'source.json': '08112b05a9371c3e416ca019aa54b413d48feb064b92293dee81016cc75360c2', 'shop-frontier.py': 'dcf16cf456cbe4323dcce724d8d123286ab164762729d6b247b8da7e1ba0d010', 'shop-deletion-portable.py': 'b1b5fbcdde1bbb20edaf5f1de279c72fba7c4017fcd0e51e48e2e0a6ee2c6701', 'deletion.json': '1c0872a8e140bd64ed0cef403958a6b7f248c42bb808f8eaed05b5bf19d6cb01', 'baseline-frontier.json': '20800d732c6b6352e4a9d636da361fdd1270611054a0c9aafa07a510f445dfcd'}])
