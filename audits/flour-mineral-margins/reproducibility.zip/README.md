Follow reproduce-flour.md on a dedicated Linux Colab runtime. Read flour-margins.tex for the proof. Use build-pdf.py for the pinned two-build reproduction. See the source and SHA-256 manifests.
