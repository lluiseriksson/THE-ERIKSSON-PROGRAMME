import pathlib, subprocess, os, time, json, hashlib, tarfile, sys
root=pathlib.Path('/content/hrpoly-neumann-mixed-owner-diagnostic-v1')
out=pathlib.Path('/content/neumann-mixed-owner-hot-v3')
bins=list(pathlib.Path('/content').rglob('lean-4.29.0-rc6-linux/bin/lake'))
assert len(bins)==1, bins
os.environ['PATH']=str(bins[0].parent)+':'+os.environ['PATH']
import shutil
shutil.copyfile(root/'tmp/NeumannMixedOwnerDraftV3.lean',out/'NeumannMixedOwnerDraftV3.lean')
shutil.copyfile(root/'tmp/MixedOwnerIntegerRepro.lean',out/'MixedOwnerIntegerRepro.lean')
status='FAIL'
records=[]
try:
 for stage,cmd in [('minimal_repro',['lake','env','lean','tmp/MixedOwnerIntegerRepro.lean']),('owner_diagnostic',['lake','env','lean','tmp/NeumannMixedOwnerDraftV3.lean'])]:
  start=time.monotonic()
  p=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/(stage+'.log')).write_text(p.stdout)
  record={'stage':stage,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start}
  records.append(record)
  print(json.dumps(record),flush=True)
  print(p.stdout,flush=True)
  if p.returncode: raise RuntimeError('FIRST_ERROR='+stage)
 sys.path.insert(0,str(root/'scripts'))
 import full_green_owner_exact_axiom_gate as gate
 names={'YangMills.RG.'+n for n in ['neumannMixedOrbit_pack','neumannMixedImage_pack','neumannMixedOrbit_owner','neumannMixedImage_owner','neumannMixedImage_source_injective','neumannMixedImage_owner_eq_iff','neumannMixedCountingIndicator_image']}
 result=gate.exact_axioms(p.stdout,names)
 (out/'axioms.json').write_text(json.dumps(result,sort_keys=True))
 status='PASS'
except Exception as e:
 print(repr(e),flush=True)
finally:
 (out/'result.json').write_text(json.dumps({'status':status,'source':'bab8c90d09f7dfeaf7965ce3b0381a96bfabd19e','cold_seal':False,'records':records},sort_keys=True))
 archive=pathlib.Path(str(out)+'.tar.gz')
 with tarfile.open(archive,'w:gz') as t: t.add(out,arcname=out.name)
 print('ARCHIVE_SHA256='+hashlib.sha256(archive.read_bytes()).hexdigest(),flush=True)
 print('FINAL_STATUS='+status,flush=True)
