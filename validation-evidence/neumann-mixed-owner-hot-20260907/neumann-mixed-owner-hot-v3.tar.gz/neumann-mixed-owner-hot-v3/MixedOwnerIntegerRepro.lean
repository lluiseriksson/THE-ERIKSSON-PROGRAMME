import Mathlib.Data.Int.Basic
import Mathlib.Tactic.Omega
example (a x y : ℤ) (h : a+x=a+y) : x=y := by omega
example (a x y : ℤ) (h : a-x-1=a-y-1) : x=y := by omega
