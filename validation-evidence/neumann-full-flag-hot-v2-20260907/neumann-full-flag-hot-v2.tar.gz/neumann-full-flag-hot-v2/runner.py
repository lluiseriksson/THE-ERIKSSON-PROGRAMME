import pathlib,subprocess,os,time,json,hashlib,tarfile,sys
root=pathlib.Path('/content/hrpoly-neumann-physical-full-flag-diagnostic-v1')
out=pathlib.Path('/content/neumann-full-flag-hot-v2')
bins=list(pathlib.Path('/content/lean-4.29.0-rc6-linux').rglob('bin/lake'));assert len(bins)==1
os.environ['PATH']=str(bins[0].parent)+':'+os.environ['PATH']
sys.path.insert(0,str(root/'scripts'))
import full_green_owner_exact_axiom_gate as gate
status='FAIL'; records=[]; audits={}
try:
 for stage,cmd,names in [('repro',['lake','env','lean','tmp/NeumannFullFlagCastReproV2.lean'],{'fullFlagScaleCastRepro'}),('prerequisite',['lake','build','YangMills.RG.NeumannRectangleDirectionalMasks'],None),('draft',['lake','env','lean','tmp/NeumannPhysicalFullFlagDraftV2.lean'],{'YangMills.RG.'+n for n in ['neumannPhysicalFullFlag_iff','neumannPhysicalFullFlag_scale_test','neumannPhysicalFullFlag_scale','neumannPhysicalFullFlag_outgoing','neumannPhysicalFullFlag_incoming']})]:
  start=time.monotonic();p=subprocess.run(cmd,cwd=root,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
  (out/(stage+'.log')).write_text(p.stdout)
  rec={'stage':stage,'command':cmd,'exit':p.returncode,'seconds':time.monotonic()-start,'log_sha256':hashlib.sha256(p.stdout.encode()).hexdigest()};records.append(rec)
  print(json.dumps(rec),flush=True);print(p.stdout,flush=True)
  if p.returncode:raise RuntimeError('FIRST_ERROR='+stage)
  if names:audits[stage]=gate.exact_axioms(p.stdout,names)
 status='PASS'
except Exception as e:print(repr(e),flush=True)
finally:
 sources={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.glob('*.lean')}
 (out/'result.json').write_text(json.dumps({'status':status,'source_base':'f0c58431d20042ced9177632409e9f9bcbe79692','cold_seal':False,'records':records,'audits':audits,'source_overlays':sources},sort_keys=True))
 archive=pathlib.Path(str(out)+'.tar.gz')
 with tarfile.open(archive,'w:gz') as t:t.add(out,arcname=out.name)
 print('ARCHIVE_SHA256='+hashlib.sha256(archive.read_bytes()).hexdigest(),flush=True);print('FINAL_STATUS='+status,flush=True)
