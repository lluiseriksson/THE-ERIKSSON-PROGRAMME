"""Numerical audit for the exact type-III reduction and soft-boundary identities.

The script is deterministic and writes the crossover figure plus a JSON report.
It is not used as a substitute for the proofs.
"""

from __future__ import annotations

import json
import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from numpy.typing import NDArray
from scipy.linalg import expm
from scipy.integrate import quad


OUT = Path(__file__).resolve().parent
RNG = np.random.default_rng(20260805)


def entropy(rho: NDArray[np.complex128]) -> float:
    eigenvalues = np.linalg.eigvalsh((rho + rho.conj().T) / 2)
    eigenvalues = np.clip(eigenvalues.real, 0.0, None)
    mask = eigenvalues > 1e-15
    return float(-np.sum(eigenvalues[mask] * np.log(eigenvalues[mask])))


def random_density(dimension: int) -> NDArray[np.complex128]:
    matrix = RNG.normal(size=(dimension, dimension)) + 1j * RNG.normal(
        size=(dimension, dimension)
    )
    rho = matrix @ matrix.conj().T
    return rho / np.trace(rho)


def dissipator(jump: NDArray[np.complex128], rho: NDArray[np.complex128]):
    rate = jump.conj().T @ jump
    return jump @ rho @ jump.conj().T - (rate @ rho + rho @ rate) / 2


def evolve_with_generator(generator, rho: NDArray[np.complex128], time: float):
    dimension = rho.shape[0]
    superoperator = np.zeros(
        (dimension * dimension, dimension * dimension), dtype=np.complex128
    )
    for column in range(dimension * dimension):
        basis = np.zeros((dimension, dimension), dtype=np.complex128)
        row_index, column_index = np.unravel_index(column, basis.shape, order="F")
        basis[row_index, column_index] = 1.0
        superoperator[:, column] = generator(basis).reshape(-1, order="F")
    evolved = expm(time * superoperator) @ rho.reshape(-1, order="F")
    return evolved.reshape(rho.shape, order="F")


def superoperator_from_map(linear_map, dimension: int) -> NDArray[np.complex128]:
    superoperator = np.zeros(
        (dimension * dimension, dimension * dimension), dtype=np.complex128
    )
    for column in range(dimension * dimension):
        basis = np.zeros((dimension, dimension), dtype=np.complex128)
        row_index, column_index = np.unravel_index(column, basis.shape, order="F")
        basis[row_index, column_index] = 1.0
        superoperator[:, column] = linear_map(basis).reshape(-1, order="F")
    return superoperator


def random_gkls_audit(trials: int = 40) -> dict[str, float | int]:
    max_identity_error = 0.0
    max_slope_identity_error = 0.0
    max_finite_difference_relative_error = 0.0
    min_leakage = float("inf")

    for _ in range(trials):
        rho_p = random_density(2)
        tau_q = random_density(2)
        rho = np.zeros((4, 4), dtype=np.complex128)
        tau = np.zeros((4, 4), dtype=np.complex128)
        rho[:2, :2] = rho_p
        tau[2:, 2:] = tau_q

        jump = RNG.normal(size=(4, 4)) + 1j * RNG.normal(size=(4, 4))
        hamiltonian = RNG.normal(size=(4, 4)) + 1j * RNG.normal(size=(4, 4))
        hamiltonian = (hamiltonian + hamiltonian.conj().T) / 2

        def generator(state: NDArray[np.complex128]):
            return -1j * (hamiltonian @ state - state @ hamiltonian) + dissipator(
                jump, state
            )

        x0 = generator(rho)
        a = float(np.trace(x0[2:, 2:]).real)
        crossing = jump[2:, :2] @ np.linalg.cholesky(rho_p)
        a_squares = float(np.linalg.norm(crossing, "fro") ** 2)
        min_leakage = min(min_leakage, a)
        max_identity_error = max(max_identity_error, abs(a - a_squares))

        epsilon = 10.0 ** RNG.uniform(-5.0, -2.0)
        softened = (1 - epsilon) * rho + epsilon * tau
        x = generator(softened)
        b = float(np.trace(x[2:, 2:]).real)
        def matrix_log(matrix: NDArray[np.complex128]):
            values, vectors = np.linalg.eigh(matrix)
            return (vectors * np.log(values)) @ vectors.conj().T

        analytic = (
            b * np.log((1 - epsilon) / epsilon)
            - np.trace(x[:2, :2] @ matrix_log(rho_p)).real
            - np.trace(x[2:, 2:] @ matrix_log(tau_q)).real
        )

        direct = -np.trace(x @ matrix_log(softened)).real
        max_slope_identity_error = max(max_slope_identity_error, abs(analytic - direct))

        dt = epsilon * 1e-5
        slope_dt = (
            entropy(evolve_with_generator(generator, softened, dt)) - entropy(softened)
        ) / dt
        slope_half = (
            entropy(evolve_with_generator(generator, softened, dt / 2))
            - entropy(softened)
        ) / (dt / 2)
        numerical = 2 * slope_half - slope_dt
        relative_error = abs(analytic - numerical) / max(1.0, abs(analytic))
        max_finite_difference_relative_error = max(
            max_finite_difference_relative_error, relative_error
        )

    return {
        "trials": trials,
        "minimum_leakage_coefficient": min_leakage,
        "max_gkls_square_sum_identity_error": max_identity_error,
        "max_softened_slope_identity_error": max_slope_identity_error,
        "max_finite_difference_relative_error": max_finite_difference_relative_error,
    }


def relative_entropy(rho: NDArray[np.complex128], sigma: NDArray[np.complex128]) -> float:
    values, vectors = np.linalg.eigh((rho + rho.conj().T) / 2)
    mask = values > 1e-15
    log_rho = (vectors[:, mask] * np.log(values[mask])) @ vectors[:, mask].conj().T
    sigma_values, sigma_vectors = np.linalg.eigh((sigma + sigma.conj().T) / 2)
    log_sigma = (sigma_vectors * np.log(sigma_values)) @ sigma_vectors.conj().T
    return float(np.trace(rho @ (log_rho - log_sigma)).real)


def type_iii_binary_audit(trials: int = 40) -> dict[str, float | int]:
    """Audit the two-sector algebra used in the regulator-free theorem."""
    max_orbit_error = 0.0
    max_relative_entropy_error = 0.0
    max_stationarity_error = 0.0
    rho0 = np.diag([1.0, 0.0]).astype(np.complex128)
    jump_up = np.array([[0.0, 0.0], [1.0, 0.0]], dtype=np.complex128)
    jump_down = jump_up.conj().T

    for _ in range(trials):
        kappa_plus = float(10.0 ** RNG.uniform(-1.0, 1.0))
        kappa_minus = float(10.0 ** RNG.uniform(-1.0, 1.0))
        rate_sum = kappa_plus + kappa_minus
        r = kappa_minus / rate_sum
        eta = np.diag([r, 1 - r]).astype(np.complex128)

        def generator(state: NDArray[np.complex128]):
            return kappa_plus * dissipator(jump_up, state) + kappa_minus * dissipator(
                jump_down, state
            )

        max_stationarity_error = max(
            max_stationarity_error, float(np.linalg.norm(generator(eta), "fro"))
        )
        time = float(10.0 ** RNG.uniform(-5.0, 0.0))
        evolved = evolve_with_generator(generator, rho0, time)
        p = (1 - r) * (1 - np.exp(-rate_sum * time))
        exact = np.diag([1 - p, p]).astype(np.complex128)
        max_orbit_error = max(
            max_orbit_error, float(np.linalg.norm(evolved - exact, "fro"))
        )
        binary = (1 - p) * np.log((1 - p) / r) + p * np.log(p / (1 - r))
        max_relative_entropy_error = max(
            max_relative_entropy_error,
            abs(relative_entropy(evolved, eta) - float(binary)),
        )

    return {
        "trials": trials,
        "max_stationarity_error": max_stationarity_error,
        "max_exact_orbit_error": max_orbit_error,
        "max_binary_relative_entropy_error": max_relative_entropy_error,
    }


def dirac_probe_collision_audit(trials: int = 40) -> dict[str, float | int]:
    """Check the graded two-mode collision expansion and product limit."""
    lowering = np.array([[0.0, 1.0], [0.0, 0.0]], dtype=np.complex128)
    raising = lowering.conj().T
    identity = np.eye(2, dtype=np.complex128)
    parity = np.diag([1.0, -1.0]).astype(np.complex128)
    system_a = np.kron(lowering, identity)
    probe_b = np.kron(parity, lowering)
    exchange = system_a.conj().T @ probe_b + probe_b.conj().T @ system_a

    max_rate_generator_error = 0.0
    max_scaled_second_order_remainder = 0.0
    max_product_limit_error = 0.0
    max_product_first_order_ratio = 0.0

    def probe_expectation(operator: NDArray[np.complex128], probe_state):
        blocks = operator.reshape(2, 2, 2, 2)
        return np.einsum("ab,iajb->ij", probe_state, blocks)

    for _ in range(trials):
        beta_omega = float(RNG.uniform(0.1, 5.0))
        occupation = 1.0 / (1.0 + np.exp(beta_omega))
        probe_state = np.diag([1 - occupation, occupation]).astype(np.complex128)
        coupling = float(10.0 ** RNG.uniform(-0.5, 0.5))
        kappa_plus = coupling**2 * occupation
        kappa_minus = coupling**2 * (1 - occupation)

        def lindblad_map(observable: NDArray[np.complex128]):
            return kappa_plus * (
                lowering @ observable @ raising
                - (lowering @ raising @ observable + observable @ lowering @ raising) / 2
            ) + kappa_minus * (
                raising @ observable @ lowering
                - (raising @ lowering @ observable + observable @ raising @ lowering) / 2
            )

        lindblad_super = superoperator_from_map(lindblad_map, 2)

        def collision_super(delta: float):
            unitary = expm(-1j * coupling * np.sqrt(delta) * exchange)

            def channel(observable: NDArray[np.complex128]):
                lifted = np.kron(observable, identity)
                evolved = unitary.conj().T @ lifted @ unitary
                return probe_expectation(evolved, probe_state)

            return superoperator_from_map(channel, 2)

        delta = 1e-4 / max(1.0, coupling**2)
        channel_super = collision_super(delta)
        identity_super = np.eye(4, dtype=np.complex128)
        inferred = (channel_super - identity_super) / delta
        max_rate_generator_error = max(
            max_rate_generator_error,
            float(np.linalg.norm(inferred - lindblad_super, ord=2)),
        )
        max_scaled_second_order_remainder = max(
            max_scaled_second_order_remainder,
            float(
                np.linalg.norm(
                    channel_super - identity_super - delta * lindblad_super, ord=2
                )
                / delta**2
            ),
        )

        time = 0.7 / max(1.0, coupling**2)
        exact_limit = expm(time * lindblad_super)
        errors = []
        for steps in (256, 512):
            discrete = np.linalg.matrix_power(collision_super(time / steps), steps)
            errors.append(float(np.linalg.norm(discrete - exact_limit, ord=2)))
        max_product_limit_error = max(max_product_limit_error, errors[-1])
        if errors[0] > 1e-15:
            max_product_first_order_ratio = max(
                max_product_first_order_ratio, errors[1] / errors[0]
            )

    return {
        "trials": trials,
        "max_generator_error_at_small_delta": max_rate_generator_error,
        "max_delta_squared_scaled_remainder": max_scaled_second_order_remainder,
        "max_product_limit_error_at_512_collisions": max_product_limit_error,
        "max_error_ratio_when_doubling_collisions": max_product_first_order_ratio,
    }


def autonomous_dirac_bath_audit(trials: int = 40) -> dict[str, float | int]:
    """Audit the on-shell fermionic KMS rates and the induced binary QMS."""
    rho0 = np.diag([1.0, 0.0]).astype(np.complex128)
    jump_up = np.array([[0.0, 0.0], [1.0, 0.0]], dtype=np.complex128)
    jump_down = jump_up.conj().T
    max_kms_ratio_error = 0.0
    max_stationarity_error = 0.0
    max_orbit_error = 0.0
    max_leakage_rate_error = 0.0

    for _ in range(trials):
        mass = float(RNG.uniform(0.0, 1.0))
        omega = float(mass + RNG.uniform(0.2, 3.0))
        beta = float(RNG.uniform(0.2, 4.0))
        cutoff = float(RNG.uniform(1.0, 5.0))
        momentum = np.sqrt(omega**2 - mass**2)
        # A positive smooth wave-packet spectral density, with normalization
        # absorbed into the fixed spatial form factor.
        spectral_density = float(
            omega * momentum * np.exp(-(momentum / cutoff) ** 2)
        )
        occupation = 1.0 / (1.0 + np.exp(beta * omega))
        gamma_down = 2 * np.pi * spectral_density * (1 - occupation)
        gamma_up = 2 * np.pi * spectral_density * occupation
        gamma = gamma_up + gamma_down

        max_kms_ratio_error = max(
            max_kms_ratio_error,
            abs(gamma_up / gamma_down - np.exp(-beta * omega)),
        )

        eta = np.diag([gamma_down / gamma, gamma_up / gamma]).astype(
            np.complex128
        )

        def generator(state: NDArray[np.complex128]):
            return gamma_up * dissipator(jump_up, state) + gamma_down * dissipator(
                jump_down, state
            )

        max_stationarity_error = max(
            max_stationarity_error, float(np.linalg.norm(generator(eta), "fro"))
        )
        leakage = float(generator(rho0)[1, 1].real)
        max_leakage_rate_error = max(
            max_leakage_rate_error, abs(leakage - gamma_up)
        )
        tau = float(10.0 ** RNG.uniform(-5.0, -0.2))
        evolved = evolve_with_generator(generator, rho0, tau)
        probability = (gamma_up / gamma) * (1 - np.exp(-gamma * tau))
        exact = np.diag([1 - probability, probability]).astype(np.complex128)
        max_orbit_error = max(
            max_orbit_error, float(np.linalg.norm(evolved - exact, "fro"))
        )

    return {
        "trials": trials,
        "max_fermionic_kms_ratio_error": max_kms_ratio_error,
        "max_stationarity_error": max_stationarity_error,
        "max_exact_orbit_error": max_orbit_error,
        "max_absorption_leakage_rate_error": max_leakage_rate_error,
    }


def finite_coupling_volterra_audit(trials: int = 100) -> dict[str, float | int]:
    """Test the explicit amplitude bound on an exactly soluble memory kernel.

    For K(s)=gamma exp(-alpha s), the Volterra equation is equivalent to a
    two-dimensional linear ODE, so no time discretization is involved.
    """
    max_absolute_error = 0.0
    max_error_to_bound_ratio = 0.0
    minimum_bound_margin = float("inf")

    for _ in range(trials):
        alpha = float(10.0 ** RNG.uniform(-0.2, 0.8))
        gamma = float(10.0 ** RNG.uniform(-1.0, 0.4))
        coupling = float(10.0 ** RNG.uniform(-2.2, -0.4))
        horizon = float(10.0 ** RNG.uniform(-1.0, 0.7))
        moment_zero = gamma / alpha
        moment_one = gamma / alpha**2
        davies_rate = moment_zero
        system = np.array(
            [[0.0, -1.0], [gamma / coupling**2, -alpha / coupling**2]],
            dtype=np.float64,
        )

        for tau in np.linspace(0.0, horizon, 401):
            exact = float((expm(tau * system) @ np.array([1.0, 0.0]))[0])
            markov = float(np.exp(-davies_rate * tau))
            error = abs(exact - markov)
            bound = coupling**2 * moment_one * (1 + moment_zero * horizon)
            max_absolute_error = max(max_absolute_error, error)
            max_error_to_bound_ratio = max(
                max_error_to_bound_ratio, error / max(bound, 1e-300)
            )
            minimum_bound_margin = min(minimum_bound_margin, bound - error)

    return {
        "trials": trials,
        "grid_points_per_trial": 401,
        "max_absolute_amplitude_error": max_absolute_error,
        "max_error_to_explicit_bound_ratio": max_error_to_bound_ratio,
        "minimum_bound_minus_error": minimum_bound_margin,
    }


def all_time_resonance_audit(trials: int = 60) -> dict[str, float | int]:
    """Check uniform O(lambda^2) scaling for analytic exponential kernels."""
    max_error = 0.0
    max_scaled_error = 0.0
    max_terminal_error = 0.0

    for _ in range(trials):
        alpha = float(10.0 ** RNG.uniform(-0.1, 0.8))
        gamma = float(10.0 ** RNG.uniform(-1.1, 0.2))
        coupling = float(10.0 ** RNG.uniform(-2.5, -1.0))
        davies_rate = gamma / alpha
        system = np.array(
            [[0.0, -(coupling**2)], [gamma, -alpha]], dtype=np.float64
        )
        terminal_time = 24.0 / (coupling**2 * davies_rate)
        times = np.concatenate(
            ([0.0], np.geomspace(1e-8, terminal_time, 900))
        )

        trial_error = 0.0
        for physical_time in times:
            exact = float(
                (expm(physical_time * system) @ np.array([1.0, 0.0]))[0]
            )
            markov = float(
                np.exp(-(coupling**2) * davies_rate * physical_time)
            )
            trial_error = max(trial_error, abs(exact - markov))

        terminal_exact = float(
            (expm(terminal_time * system) @ np.array([1.0, 0.0]))[0]
        )
        terminal_markov = float(
            np.exp(-(coupling**2) * davies_rate * terminal_time)
        )
        max_error = max(max_error, trial_error)
        max_scaled_error = max(max_scaled_error, trial_error / coupling**2)
        max_terminal_error = max(
            max_terminal_error, abs(terminal_exact - terminal_markov)
        )

    return {
        "trials": trials,
        "time_points_per_trial": 901,
        "max_uniform_amplitude_error": max_error,
        "max_error_divided_by_lambda_squared": max_scaled_error,
        "max_error_at_twenty_four_lifetimes": max_terminal_error,
    }


def explicit_compact_dirac_form_factor_audit() -> dict[str, float | int]:
    """Audit the concrete compact smear used in the all-time Dirac theorem.

    The analytic Paley--Wiener statement is proved in the paper.  Numerically we
    verify the two scalar facts entering the FGR check: positivity of the radial
    Fourier transform at the Bohr shell and the omega^10 threshold law.
    """

    omega = 1.0
    radius = 1.0 / (2.0 * omega)

    def bump(radial_position: float) -> float:
        scaled = radial_position / radius
        if scaled >= 1.0:
            return 0.0
        return float(np.exp(-1.0 / (1.0 - scaled * scaled)))

    def radial_fourier(momentum: float) -> float:
        def integrand(radial_position: float) -> float:
            argument = momentum * radial_position
            sinc = 1.0 if argument == 0.0 else np.sin(argument) / argument
            return 4.0 * np.pi * radial_position**2 * bump(radial_position) * sinc

        return float(quad(integrand, 0.0, radius, epsabs=1e-13, epsrel=1e-13)[0])

    momenta = np.geomspace(1e-4, omega, 80)
    transforms = np.array([radial_fourier(value) for value in momenta])
    spectral_density = momenta**10 * transforms**2
    scaled_density = spectral_density / momenta**10

    with (OUT / "dirac_form_factor_samples.csv").open(
        "w", newline="", encoding="utf-8"
    ) as stream:
        writer = csv.writer(stream)
        writer.writerow(["omega", "b_hat", "omega10_b_hat_squared"])
        writer.writerows(zip(momenta, transforms, spectral_density))

    minimum_sinc_on_support = float(np.sin(0.5) / 0.5)
    return {
        "bohr_frequency": omega,
        "support_radius": radius,
        "minimum_sinc_on_support": minimum_sinc_on_support,
        "b_hat_at_bohr_shell": radial_fourier(omega),
        "minimum_sampled_b_hat": float(np.min(transforms)),
        "minimum_scaled_threshold_density": float(np.min(scaled_density)),
        "maximum_scaled_threshold_density": float(np.max(scaled_density)),
        "sample_points": len(momenta),
        "threshold_power": 10,
    }


def faithful_family_exponent_audit() -> dict[str, float | int]:
    """Check the min(alpha,1) faithful-floor saturation law."""
    gamma = 1.0
    alphas = [0.25, 0.5, 1.0, 1.5, 2.0]
    times = [1e-6, 1e-8, 1e-10]
    max_smallest_time_error = 0.0
    monotone_improvements = 0

    for alpha in alphas:
        errors = []
        target = min(alpha, 1.0)
        for time in times:
            epsilon = time**alpha
            evolved = 1.0 - (1.0 - epsilon) * np.exp(-gamma * time)
            entropy_change = quad(
                lambda probability: np.log((1.0 - probability) / probability),
                epsilon,
                evolved,
                epsabs=1e-14,
                epsrel=1e-12,
                limit=100,
            )[0]
            normalized = entropy_change / (time * np.log(1.0 / time))
            errors.append(abs(normalized - target))
        if errors[-1] <= errors[0]:
            monotone_improvements += 1
        max_smallest_time_error = max(max_smallest_time_error, errors[-1])

    return {
        "tested_exponents": len(alphas),
        "times_per_exponent": len(times),
        "max_abs_normalized_error_at_t_1e_minus_10": max_smallest_time_error,
        "exponents_with_improved_small_time_error": monotone_improvements,
    }


def crossover_figure() -> dict[str, float]:
    gamma = 1.0
    times = np.logspace(-10, -1, 500)
    epsilons = [0.0, 1e-8, 1e-6, 1e-4, 1e-2]

    fig, ax = plt.subplots(figsize=(7.1, 4.5))
    max_exact_error = 0.0
    for epsilon in epsilons:
        initial_excited = epsilon
        evolved_excited = 1 - (1 - initial_excited) * np.exp(-gamma * times)

        def binary_entropy(probability: NDArray[np.float64]):
            probability = np.clip(probability, 1e-300, 1 - 1e-15)
            return -probability * np.log(probability) - (1 - probability) * np.log(
                1 - probability
            )

        power = (binary_entropy(evolved_excited) - binary_entropy(initial_excited)) / times
        label = r"$\varepsilon=0$" if epsilon == 0 else rf"$\varepsilon=10^{{{int(np.log10(epsilon))}}}$"
        ax.plot(times, power, linewidth=1.8, label=label)

        if epsilon > 0:
            plateau = gamma * (1 - epsilon) * np.log((1 - epsilon) / epsilon)
            relative = abs(power[0] - plateau) / max(1.0, abs(plateau))
            max_exact_error = max(max_exact_error, float(relative))

    ax.set_xscale("log")
    ax.set_xlabel(r"refresh time $t$")
    ax.set_ylabel(r"entropy contribution to power $[S(\rho_t)-S(\rho_0)]/t$")
    ax.set_title("Soft support turns the rapid singularity into a logarithmic plateau")
    ax.grid(True, which="both", alpha=0.25)
    ax.legend(frameon=False, ncol=2)
    fig.tight_layout()
    fig.savefig(OUT / "soft_boundary_crossover.pdf", bbox_inches="tight")
    fig.savefig(OUT / "soft_boundary_crossover.png", dpi=220, bbox_inches="tight")
    plt.close(fig)
    return {"maximum_relative_plateau_error_at_smallest_time": max_exact_error}


def main() -> None:
    parameters = {
        "seed": 20260805,
        "random_gkls_trials": 40,
        "type_iii_binary_trials": 40,
        "dirac_probe_collision_trials": 40,
        "autonomous_dirac_bath_trials": 40,
        "finite_coupling_volterra_trials": 100,
        "all_time_resonance_trials": 60,
        "compact_dirac_bohr_frequency": 1.0,
        "compact_dirac_support_radius": 0.5,
        "faithful_family_exponents": [0.25, 0.5, 1.0, 1.5, 2.0],
    }
    report = {
        "seed": parameters["seed"],
        "autonomous_dirac_bath_audit": autonomous_dirac_bath_audit(),
        "dirac_probe_collision_audit": dirac_probe_collision_audit(),
        "explicit_compact_dirac_form_factor_audit": explicit_compact_dirac_form_factor_audit(),
        "type_iii_binary_audit": type_iii_binary_audit(),
        "random_gkls_audit": random_gkls_audit(),
        "finite_coupling_volterra_audit": finite_coupling_volterra_audit(),
        "all_time_resonance_audit": all_time_resonance_audit(),
        "faithful_family_exponent_audit": faithful_family_exponent_audit(),
        "exact_two_level_crossover": crossover_figure(),
    }
    (OUT / "verification_report.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    (OUT / "parameters.json").write_text(
        json.dumps(parameters, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
