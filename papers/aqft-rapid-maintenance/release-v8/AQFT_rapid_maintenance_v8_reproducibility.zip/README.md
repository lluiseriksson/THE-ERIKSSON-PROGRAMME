# Reproducibility package

The archive `AQFT_rapid_maintenance_v8_reproducibility.zip` accompanies **Faithfulness, Not Algebra Type, Controls the Rapid-Maintenance Singularity**, version 8 (5 August 2026).

## One-command audit

Create a Python environment, install the pinned packages, and run:

```text
python verify_soft_boundary.py
```

The command is deterministic. It rewrites:

- `verification_report.json`
- `parameters.json`
- `dirac_form_factor_samples.csv`
- `soft_boundary_crossover.pdf`
- `soft_boundary_crossover.png`

The random seed is `20260805`.

## What is checked

The script audits:

1. the exact binary type-III reduction in its two-sector matrix representative;
2. the finite-dimensional softened-boundary entropy identity and GKLS square-sum formula;
3. the graded-CAR collision signs and product-limit scaling;
4. the fermionic KMS ratio, stationary weights, and exact Dirac-bath orbit;
5. positivity and threshold order of the explicit compact Dirac form factor used in the all-time theorem;
6. the finite-coupling Volterra bound on exactly solved exponential kernels;
7. all-time pole scaling on exactly solved analytic kernels;
8. the faithful-family exponent saturation law; and
9. the exact two-level crossover used for Figure 1.

Numerical checks do not replace the analytic proofs. In particular, Paley-Wiener analyticity, spectral deformation, relative Cauchy evolution, and the type-III Araki-relative-entropy identity are proved or sourced in the paper rather than inferred numerically.

## Manifest

- `Eriksson_Faithfulness_Rapid_Maintenance_AQFT_2026_v8.pdf`: final paper.
- `faithfulness_rapid_maintenance.tex`: complete LaTeX source.
- `verify_soft_boundary.py`: deterministic audit and figure generator.
- `parameters.json`: seeds, trial counts, and explicit form-factor parameters.
- `verification_report.json`: machine-readable audit output.
- `dirac_form_factor_samples.csv`: sampled radial transform and threshold density.
- `soft_boundary_crossover.pdf`, `soft_boundary_crossover.png`: generated Figure 1.
- `requirements.txt`: tested Python package versions.
- `SHA256SUMS.txt`: SHA-256 manifest for every other file in this directory.

## Tested environment

- Python 3.11+
- NumPy 2.3.5
- SciPy 1.15.2
- Matplotlib 3.10.8

The audit uses only public numerical APIs and should also run on nearby package versions, but the versions above are the delivered reference environment.
