$ErrorActionPreference = 'Stop'

Write-Output 'Machine-checked SU(2) crossing differential descent verification'
Write-Output ('UTC start: ' + [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))

$expectedToolchain = 'leanprover/lean4:v4.29.0-rc6'
$expectedMathlib = '07642720480157414db592fa85b626dafb71355b'
$producer = 'Lean2dYangMills/SU2CrossingDifferentialDescent.lean'
$audit = 'Lean2dYangMills/AuditSU2CrossingDifferentialDescent.lean'

$actualToolchain = (Get-Content -Raw -LiteralPath 'lean-toolchain').Trim()
if ($actualToolchain -ne $expectedToolchain) { throw "Unexpected Lean toolchain: $actualToolchain" }
$manifest = Get-Content -Raw -LiteralPath 'lake-manifest.json'
if ($manifest -notmatch [regex]::Escape($expectedMathlib)) {
  throw 'Pinned Mathlib commit not found in lake-manifest.json.'
}

Write-Output 'Building the producer and dependency closure'
lake build Lean2dYangMills.SU2CrossingDifferentialDescent
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Output 'Compiling the kernel dependency audit'
lake env lean $audit
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

Write-Output 'Scanning new modules for local proof escapes'
$matches = rg -n --glob '*.lean' '\b(sorry|admit|axiom)\b' $producer $audit
if ($LASTEXITCODE -eq 0) { $matches; throw 'Proof-escape scan failed.' }
if ($LASTEXITCODE -ne 1) { exit $LASTEXITCODE }

Write-Output 'Counting public declarations in the producer'
$declarations = rg -n '^(?:@\[[^]]+\]\s*)?(abbrev|def|theorem|structure) ' $producer
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
$declarations
if (($declarations | Measure-Object).Count -ne 26) {
  throw 'Expected exactly 26 public declarations.'
}
if (@(Get-Content -LiteralPath $producer).Count -ne 426) {
  throw 'Expected exactly 426 physical producer lines.'
}

Write-Output ('Producer SHA-256: ' + (Get-FileHash -Algorithm SHA256 $producer).Hash)
Write-Output ('Audit SHA-256: ' + (Get-FileHash -Algorithm SHA256 $audit).Hash)
Write-Output ('UTC finish: ' + [DateTime]::UtcNow.ToString('yyyy-MM-ddTHH:mm:ssZ'))
Write-Output 'VERIFICATION RESULT: PASS'
