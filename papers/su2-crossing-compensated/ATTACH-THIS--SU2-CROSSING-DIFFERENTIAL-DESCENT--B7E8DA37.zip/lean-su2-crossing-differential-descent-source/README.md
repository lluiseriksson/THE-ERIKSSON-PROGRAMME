# Machine-checked SU(2) crossing differential descent

This is the Lean artifact for the paper *Machine-Checked Haar and Differential
Descent at an SU(2) Crossing*. It contains the exact four-edge-to-two-coordinate
Haar quotient, gauge-compensated physical flows, differential descent of the
crossing Wilson word, and the resulting four-edge Pauli Ward identity.

Pinned environment:

- Lean `4.29.0-rc6`
- Mathlib `07642720480157414db592fa85b626dafb71355b`

Reproduce from a clean extracted source tree in Windows PowerShell:

```powershell
lake update
lake exe cache get
.\verify-su2-crossing-differential-descent.ps1
```

The verifier builds the dependency closure, compiles the kernel audit, scans
the two new modules for `sorry`, `admit`, and local `axiom`, checks 26 public
declarations and 426 physical producer lines, and prints SHA-256 hashes.
See `CLAIM_SCOPE.md` for the exact scientific boundary.
