# Verification record - 2 August 2026

- Producer: `Lean2dYangMills/SU2CrossingDifferentialDescent.lean`
- Audit: `Lean2dYangMills/AuditSU2CrossingDifferentialDescent.lean`
- Lean: `v4.29.0-rc6`
- Mathlib: `07642720480157414db592fa85b626dafb71355b`
- Producer size: 426 physical lines
- Public surface: 26 declarations
- Theorems audited: 16
- Clean-source build target:
  `Lean2dYangMills.SU2CrossingDifferentialDescent`
- Expected theorem dependency set: `propext`, `Classical.choice`, `Quot.sound`
- Local proof escapes: none

The final release must be reconstructed from the exact source ZIP. The wrapper
must record all 2915 build jobs, compile the audit, and end with
`VERIFICATION RESULT: PASS`.
