import Lean2dYangMills.SU2PhysicalConstructionIntegral

/-!
# Explicit boundary-disk examples

The universal conditioned-edge theorem is stated over the certified structure
`SU2BoundaryDiskCellulation`.  This module supplies a concrete inhabitant: one
triangular bounded face with the oppositely oriented exterior cycle.  Thus the
central domain is demonstrably nonempty, and the headline theorem has a fully
instantiated physical-edge consumer.
-/

noncomputable section

namespace Lean2dYangMills

namespace SU2TriangleBoundaryExample

abbrev Face := Fin 1
abbrev Vertex := Fin 3
abbrev Edge := Fin 3
abbrev HalfEdge := Edge × Bool

def edgeSource : Edge -> Vertex := ![0, 1, 2]
def edgeTarget : Edge -> Vertex := ![1, 2, 0]

def source (h : HalfEdge) : Vertex :=
  if h.2 then edgeTarget h.1 else edgeSource h.1

def face (h : HalfEdge) : Option Face :=
  if h.2 then none else some 0

def reverse : Equiv.Perm HalfEdge where
  toFun h := (h.1, !h.2)
  invFun h := (h.1, !h.2)
  left_inv := by
    intro h
    simp
  right_inv := by
    intro h
    simp

def nextEdge (h : HalfEdge) : Edge :=
  if h.2 then ![2, 0, 1] h.1 else ![1, 2, 0] h.1

def previousEdge (h : HalfEdge) : Edge :=
  if h.2 then ![1, 2, 0] h.1 else ![2, 0, 1] h.1

def next : Equiv.Perm HalfEdge where
  toFun h := (nextEdge h, h.2)
  invFun h := (previousEdge h, h.2)
  left_inv := by decide
  right_inv := by decide

theorem face_cycle (h k : HalfEdge) (hface : face h = face k) :
    ∃ n : Nat, (next ^ n) h = k := by
  rcases h with ⟨he, hb⟩
  rcases k with ⟨ke, kb⟩
  fin_cases he <;> fin_cases hb <;> fin_cases ke <;> fin_cases kb
  all_goals simp [face] at hface
  all_goals first
    | exact ⟨0, by decide⟩
    | exact ⟨1, by decide⟩
    | exact ⟨2, by decide⟩

/-- The underlying finite combinatorial disk: one triangular bounded face. -/
def cellulation : SU2FiniteDiskCellulation where
  Face := Face
  Vertex := Vertex
  Edge := Edge
  HalfEdge := HalfEdge
  edgeDarts := Equiv.refl _
  reverse := reverse
  reverse_involutive := by
    intro h
    rcases h with ⟨e, b⟩
    simp [reverse]
  reverse_ne := by
    intro h
    rcases h with ⟨e, b⟩
    fin_cases b <;> simp [reverse]
  reverse_edgeDarts := by
    intro e b
    rfl
  source := source
  face := face
  next := next
  next_source := by decide
  face_next := by decide
  face_cycle := face_cycle
  faceArea := fun _ => 1
  faceArea_pos := by norm_num
  euler_disk := by norm_num

theorem dualGraph_eq_top : cellulation.dualGraph = ⊤ := by
  ext f g
  fin_cases f
  fin_cases g
  simp [SU2FiniteDiskCellulation.dualGraph]

theorem primalGraph_eq_top : cellulation.primalGraph = ⊤ := by
  ext v w
  fin_cases v <;> fin_cases w
  all_goals simp only [SU2FiniteDiskCellulation.primalGraph,
    SU2FiniteDiskCellulation.primalAdj, SimpleGraph.top_adj]
  · simp
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (0, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (2, true), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (0, true), rfl, rfl⟩
  · simp
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (1, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (2, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (1, true), rfl, rfl⟩
  · simp

def connected : SU2ConnectedDiskCellulation where
  cellulation := cellulation
  dual_connected := by
    letI : Nonempty cellulation.Face := ⟨by
      change Face
      exact 0⟩
    change cellulation.dualGraph.Connected
    rw [dualGraph_eq_top]
    exact SimpleGraph.connected_top

def edgeConnected : SU2EdgeConnectedDiskCellulation where
  connected := connected
  primal_connected := by
    letI : Nonempty cellulation.Vertex := ⟨by
      change Vertex
      exact 0⟩
    change cellulation.primalGraph.Connected
    rw [primalGraph_eq_top]
    exact SimpleGraph.connected_top
  faceBoundaryLength := fun _ => 3
  faceBoundaryLength_pos := by norm_num
  faceBoundaryStart := fun _ => (0, false)
  faceBoundaryStart_face := by decide
  faceBoundary_closed := by decide
  faceBoundary_complete := by
    intro f h hh
    fin_cases f
    rcases h with ⟨he, hb⟩
    change face (he, hb) = some 0 at hh
    fin_cases he <;> fin_cases hb
    all_goals simp [face] at hh
    all_goals first
      | exact ⟨0, by decide⟩
      | exact ⟨1, by decide⟩
      | exact ⟨2, by decide⟩
  faceBoundary_nodup := by decide

def exteriorEdgeAt (k : Fin 3) : Edge :=
  cellulation.edgeOfHalfEdge ((cellulation.next ^ (k : Nat)) (0, true))

@[simp] theorem exteriorEdgeAt_zero : exteriorEdgeAt 0 = 0 := by
  decide

@[simp] theorem exteriorEdgeAt_one : exteriorEdgeAt 1 = 2 := by
  decide

@[simp] theorem exteriorEdgeAt_two : exteriorEdgeAt 2 = 1 := by
  decide

theorem exteriorEdgeAt_injective : Function.Injective exteriorEdgeAt := by
  intro i j hij
  fin_cases i <;> fin_cases j <;> simp_all

/-- A concrete inhabitant of the central boundary-cellulation record. -/
def boundaryDisk : SU2BoundaryDiskCellulation where
  toSU2EdgeConnectedDiskCellulation := edgeConnected
  exteriorBoundaryLength := 3
  exteriorBoundaryLength_pos := by norm_num
  exteriorBoundaryStart := (0, true)
  exteriorBoundaryStart_face := by decide
  exteriorBoundary_closed := by decide
  exteriorBoundary_complete := by
    intro h hh
    rcases h with ⟨he, hb⟩
    change face (he, hb) = none at hh
    fin_cases he <;> fin_cases hb
    all_goals simp [face] at hh
    all_goals first
      | exact ⟨0, by decide⟩
      | exact ⟨1, by decide⟩
      | exact ⟨2, by decide⟩
  exteriorBoundary_edge_injective := by
    exact exteriorEdgeAt_injective

theorem boundaryDisk_card_data :
    Fintype.card boundaryDisk.connected.cellulation.Vertex = 3 ∧
    Fintype.card boundaryDisk.connected.cellulation.Edge = 3 ∧
    Fintype.card boundaryDisk.connected.cellulation.Face = 1 := by
  decide

theorem boundaryDisk_conditionedEdgeModelAmplitude_eq_heatKernel
    (g : SU2) :
    boundaryDisk.conditionedEdgeModelAmplitude g = su2HeatKernel 1 g := by
  rw [boundaryDisk.conditionedEdgeModelAmplitude_eq_heatKernel]
  congr 2
  change (∑ _ : Fin 1, (1 : Real)) = 1
  norm_num

end SU2TriangleBoundaryExample

namespace SU2ThreeSpokeBoundaryExample

abbrev Face := Fin 3
abbrev Vertex := Fin 4
abbrev Edge := Fin 6
abbrev HalfEdge := Edge × Bool

def edgeSource : Edge -> Vertex := ![0, 0, 0, 1, 2, 3]
def edgeTarget : Edge -> Vertex := ![1, 2, 3, 2, 3, 1]

def source (h : HalfEdge) : Vertex :=
  if h.2 then edgeTarget h.1 else edgeSource h.1

def faceFalse : Edge -> Option Face :=
  ![some 0, some 1, some 2, some 0, some 1, some 2]

def faceTrue : Edge -> Option Face :=
  ![some 2, some 0, some 1, none, none, none]

def face (h : HalfEdge) : Option Face :=
  if h.2 then faceTrue h.1 else faceFalse h.1

def reverse : Equiv.Perm HalfEdge where
  toFun h := (h.1, !h.2)
  invFun h := (h.1, !h.2)
  left_inv := by intro h; rcases h with ⟨e, b⟩; simp
  right_inv := by intro h; rcases h with ⟨e, b⟩; simp

def nextFun (h : HalfEdge) : HalfEdge :=
  if h.2 then
    (![2, 0, 1, 5, 3, 4] h.1, ![false, false, false, true, true, true] h.1)
  else
    (![3, 4, 5, 1, 2, 0] h.1, ![false, false, false, true, true, true] h.1)

def previousFun (h : HalfEdge) : HalfEdge :=
  if h.2 then
    (![5, 3, 4, 4, 5, 3] h.1, ![false, false, false, true, true, true] h.1)
  else
    (![1, 2, 0, 0, 1, 2] h.1, ![true, true, true, false, false, false] h.1)

def next : Equiv.Perm HalfEdge where
  toFun := nextFun
  invFun := previousFun
  left_inv := by decide
  right_inv := by decide

theorem face_cycle (h k : HalfEdge) (hface : face h = face k) :
    ∃ n : Nat, (next ^ n) h = k := by
  rcases h with ⟨he, hb⟩
  rcases k with ⟨ke, kb⟩
  fin_cases he <;> fin_cases hb <;> fin_cases ke <;> fin_cases kb
  all_goals simp [face, faceFalse, faceTrue] at hface
  all_goals first
    | exact ⟨0, by decide⟩
    | exact ⟨1, by decide⟩
    | exact ⟨2, by decide⟩

/-- Three triangular faces meeting at one interior vertex. -/
def cellulation : SU2FiniteDiskCellulation where
  Face := Face
  Vertex := Vertex
  Edge := Edge
  HalfEdge := HalfEdge
  edgeDarts := Equiv.refl _
  reverse := reverse
  reverse_involutive := by intro h; rcases h with ⟨e, b⟩; simp [reverse]
  reverse_ne := by intro h; rcases h with ⟨e, b⟩; fin_cases b <;> simp [reverse]
  reverse_edgeDarts := by intro e b; rfl
  source := source
  face := face
  next := next
  next_source := by decide
  face_next := by decide
  face_cycle := face_cycle
  faceArea := fun _ => 1
  faceArea_pos := by norm_num
  euler_disk := by norm_num

theorem dualGraph_eq_top : cellulation.dualGraph = ⊤ := by
  ext f g
  fin_cases f <;> fin_cases g
  all_goals simp only [SU2FiniteDiskCellulation.dualGraph,
    SU2FiniteDiskCellulation.dualAdj, SimpleGraph.top_adj]
  · simp
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (1, true), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (0, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (1, false), rfl, rfl⟩
  · simp
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (2, true), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (0, true), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _
      exact ⟨by omega, (2, false), rfl, rfl⟩
  · simp

theorem primalGraph_eq_top : cellulation.primalGraph = ⊤ := by
  ext v w
  fin_cases v <;> fin_cases w
  all_goals simp only [SU2FiniteDiskCellulation.primalGraph,
    SU2FiniteDiskCellulation.primalAdj, SimpleGraph.top_adj]
  · simp
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (0, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (1, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (2, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (0, true), rfl, rfl⟩
  · simp
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (3, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (5, true), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (1, true), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (3, true), rfl, rfl⟩
  · simp
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (4, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (2, true), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (5, false), rfl, rfl⟩
  · constructor
    · exact fun h => h.1
    · intro _; exact ⟨by omega, (4, true), rfl, rfl⟩
  · simp

def connected : SU2ConnectedDiskCellulation where
  cellulation := cellulation
  dual_connected := by
    letI : Nonempty cellulation.Face := ⟨by change Face; exact 0⟩
    change cellulation.dualGraph.Connected
    rw [dualGraph_eq_top]
    exact SimpleGraph.connected_top

def faceBoundaryStart : Face -> HalfEdge :=
  ![(0, false), (1, false), (2, false)]

def edgeConnected : SU2EdgeConnectedDiskCellulation where
  connected := connected
  primal_connected := by
    letI : Nonempty cellulation.Vertex := ⟨by change Vertex; exact 0⟩
    change cellulation.primalGraph.Connected
    rw [primalGraph_eq_top]
    exact SimpleGraph.connected_top
  faceBoundaryLength := fun _ => 3
  faceBoundaryLength_pos := by norm_num
  faceBoundaryStart := faceBoundaryStart
  faceBoundaryStart_face := by decide
  faceBoundary_closed := by decide
  faceBoundary_complete := by decide
  faceBoundary_nodup := by decide

def exteriorEdgeAt (k : Fin 3) : Edge :=
  cellulation.edgeOfHalfEdge ((cellulation.next ^ (k : Nat)) (3, true))

@[simp] theorem exteriorEdgeAt_zero : exteriorEdgeAt 0 = 3 := by decide
@[simp] theorem exteriorEdgeAt_one : exteriorEdgeAt 1 = 5 := by decide
@[simp] theorem exteriorEdgeAt_two : exteriorEdgeAt 2 = 4 := by decide

theorem exteriorEdgeAt_injective : Function.Injective exteriorEdgeAt := by
  intro i j hij
  fin_cases i <;> fin_cases j <;> simp_all

/-- The cyclic three-face witness: its derived dual graph is `K₃`. -/
def boundaryDisk : SU2BoundaryDiskCellulation where
  toSU2EdgeConnectedDiskCellulation := edgeConnected
  exteriorBoundaryLength := 3
  exteriorBoundaryLength_pos := by norm_num
  exteriorBoundaryStart := (3, true)
  exteriorBoundaryStart_face := by decide
  exteriorBoundary_closed := by decide
  exteriorBoundary_complete := by decide
  exteriorBoundary_edge_injective := exteriorEdgeAt_injective

theorem boundaryDisk_card_data :
    Fintype.card boundaryDisk.connected.cellulation.Vertex = 4 ∧
    Fintype.card boundaryDisk.connected.cellulation.Edge = 6 ∧
    Fintype.card boundaryDisk.connected.cellulation.Face = 3 := by
  decide

theorem boundaryDisk_dualGraph_eq_top :
    boundaryDisk.connected.cellulation.dualGraph = ⊤ := by
  exact dualGraph_eq_top

theorem boundaryDisk_conditionedEdgeModelAmplitude_eq_heatKernel
    (g : SU2) :
    boundaryDisk.conditionedEdgeModelAmplitude g = su2HeatKernel 3 g := by
  rw [boundaryDisk.conditionedEdgeModelAmplitude_eq_heatKernel]
  congr 2
  change (∑ _ : Fin 3, (1 : Real)) = 3
  norm_num

end SU2ThreeSpokeBoundaryExample

theorem nonempty_su2BoundaryDiskCellulation :
    Nonempty SU2BoundaryDiskCellulation :=
  ⟨SU2TriangleBoundaryExample.boundaryDisk⟩

end Lean2dYangMills
