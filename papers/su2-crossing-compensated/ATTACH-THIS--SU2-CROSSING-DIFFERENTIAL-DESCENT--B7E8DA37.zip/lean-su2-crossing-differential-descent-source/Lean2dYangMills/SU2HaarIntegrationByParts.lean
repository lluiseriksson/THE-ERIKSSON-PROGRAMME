import Mathlib.Analysis.Calculus.ParametricIntegral
import Lean2dYangMills.SU2FiniteGaugeFixing
import Lean2dYangMills.SU2TraceSkein

/-!
# Haar integration by parts on finite SU(2) edge configurations

This file supplies the analytic producer that was absent from the finite-SU(2)
trace-skein development.  The core theorem differentiates a genuinely
measure-preserving real flow under the integral sign, with a locally uniform
integrable majorant, and proves that the integral of its infinitesimal
generator vanishes.  A product-rule corollary is the corresponding integration
by parts identity.

The abstract result is then instantiated twice:

* on normalized Haar measure of the concrete Mathlib `SU(2)` group;
* on finite products of normalized Haar measure, with a flow acting on one
  selected edge coordinate.

No Makeenko--Migdal area identity is assumed or claimed here.  The output is
the reusable Haar integration-by-parts layer needed to move invariant
derivatives between a finite-edge density and an observable.
-/

noncomputable section

open scoped BigOperators

namespace Lean2dYangMills

open MeasureTheory Set

section AbstractFlow

variable {Alpha : Type*} [MeasurableSpace Alpha]

/-- Differentiation under a measure-preserving flow.  The derivative family is
proved integrable from the supplied majorant, and invariance forces its
integral to vanish. -/
theorem integral_generator_eq_zero_of_measurePreserving_flow
    {mu : Measure Alpha}
    (T : Real -> Alpha -> Alpha)
    (hT : forall t, MeasurePreserving (T t) mu mu)
    (hT_zero : forall x, T 0 x = x)
    (f D : Alpha -> Complex)
    (hf : Integrable f mu)
    (hD : AEStronglyMeasurable D mu)
    (epsilon : Real) (h_epsilon : 0 < epsilon)
    (bound : Alpha -> Real) (hbound_int : Integrable bound mu)
    (h_deriv : forall x t, |t| < epsilon ->
      HasDerivAt (fun s => f (T s x)) (D (T t x)) t)
    (h_bound : forall x t, |t| < epsilon ->
      ‖D (T t x)‖ <= bound x) :
    (∫ x, D x ∂mu) = 0 := by
  let F : Real -> Alpha -> Complex := fun t x => f (T t x)
  let F' : Real -> Alpha -> Complex := fun t x => D (T t x)
  have hs : Ioo (-epsilon) epsilon ∈ nhds (0 : Real) :=
    Ioo_mem_nhds (by linarith) (by linarith)
  have hF_meas : forall t, AEStronglyMeasurable (F t) mu := by
    intro t
    simpa [F, Function.comp_def] using
      hf.aestronglyMeasurable.comp_quasiMeasurePreserving
        (hT t).quasiMeasurePreserving
  have hF_int : Integrable (F 0) mu := by
    simpa [F, hT_zero] using hf
  have hF'_meas : AEStronglyMeasurable (F' 0) mu := by
    simpa [F', hT_zero] using hD
  have hdiff := hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (μ := mu) (F := F) (F' := F') (bound := bound)
    (s := Ioo (-epsilon) epsilon) (x₀ := (0 : Real))
    hs
    (Filter.Eventually.of_forall hF_meas)
    hF_int
    hF'_meas
    (ae_of_all _ fun x t ht => by
      exact h_bound x t (abs_lt.2 ht))
    hbound_int
    (ae_of_all _ fun x t ht => by
      exact h_deriv x t (abs_lt.2 ht))
  have hinvariant : forall t,
      (∫ x, F t x ∂mu) = ∫ x, f x ∂mu := by
    intro t
    have hfm : AEStronglyMeasurable f (Measure.map (T t) mu) := by
      rw [(hT t).map_eq]
      exact hf.aestronglyMeasurable
    have hmap := MeasureTheory.integral_map
      (hT t).measurable.aemeasurable hfm
    rw [(hT t).map_eq] at hmap
    simpa [F, Function.comp_def] using hmap.symm
  have hconst : HasDerivAt (fun t => ∫ x, F t x ∂mu) 0 0 := by
    convert hasDerivAt_const (x := (0 : Real)) (∫ x, f x ∂mu) using 1
    funext t
    exact hinvariant t
  have hzero : (∫ x, F' 0 x ∂mu) = 0 := hdiff.2.unique hconst
  simpa [F', hT_zero] using hzero

/-- Data sufficient for a dominated product-rule calculation along a
measure-preserving flow.  The bounds are local in the flow parameter but
uniform in the configuration variable. -/
structure DominatedFlowPair
    (mu : Measure Alpha) (T : Real -> Alpha -> Alpha)
    (f g Df Dg : Alpha -> Complex) where
  epsilon : Real
  epsilon_pos : 0 < epsilon
  bound_f : Real
  bound_g : Real
  bound_Df : Real
  bound_Dg : Real
  bound_f_nonneg : 0 <= bound_f
  bound_g_nonneg : 0 <= bound_g
  bound_Df_nonneg : 0 <= bound_Df
  bound_Dg_nonneg : 0 <= bound_Dg
  measurable_f : AEStronglyMeasurable f mu
  measurable_g : AEStronglyMeasurable g mu
  measurable_Df : AEStronglyMeasurable Df mu
  measurable_Dg : AEStronglyMeasurable Dg mu
  norm_f_le : forall x t, |t| < epsilon -> ‖f (T t x)‖ <= bound_f
  norm_g_le : forall x t, |t| < epsilon -> ‖g (T t x)‖ <= bound_g
  norm_Df_le : forall x t, |t| < epsilon -> ‖Df (T t x)‖ <= bound_Df
  norm_Dg_le : forall x t, |t| < epsilon -> ‖Dg (T t x)‖ <= bound_Dg
  hasDerivAt_f : forall x t, |t| < epsilon ->
    HasDerivAt (fun s => f (T s x)) (Df (T t x)) t
  hasDerivAt_g : forall x t, |t| < epsilon ->
    HasDerivAt (fun s => g (T s x)) (Dg (T t x)) t

/-- Haar-type integration by parts for a dominated measure-preserving flow. -/
theorem integral_generator_mul_eq_neg_integral_mul_generator
    {mu : Measure Alpha} [IsFiniteMeasure mu]
    (T : Real -> Alpha -> Alpha)
    (hT : forall t, MeasurePreserving (T t) mu mu)
    (hT_zero : forall x, T 0 x = x)
    (f g Df Dg : Alpha -> Complex)
    (P : DominatedFlowPair mu T f g Df Dg) :
    (∫ x, Df x * g x ∂mu) =
      -(∫ x, f x * Dg x ∂mu) := by
  let product : Alpha -> Complex := fun x => f x * g x
  let productD : Alpha -> Complex := fun x => Df x * g x + f x * Dg x
  let C : Real := P.bound_Df * P.bound_g + P.bound_f * P.bound_Dg
  have hproduct_int : Integrable product mu := by
    refine (integrable_const (P.bound_f * P.bound_g : Real)).mono' ?_ ?_
    · exact P.measurable_f.mul P.measurable_g
    · exact ae_of_all _ fun x => by
        have hf0 := P.norm_f_le x 0 (by simpa using P.epsilon_pos)
        have hg0 := P.norm_g_le x 0 (by simpa using P.epsilon_pos)
        simpa [product, hT_zero, norm_mul] using
          (mul_le_mul hf0 hg0 (norm_nonneg _) P.bound_f_nonneg)
  have hproductD_meas : AEStronglyMeasurable productD mu :=
    (P.measurable_Df.mul P.measurable_g).add
      (P.measurable_f.mul P.measurable_Dg)
  have hC_int : Integrable (fun _x : Alpha => C) mu := integrable_const C
  have hproduct_deriv : forall x t, |t| < P.epsilon ->
      HasDerivAt (fun s => product (T s x)) (productD (T t x)) t := by
    intro x t ht
    simpa [product, productD] using
      (P.hasDerivAt_f x t ht).mul (P.hasDerivAt_g x t ht)
  have hproductD_bound : forall x t, |t| < P.epsilon ->
      ‖productD (T t x)‖ <= C := by
    intro x t ht
    calc
      ‖productD (T t x)‖ <=
          ‖Df (T t x)‖ * ‖g (T t x)‖ +
            ‖f (T t x)‖ * ‖Dg (T t x)‖ := by
              simpa [productD, norm_mul] using
                norm_add_le (Df (T t x) * g (T t x))
                  (f (T t x) * Dg (T t x))
      _ <= C := by
        dsimp [C]
        apply add_le_add
        · exact mul_le_mul (P.norm_Df_le x t ht) (P.norm_g_le x t ht)
            (norm_nonneg _) P.bound_Df_nonneg
        · exact mul_le_mul (P.norm_f_le x t ht) (P.norm_Dg_le x t ht)
            (norm_nonneg _) P.bound_f_nonneg
  have hzero := integral_generator_eq_zero_of_measurePreserving_flow
    T hT hT_zero product productD hproduct_int hproductD_meas
    P.epsilon P.epsilon_pos (fun _x => C) hC_int
    hproduct_deriv hproductD_bound
  rw [show productD = fun x => Df x * g x + f x * Dg x by rfl] at hzero
  have hDf_g_int : Integrable (fun x => Df x * g x) mu := by
    refine (integrable_const (P.bound_Df * P.bound_g : Real)).mono' ?_ ?_
    · exact P.measurable_Df.mul P.measurable_g
    · exact ae_of_all _ fun x => by
        have hDf0 := P.norm_Df_le x 0 (by simpa using P.epsilon_pos)
        have hg0 := P.norm_g_le x 0 (by simpa using P.epsilon_pos)
        simpa [hT_zero, norm_mul] using
          (mul_le_mul hDf0 hg0 (norm_nonneg _) P.bound_Df_nonneg)
  have hf_Dg_int : Integrable (fun x => f x * Dg x) mu := by
    refine (integrable_const (P.bound_f * P.bound_Dg : Real)).mono' ?_ ?_
    · exact P.measurable_f.mul P.measurable_Dg
    · exact ae_of_all _ fun x => by
        have hf0 := P.norm_f_le x 0 (by simpa using P.epsilon_pos)
        have hDg0 := P.norm_Dg_le x 0 (by simpa using P.epsilon_pos)
        simpa [hT_zero, norm_mul] using
          (mul_le_mul hf0 hDg0 (norm_nonneg _) P.bound_f_nonneg)
  rw [integral_add hDf_g_int hf_Dg_int] at hzero
  exact eq_neg_of_add_eq_zero_left hzero

/-- Two successive integrations by parts transfer a mixed pair of generators
from a density to an observable with positive sign.  No commutation relation
between the two flows is assumed: the two intermediate derivatives are named
separately and supplied by the caller. -/
theorem integral_two_generators_transfer
    {mu : Measure Alpha} [IsFiniteMeasure mu]
    (T₁ T₂ : Real -> Alpha -> Alpha)
    (hT₁ : forall t, MeasurePreserving (T₁ t) mu mu)
    (hT₁_zero : forall x, T₁ 0 x = x)
    (hT₂ : forall t, MeasurePreserving (T₂ t) mu mu)
    (hT₂_zero : forall x, T₂ 0 x = x)
    (rho f D₂rho D₁D₂rho D₁f D₂D₁f : Alpha -> Complex)
    (P₁ : DominatedFlowPair mu T₁ D₂rho f D₁D₂rho D₁f)
    (P₂ : DominatedFlowPair mu T₂ rho D₁f D₂rho D₂D₁f) :
    (∫ x, D₁D₂rho x * f x ∂mu) =
      ∫ x, rho x * D₂D₁f x ∂mu := by
  have h₁ := integral_generator_mul_eq_neg_integral_mul_generator
    T₁ hT₁ hT₁_zero D₂rho f D₁D₂rho D₁f P₁
  have h₂ := integral_generator_mul_eq_neg_integral_mul_generator
    T₂ hT₂ hT₂_zero rho D₁f D₂rho D₂D₁f P₂
  calc
    (∫ x, D₁D₂rho x * f x ∂mu) =
        -(∫ x, D₂rho x * D₁f x ∂mu) := h₁
    _ = ∫ x, rho x * D₂D₁f x ∂mu := by rw [h₂]; simp

end AbstractFlow

/-! ## Concrete SU(2) Haar translations -/

/-- Left translation along an arbitrary real curve in concrete `SU(2)`. -/
def su2HaarLeftFlow (gamma : Real -> SU2) (t : Real) (x : SU2) : SU2 :=
  gamma t * x

/-- Right translation along an arbitrary real curve in concrete `SU(2)`. -/
def su2HaarRightFlow (gamma : Real -> SU2) (t : Real) (x : SU2) : SU2 :=
  x * gamma t

theorem measurePreserving_su2HaarLeftFlow (gamma : Real -> SU2) (t : Real) :
    MeasurePreserving (su2HaarLeftFlow gamma t) su2HaarProb su2HaarProb := by
  simpa [su2HaarLeftFlow] using
    MeasureTheory.measurePreserving_mul_left su2HaarProb (gamma t)

theorem measurePreserving_su2HaarRightFlow (gamma : Real -> SU2) (t : Real) :
    MeasurePreserving (su2HaarRightFlow gamma t) su2HaarProb su2HaarProb := by
  simpa [su2HaarRightFlow] using
    MeasureTheory.measurePreserving_mul_right su2HaarProb (gamma t)

/-- One-coordinate multiplier in a finite SU(2) edge configuration. -/
def su2SingleEdgeMultiplier {I : Type} [Fintype I]
    (edge : I) (h : SU2) : I -> SU2 := by
  classical
  exact fun j => if j = edge then h else 1

/-- Left-invariant flow on one selected edge coordinate. -/
def su2EdgeLeftFlow {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (t : Real)
    (U : I -> SU2) : I -> SU2 :=
  su2SingleEdgeMultiplier edge (gamma t) * U

/-- Right-invariant flow on one selected edge coordinate. -/
def su2EdgeRightFlow {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (t : Real)
    (U : I -> SU2) : I -> SU2 :=
  U * su2SingleEdgeMultiplier edge (gamma t)

theorem measurePreserving_su2EdgeLeftFlow {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (t : Real) :
    MeasurePreserving (su2EdgeLeftFlow edge gamma t)
      (su2FiniteProductHaar I) (su2FiniteProductHaar I) := by
  simpa [su2EdgeLeftFlow] using
    MeasureTheory.measurePreserving_mul_left (su2FiniteProductHaar I)
      (su2SingleEdgeMultiplier edge (gamma t))

theorem measurePreserving_su2EdgeRightFlow {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (t : Real) :
    MeasurePreserving (su2EdgeRightFlow edge gamma t)
      (su2FiniteProductHaar I) (su2FiniteProductHaar I) := by
  simpa [su2EdgeRightFlow] using
    MeasureTheory.measurePreserving_mul_right (su2FiniteProductHaar I)
      (su2SingleEdgeMultiplier edge (gamma t))

theorem su2EdgeLeftFlow_zero {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (hgamma_zero : gamma 0 = 1)
    (U : I -> SU2) : su2EdgeLeftFlow edge gamma 0 U = U := by
  classical
  funext j
  simp [su2EdgeLeftFlow, su2SingleEdgeMultiplier, hgamma_zero]

theorem su2EdgeRightFlow_zero {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (hgamma_zero : gamma 0 = 1)
    (U : I -> SU2) : su2EdgeRightFlow edge gamma 0 U = U := by
  classical
  funext j
  simp [su2EdgeRightFlow, su2SingleEdgeMultiplier, hgamma_zero]

/-- Single-edge SU(2) Haar integration by parts for a left-invariant flow. -/
theorem integral_su2Edge_leftGenerator_mul_eq_neg_integral_mul_generator
    {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (hgamma_zero : gamma 0 = 1)
    (f g Df Dg : (I -> SU2) -> Complex)
    (P : DominatedFlowPair (su2FiniteProductHaar I)
      (su2EdgeLeftFlow edge gamma) f g Df Dg) :
    (∫ U, Df U * g U ∂su2FiniteProductHaar I) =
      -(∫ U, f U * Dg U ∂su2FiniteProductHaar I) := by
  exact integral_generator_mul_eq_neg_integral_mul_generator
    (su2EdgeLeftFlow edge gamma)
    (measurePreserving_su2EdgeLeftFlow edge gamma)
    (su2EdgeLeftFlow_zero edge gamma hgamma_zero)
    f g Df Dg P

/-- Single-edge SU(2) Haar integration by parts for a right-invariant flow. -/
theorem integral_su2Edge_rightGenerator_mul_eq_neg_integral_mul_generator
    {I : Type} [Fintype I]
    (edge : I) (gamma : Real -> SU2) (hgamma_zero : gamma 0 = 1)
    (f g Df Dg : (I -> SU2) -> Complex)
    (P : DominatedFlowPair (su2FiniteProductHaar I)
      (su2EdgeRightFlow edge gamma) f g Df Dg) :
    (∫ U, Df U * g U ∂su2FiniteProductHaar I) =
      -(∫ U, f U * Dg U ∂su2FiniteProductHaar I) := by
  exact integral_generator_mul_eq_neg_integral_mul_generator
    (su2EdgeRightFlow edge gamma)
    (measurePreserving_su2EdgeRightFlow edge gamma)
    (su2EdgeRightFlow_zero edge gamma hgamma_zero)
    f g Df Dg P

/-- The concrete two-generator transfer on finite edge configurations, using
the right-multiplication convention standard in local Makeenko--Migdal
coordinates. -/
theorem integral_su2Edge_two_rightGenerators_transfer
    {I : Type} [Fintype I]
    (edge₁ edge₂ : I)
    (gamma₁ gamma₂ : Real -> SU2)
    (hgamma₁_zero : gamma₁ 0 = 1)
    (hgamma₂_zero : gamma₂ 0 = 1)
    (rho f D₂rho D₁D₂rho D₁f D₂D₁f : (I -> SU2) -> Complex)
    (P₁ : DominatedFlowPair (su2FiniteProductHaar I)
      (su2EdgeRightFlow edge₁ gamma₁)
      D₂rho f D₁D₂rho D₁f)
    (P₂ : DominatedFlowPair (su2FiniteProductHaar I)
      (su2EdgeRightFlow edge₂ gamma₂)
      rho D₁f D₂rho D₂D₁f) :
    (∫ U, D₁D₂rho U * f U ∂su2FiniteProductHaar I) =
      ∫ U, rho U * D₂D₁f U ∂su2FiniteProductHaar I := by
  exact integral_two_generators_transfer
    (su2EdgeRightFlow edge₁ gamma₁)
    (su2EdgeRightFlow edge₂ gamma₂)
    (measurePreserving_su2EdgeRightFlow edge₁ gamma₁)
    (su2EdgeRightFlow_zero edge₁ gamma₁ hgamma₁_zero)
    (measurePreserving_su2EdgeRightFlow edge₂ gamma₂)
    (su2EdgeRightFlow_zero edge₂ gamma₂ hgamma₂_zero)
    rho f D₂rho D₁D₂rho D₁f D₂D₁f P₁ P₂

/-! ## Pauli-normalized SU(2) curves -/

/-- The unit-row curve whose tangent is `i sigma_1 / 2`. -/
def su2PauliXCurveRow (t : Real) : SU2RowSphere := by
  refine ⟨(((Real.cos (t / 2) : Real) : Complex),
    Complex.I * (((Real.sin (t / 2) : Real) : Complex))), ?_⟩
  simp only [Complex.normSq_apply, Complex.ofReal_re, Complex.ofReal_im,
    Complex.I_mul_re, Complex.I_mul_im]
  nlinarith [Real.sin_sq_add_cos_sq (t / 2)]

/-- Concrete SU(2) curve tangent to the first Pauli direction. -/
def su2PauliXCurve (t : Real) : SU2 :=
  rowSphereToSU2 (su2PauliXCurveRow t)

theorem su2PauliXCurve_zero : su2PauliXCurve 0 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [su2PauliXCurve, su2PauliXCurveRow, rowSphereToSU2]

/-- Entrywise tangent normalization for the first Pauli curve. -/
theorem hasDerivAt_su2PauliXCurve_entry (i j : Fin 2) :
    HasDerivAt
      (fun t : Real => ((su2PauliXCurve t : SU2) :
        Matrix (Fin 2) (Fin 2) Complex) i j)
      (su2PauliX i j) 0 := by
  have hlin : HasDerivAt (fun t : Real => t / 2) (1 / 2 : Real) 0 := by
    simpa using (hasDerivAt_id (x := (0 : Real))).div_const 2
  have hcos : HasDerivAt (fun t : Real => Real.cos (t / 2)) 0 0 := by
    convert (Real.hasDerivAt_cos (0 / 2)).comp 0 hlin using 1 <;> norm_num
  have hsin : HasDerivAt (fun t : Real => Real.sin (t / 2)) (1 / 2 : Real) 0 := by
    convert (Real.hasDerivAt_sin (0 / 2)).comp 0 hlin using 1 <;> norm_num
  have hstarI (r : Real) :
      -star (Complex.I * (r : Complex)) = Complex.I * (r : Complex) := by
    apply Complex.ext <;> simp
  have hstarReal (r : Real) : star (r : Complex) = (r : Complex) := by
    exact Complex.conj_ofReal r
  fin_cases i <;> fin_cases j
  · change HasDerivAt (fun t : Real => ((Real.cos (t / 2) : Real) : Complex)) 0 0
    exact hcos.ofReal_comp
  · change HasDerivAt
      (fun t : Real => Complex.I * ((Real.sin (t / 2) : Real) : Complex))
      (Complex.I / 2) 0
    convert hsin.ofReal_comp.const_mul Complex.I using 1 <;>
      norm_num [Complex.ext_iff]
  · change HasDerivAt
      (fun t : Real => -star
        (Complex.I * ((Real.sin (t / 2) : Real) : Complex)))
      (Complex.I / 2) 0
    convert hsin.ofReal_comp.const_mul Complex.I using 1
    · funext t
      exact hstarI _
    · norm_num [Complex.ext_iff]
  · change HasDerivAt
      (fun t : Real => star (((Real.cos (t / 2) : Real) : Complex))) 0 0
    convert hcos.ofReal_comp using 1
    funext t
    exact hstarReal _

/-- The unit-row curve whose tangent is `i sigma_2 / 2`. -/
def su2PauliYCurveRow (t : Real) : SU2RowSphere := by
  refine ⟨(((Real.cos (t / 2) : Real) : Complex),
    ((Real.sin (t / 2) : Real) : Complex)), ?_⟩
  simp only [Complex.normSq_apply, Complex.ofReal_re, Complex.ofReal_im]
  nlinarith [Real.sin_sq_add_cos_sq (t / 2)]

/-- Concrete SU(2) curve tangent to the second Pauli direction. -/
def su2PauliYCurve (t : Real) : SU2 :=
  rowSphereToSU2 (su2PauliYCurveRow t)

theorem su2PauliYCurve_zero : su2PauliYCurve 0 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [su2PauliYCurve, su2PauliYCurveRow, rowSphereToSU2]

/-- Entrywise tangent normalization for the second Pauli curve. -/
theorem hasDerivAt_su2PauliYCurve_entry (i j : Fin 2) :
    HasDerivAt
      (fun t : Real => ((su2PauliYCurve t : SU2) :
        Matrix (Fin 2) (Fin 2) Complex) i j)
      (su2PauliY i j) 0 := by
  have hlin : HasDerivAt (fun t : Real => t / 2) (1 / 2 : Real) 0 := by
    simpa using (hasDerivAt_id (x := (0 : Real))).div_const 2
  have hcos : HasDerivAt (fun t : Real => Real.cos (t / 2)) 0 0 := by
    convert (Real.hasDerivAt_cos (0 / 2)).comp 0 hlin using 1 <;> norm_num
  have hsin : HasDerivAt (fun t : Real => Real.sin (t / 2)) (1 / 2 : Real) 0 := by
    convert (Real.hasDerivAt_sin (0 / 2)).comp 0 hlin using 1 <;> norm_num
  have hstarReal (r : Real) : star (r : Complex) = (r : Complex) := by
    exact Complex.conj_ofReal r
  fin_cases i <;> fin_cases j
  · change HasDerivAt (fun t : Real => ((Real.cos (t / 2) : Real) : Complex)) 0 0
    exact hcos.ofReal_comp
  · change HasDerivAt (fun t : Real => ((Real.sin (t / 2) : Real) : Complex))
      (1 / 2) 0
    convert hsin.ofReal_comp using 1 <;> norm_num
  · change HasDerivAt
      (fun t : Real => -star (((Real.sin (t / 2) : Real) : Complex)))
      (-(1 / 2 : Complex)) 0
    convert hsin.ofReal_comp.neg using 1
    · funext t
      rw [hstarReal]
      rfl
    · norm_num [Complex.ext_iff]
  · change HasDerivAt
      (fun t : Real => star (((Real.cos (t / 2) : Real) : Complex))) 0 0
    convert hcos.ofReal_comp using 1
    funext t
    exact hstarReal _

/-- The unit-row curve whose tangent is `i sigma_3 / 2`. -/
def su2PauliZCurveRow (t : Real) : SU2RowSphere := by
  let a : Complex := ((Real.cos (t / 2) : Real) : Complex) +
    Complex.I * ((Real.sin (t / 2) : Real) : Complex)
  refine ⟨(a, (0 : Complex)), ?_⟩
  dsimp [a]
  simp only [Complex.normSq_apply, Complex.add_re, Complex.ofReal_re,
    Complex.I_mul_re, Complex.ofReal_im, Complex.add_im,
    Complex.I_mul_im, Complex.zero_re, Complex.zero_im, zero_mul, zero_add,
    add_zero]
  nlinarith [Real.sin_sq_add_cos_sq (t / 2)]

/-- Concrete SU(2) curve tangent to the third Pauli direction. -/
def su2PauliZCurve (t : Real) : SU2 :=
  rowSphereToSU2 (su2PauliZCurveRow t)

theorem su2PauliZCurve_zero : su2PauliZCurve 0 = 1 := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [su2PauliZCurve, su2PauliZCurveRow, rowSphereToSU2]

/-- Entrywise tangent normalization for the third Pauli curve. -/
theorem hasDerivAt_su2PauliZCurve_entry (i j : Fin 2) :
    HasDerivAt
      (fun t : Real => ((su2PauliZCurve t : SU2) :
        Matrix (Fin 2) (Fin 2) Complex) i j)
      (su2PauliZ i j) 0 := by
  have hlin : HasDerivAt (fun t : Real => t / 2) (1 / 2 : Real) 0 := by
    simpa using (hasDerivAt_id (x := (0 : Real))).div_const 2
  have hcos : HasDerivAt (fun t : Real => Real.cos (t / 2)) 0 0 := by
    convert (Real.hasDerivAt_cos (0 / 2)).comp 0 hlin using 1 <;> norm_num
  have hsin : HasDerivAt (fun t : Real => Real.sin (t / 2)) (1 / 2 : Real) 0 := by
    convert (Real.hasDerivAt_sin (0 / 2)).comp 0 hlin using 1 <;> norm_num
  have hstarReal (r : Real) : star (r : Complex) = (r : Complex) := by
    exact Complex.conj_ofReal r
  have hstarI (r : Real) :
      star (Complex.I * (r : Complex)) = -Complex.I * (r : Complex) := by
    apply Complex.ext <;> simp
  fin_cases i <;> fin_cases j
  · change HasDerivAt
      (fun t : Real => ((Real.cos (t / 2) : Real) : Complex) +
        Complex.I * ((Real.sin (t / 2) : Real) : Complex))
      (Complex.I / 2) 0
    convert hcos.ofReal_comp.add (hsin.ofReal_comp.const_mul Complex.I) using 1 <;>
      norm_num [Complex.ext_iff]
  · change HasDerivAt (fun _t : Real => (0 : Complex)) 0 0
    exact hasDerivAt_const (x := (0 : Real)) 0
  · change HasDerivAt (fun _t : Real => -star (0 : Complex)) 0 0
    simpa using (hasDerivAt_const (x := (0 : Real)) (c := (0 : Complex)))
  · change HasDerivAt
      (fun t : Real => star
        (((Real.cos (t / 2) : Real) : Complex) +
          Complex.I * ((Real.sin (t / 2) : Real) : Complex)))
      (-(Complex.I / 2)) 0
    convert hcos.ofReal_comp.sub (hsin.ofReal_comp.const_mul Complex.I) using 1
    · funext t
      rw [star_add, hstarReal, hstarI]
      simp only [Pi.sub_apply, sub_eq_add_neg]
      ring
    · norm_num [Complex.ext_iff]

end Lean2dYangMills
