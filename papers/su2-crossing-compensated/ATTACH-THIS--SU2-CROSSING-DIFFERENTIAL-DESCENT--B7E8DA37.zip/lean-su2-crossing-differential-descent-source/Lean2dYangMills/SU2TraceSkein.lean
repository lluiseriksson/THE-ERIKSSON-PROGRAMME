import Lean2dYangMills.SU2Character

/-!
# The finite-`SU(2)` trace-skein closure at a crossing

This file isolates the exact rank-two algebra behind the finite-`N`
Makeenko--Migdal crossing term. No Yang--Mills integration or area derivative
is assumed here. We prove two unconditional facts:

* contraction against the three normalized Pauli directions produces the
  `SU(2)` correction `-W(A)W(B) + (1/4)W(AB)`;
* for special-unitary `2 x 2` matrices the trace skein identity rewrites the
  resulting two-trace term as a linear combination of two single traces.

Thus, once the analytic local Makeenko--Migdal identity is supplied, its
finite-`SU(2)` right-hand side closes linearly on single-trace loop words.
-/

noncomputable section

open scoped BigOperators

namespace Lean2dYangMills

open Matrix

/-- The normalized trace used for the fundamental Wilson observable. -/
def su2NormalizedMatrixTrace
    (A : Matrix (Fin 2) (Fin 2) Complex) : Complex :=
  Matrix.trace A / 2

/-- First normalized anti-Hermitian Pauli direction, `i sigma_1 / 2`. -/
def su2PauliX : Matrix (Fin 2) (Fin 2) Complex :=
  !![0, Complex.I / 2; Complex.I / 2, 0]

/-- Second normalized anti-Hermitian Pauli direction, `i sigma_2 / 2`. -/
def su2PauliY : Matrix (Fin 2) (Fin 2) Complex :=
  !![0, 1 / 2; -(1 / 2), 0]

/-- Third normalized anti-Hermitian Pauli direction, `i sigma_3 / 2`. -/
def su2PauliZ : Matrix (Fin 2) (Fin 2) Complex :=
  !![Complex.I / 2, 0; 0, -(Complex.I / 2)]

/-- The quadratic Casimir of the three normalized Pauli directions is
`-3/4` times the identity matrix. -/
theorem su2Pauli_casimir :
    su2PauliX * su2PauliX + su2PauliY * su2PauliY +
        su2PauliZ * su2PauliZ =
      -(3 / 4 : Complex) •
        (1 : Matrix (Fin 2) (Fin 2) Complex) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [su2PauliX, su2PauliY, su2PauliZ] <;>
    ring_nf <;>
    simp [Complex.I_sq] <;>
    norm_num

/-- The rank-two Fierz identity for the normalized Pauli directions. -/
theorem su2Pauli_fierz (B : Matrix (Fin 2) (Fin 2) Complex) :
    su2PauliX * B * su2PauliX + su2PauliY * B * su2PauliY +
        su2PauliZ * B * su2PauliZ =
      -su2NormalizedMatrixTrace B •
          (1 : Matrix (Fin 2) (Fin 2) Complex) +
        (1 / 4 : Complex) • B := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [su2PauliX, su2PauliY, su2PauliZ,
      su2NormalizedMatrixTrace, Matrix.trace_fin_two, Matrix.mul_apply,
      Matrix.vecMul, dotProduct, Fin.sum_univ_two] <;>
    ring_nf <;>
    simp [Complex.I_sq] <;>
    ring

/-- Contraction of a crossing word against the normalized Pauli directions. -/
def su2PauliCrossingContraction
    (A B : Matrix (Fin 2) (Fin 2) Complex) : Complex :=
  su2NormalizedMatrixTrace (A * su2PauliX * B * su2PauliX) +
  su2NormalizedMatrixTrace (A * su2PauliY * B * su2PauliY) +
  su2NormalizedMatrixTrace (A * su2PauliZ * B * su2PauliZ)

/-- The explicit Pauli contraction identity in the normalization for which
the fundamental `SU(2)` Casimir is `3/4`.

The theorem is polynomial matrix algebra and is valid for arbitrary complex
`2 x 2` matrices. The characteristic finite-`SU(2)` correction is the
`(1/4) W(AB)` term. -/
theorem su2PauliCrossingContraction_eq
    (A B : Matrix (Fin 2) (Fin 2) Complex) :
    su2PauliCrossingContraction A B =
      -su2NormalizedMatrixTrace A * su2NormalizedMatrixTrace B +
        (1 / 4 : Complex) * su2NormalizedMatrixTrace (A * B) := by
  simp [su2PauliCrossingContraction, su2NormalizedMatrixTrace,
    su2PauliX, su2PauliY, su2PauliZ, Matrix.trace_fin_two,
    Matrix.mul_apply, Fin.sum_univ_two]
  ring_nf
  rw [Complex.I_sq]
  ring

/-- Matrix form of the `SL(2)` trace-skein identity, specialized to the
concrete `SU(2)` group. -/
theorem su2_matrix_trace_skein (g h : SU2) :
    Matrix.trace
          ((g : Matrix (Fin 2) (Fin 2) Complex) *
            (h : Matrix (Fin 2) (Fin 2) Complex)) +
        Matrix.trace
          ((g : Matrix (Fin 2) (Fin 2) Complex) *
            star (h : Matrix (Fin 2) (Fin 2) Complex)) =
      Matrix.trace (g : Matrix (Fin 2) (Fin 2) Complex) *
        Matrix.trace (h : Matrix (Fin 2) (Fin 2) Complex) := by
  rw [Matrix.trace_fin_two, Matrix.trace_fin_two, Matrix.trace_fin_two,
    Matrix.trace_fin_two]
  simp only [Matrix.mul_apply, Fin.sum_univ_two,
    Matrix.star_eq_conjTranspose, Matrix.conjTranspose_apply]
  rw [su2_apply_one_one_eq_conj_apply_zero_zero h,
    su2_apply_one_zero_eq_neg_conj_apply_zero_one h]
  simp
  ring

/-- The normalized fundamental Wilson observable as a function on the
concrete `SU(2)` group. -/
def su2FundamentalWilson (g : SU2) : Complex :=
  su2NormalizedMatrixTrace (g : Matrix (Fin 2) (Fin 2) Complex)

/-- Exact normalized trace-skein relation for `SU(2)`. -/
theorem su2_fundamentalWilson_skein (g h : SU2) :
    su2FundamentalWilson g * su2FundamentalWilson h =
      (1 / 2 : Complex) *
        (su2FundamentalWilson (g * h) +
          su2FundamentalWilson (g * h⁻¹)) := by
  unfold su2FundamentalWilson su2NormalizedMatrixTrace
  change
    (Matrix.trace (g : Matrix (Fin 2) (Fin 2) Complex) / 2) *
        (Matrix.trace (h : Matrix (Fin 2) (Fin 2) Complex) / 2) =
      (1 / 2 : Complex) *
        (Matrix.trace
              ((g : Matrix (Fin 2) (Fin 2) Complex) *
                (h : Matrix (Fin 2) (Fin 2) Complex)) /
            2 +
          Matrix.trace
              ((g : Matrix (Fin 2) (Fin 2) Complex) *
                star (h : Matrix (Fin 2) (Fin 2) Complex)) /
            2)
  calc
    (Matrix.trace (g : Matrix (Fin 2) (Fin 2) Complex) / 2) *
          (Matrix.trace (h : Matrix (Fin 2) (Fin 2) Complex) / 2) =
        (1 / 4 : Complex) *
          (Matrix.trace (g : Matrix (Fin 2) (Fin 2) Complex) *
            Matrix.trace (h : Matrix (Fin 2) (Fin 2) Complex)) := by ring
    _ = (1 / 4 : Complex) *
          (Matrix.trace
              ((g : Matrix (Fin 2) (Fin 2) Complex) *
                (h : Matrix (Fin 2) (Fin 2) Complex)) +
            Matrix.trace
              ((g : Matrix (Fin 2) (Fin 2) Complex) *
                star (h : Matrix (Fin 2) (Fin 2) Complex))) := by
          rw [su2_matrix_trace_skein]
    _ = _ := by ring

/-- The finite-`SU(2)` Makeenko--Migdal crossing term closes exactly on two
single-trace resolutions. This theorem is the group-theoretic producer only;
it does not assert the analytic area-derivative equation. -/
theorem su2_makeenkoMigdal_crossingTerm_closed (g h : SU2) :
    su2FundamentalWilson g * su2FundamentalWilson h -
        (1 / 4 : Complex) * su2FundamentalWilson (g * h) =
      (1 / 4 : Complex) * su2FundamentalWilson (g * h) +
        (1 / 2 : Complex) * su2FundamentalWilson (g * h⁻¹) := by
  rw [su2_fundamentalWilson_skein]
  ring

/-- Recursive single-trace resolution of a product of fundamental Wilson
factors.  Every recursive branch contains one group word and one trace. -/
def su2WilsonProductExpansion (g : SU2) : List SU2 -> Complex
  | [] => su2FundamentalWilson g
  | h :: hs =>
      (1 / 2 : Complex) *
        (su2WilsonProductExpansion (g * h) hs +
          su2WilsonProductExpansion (g * h⁻¹) hs)

/-- All-order finite-`SU(2)` trace closure.  A product of any finite number of
normalized fundamental traces is exactly the recursive linear combination of
single traces obtained by resolving one factor at a time. -/
theorem su2WilsonProductExpansion_eq (g : SU2) (hs : List SU2) :
    su2WilsonProductExpansion g hs =
      su2FundamentalWilson g * (hs.map su2FundamentalWilson).prod := by
  induction hs generalizing g with
  | nil => simp [su2WilsonProductExpansion]
  | cons h hs ih =>
      rw [su2WilsonProductExpansion, ih (g := g * h), ih (g := g * h⁻¹)]
      simp only [List.map_cons, List.prod_cons]
      calc
        (1 / 2 : Complex) *
              (su2FundamentalWilson (g * h) *
                  (hs.map su2FundamentalWilson).prod +
                su2FundamentalWilson (g * h⁻¹) *
                  (hs.map su2FundamentalWilson).prod) =
            ((1 / 2 : Complex) *
                (su2FundamentalWilson (g * h) +
                  su2FundamentalWilson (g * h⁻¹))) *
              (hs.map su2FundamentalWilson).prod := by ring
        _ = (su2FundamentalWilson g * su2FundamentalWilson h) *
              (hs.map su2FundamentalWilson).prod := by
            rw [su2_fundamentalWilson_skein]
        _ = su2FundamentalWilson g *
              (su2FundamentalWilson h *
                (hs.map su2FundamentalWilson).prod) := by ring

/-- The Pauli contraction itself is the negative of the closed crossing term. -/
theorem su2PauliCrossingContraction_eq_closedResolutions (g h : SU2) :
    su2PauliCrossingContraction
        (g : Matrix (Fin 2) (Fin 2) Complex)
        (h : Matrix (Fin 2) (Fin 2) Complex) =
      -(1 / 4 : Complex) * su2FundamentalWilson (g * h) -
        (1 / 2 : Complex) * su2FundamentalWilson (g * h⁻¹) := by
  rw [su2PauliCrossingContraction_eq]
  change
    -su2FundamentalWilson g * su2FundamentalWilson h +
        (1 / 4 : Complex) * su2FundamentalWilson (g * h) = _
  calc
    -su2FundamentalWilson g * su2FundamentalWilson h +
          (1 / 4 : Complex) * su2FundamentalWilson (g * h) =
        -(su2FundamentalWilson g * su2FundamentalWilson h) +
          (1 / 4 : Complex) * su2FundamentalWilson (g * h) := by ring
    _ = -(1 / 2 : Complex) *
          (su2FundamentalWilson (g * h) +
            su2FundamentalWilson (g * h⁻¹)) +
          (1 / 4 : Complex) * su2FundamentalWilson (g * h) := by
        rw [su2_fundamentalWilson_skein]
        ring
    _ = _ := by ring

/-! ## Four-branch oriented local crossing interface -/

/-- Orientation carried by a transported local branch holonomy. -/
inductive SU2BranchOrientation where
  | forward
  | reverse
  deriving DecidableEq, Repr

/-- Reversing a branch replaces its holonomy by its group inverse. -/
def su2OrientedBranchHolonomy
    (orientation : SU2BranchOrientation) (holonomy : SU2) : SU2 :=
  match orientation with
  | .forward => holonomy
  | .reverse => holonomy⁻¹

/-- Algebraic local data at a transverse crossing after the four branches have
been transported to the crossing base point. Opposite cyclic positions
`0,2` and `1,3` form the two cut strands. Certification that geometric paths
produce such a datum belongs to the separate geometric layer. -/
structure SU2FourBranchCrossing where
  branch0 : SU2
  branch1 : SU2
  branch2 : SU2
  branch3 : SU2
  orientation0 : SU2BranchOrientation
  orientation1 : SU2BranchOrientation
  orientation2 : SU2BranchOrientation
  orientation3 : SU2BranchOrientation

/-- Holonomy of the first cut strand, joining opposite branches `0` and `2`. -/
def SU2FourBranchCrossing.firstStrand (crossing : SU2FourBranchCrossing) : SU2 :=
  su2OrientedBranchHolonomy crossing.orientation0 crossing.branch0 *
    su2OrientedBranchHolonomy crossing.orientation2 crossing.branch2

/-- Holonomy of the second cut strand, joining opposite branches `1` and `3`. -/
def SU2FourBranchCrossing.secondStrand (crossing : SU2FourBranchCrossing) : SU2 :=
  su2OrientedBranchHolonomy crossing.orientation1 crossing.branch1 *
    su2OrientedBranchHolonomy crossing.orientation3 crossing.branch3

/-- Orientation-preserving local reconnection. -/
def SU2FourBranchCrossing.directResolution (crossing : SU2FourBranchCrossing) : SU2 :=
  crossing.firstStrand * crossing.secondStrand

/-- The second local reconnection, with the second strand traversed backwards. -/
def SU2FourBranchCrossing.reverseResolution (crossing : SU2FourBranchCrossing) : SU2 :=
  crossing.firstStrand * crossing.secondStrand⁻¹

/-- The corrected finite-`SU(2)` crossing term attached to four oriented
branches. -/
def SU2FourBranchCrossing.correctedCrossingTerm
    (crossing : SU2FourBranchCrossing) : Complex :=
  su2FundamentalWilson crossing.firstStrand *
      su2FundamentalWilson crossing.secondStrand -
    (1 / 4 : Complex) * su2FundamentalWilson crossing.directResolution

/-- The binary skein relation closes uniformly for every assignment of four
branch holonomies and every choice of their orientations. -/
theorem su2_fourBranchCrossing_trace_skein (crossing : SU2FourBranchCrossing) :
    su2FundamentalWilson crossing.firstStrand *
        su2FundamentalWilson crossing.secondStrand =
      (1 / 2 : Complex) *
        (su2FundamentalWilson crossing.directResolution +
          su2FundamentalWilson crossing.reverseResolution) := by
  exact su2_fundamentalWilson_skein crossing.firstStrand crossing.secondStrand

/-- Universal four-branch closure theorem: the corrected crossing term is a
linear combination of precisely the two oriented local reconnections. -/
theorem su2_fourBranchCrossing_term_closed (crossing : SU2FourBranchCrossing) :
    crossing.correctedCrossingTerm =
      (1 / 4 : Complex) * su2FundamentalWilson crossing.directResolution +
        (1 / 2 : Complex) * su2FundamentalWilson crossing.reverseResolution := by
  exact su2_makeenkoMigdal_crossingTerm_closed
    crossing.firstStrand crossing.secondStrand

/-- The Pauli-contracted four-branch word closes on the same two local
reconnections with the corresponding negative coefficients. -/
theorem su2_fourBranchCrossing_pauliContraction_closed
    (crossing : SU2FourBranchCrossing) :
    su2PauliCrossingContraction
        (crossing.firstStrand : Matrix (Fin 2) (Fin 2) Complex)
        (crossing.secondStrand : Matrix (Fin 2) (Fin 2) Complex) =
      -(1 / 4 : Complex) * su2FundamentalWilson crossing.directResolution -
        (1 / 2 : Complex) * su2FundamentalWilson crossing.reverseResolution := by
  exact su2PauliCrossingContraction_eq_closedResolutions
    crossing.firstStrand crossing.secondStrand

end Lean2dYangMills
