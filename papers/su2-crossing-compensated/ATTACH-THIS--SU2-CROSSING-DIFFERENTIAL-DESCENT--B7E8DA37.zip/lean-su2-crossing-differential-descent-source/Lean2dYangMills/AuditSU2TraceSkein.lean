import Lean2dYangMills.SU2TraceSkein

/-!
# Kernel audit for the finite-SU(2) trace-skein paper

Run with:

`lake env lean Lean2dYangMills/AuditSU2TraceSkein.lean`
-/

#print axioms Lean2dYangMills.su2Pauli_casimir
#print axioms Lean2dYangMills.su2Pauli_fierz
#print axioms Lean2dYangMills.su2PauliCrossingContraction_eq
#print axioms Lean2dYangMills.su2_matrix_trace_skein
#print axioms Lean2dYangMills.su2_fundamentalWilson_skein
#print axioms Lean2dYangMills.su2_makeenkoMigdal_crossingTerm_closed
#print axioms Lean2dYangMills.su2PauliCrossingContraction_eq_closedResolutions
#print axioms Lean2dYangMills.su2WilsonProductExpansion_eq
#print axioms Lean2dYangMills.su2_fourBranchCrossing_trace_skein
#print axioms Lean2dYangMills.su2_fourBranchCrossing_term_closed
#print axioms Lean2dYangMills.su2_fourBranchCrossing_pauliContraction_closed
