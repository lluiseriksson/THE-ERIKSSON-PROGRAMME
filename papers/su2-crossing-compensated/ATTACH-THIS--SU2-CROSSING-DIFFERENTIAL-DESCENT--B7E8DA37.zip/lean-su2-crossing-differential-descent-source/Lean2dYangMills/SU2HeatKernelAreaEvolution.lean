import Lean2dYangMills.SU2ExactAreaLaw
import Mathlib.Analysis.Calculus.SmoothSeries
import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Analysis.Calculus.ContDiff.Deriv

/-!
# Positive-area evolution of the concrete SU(2) heat kernel

This module differentiates the already constructed infinite character series
with respect to heat time.  The derivative is produced term by term from an
explicit summable majorant on every positive-time neighbourhood; it is not a
field of an interface package.
-/

noncomputable section

set_option linter.unnecessarySeqFocus false

namespace Lean2dYangMills

open MeasureTheory Set Filter
open scoped ContDiff

/-- The SU(2) Casimir eigenvalue in the convention used by the heat kernel. -/
def su2CasimirEigenvalue (n : Nat) : Real :=
  (n : Real) * ((n : Real) + 2) / 4

/-- The coefficientwise positive-time derivative of the two-point class kernel. -/
def su2ClassHeatKernelAreaDerivativeTerm
    (t : Real) (g h : SU2) (n : Nat) : Complex :=
  ((-su2CasimirEigenvalue n * Real.exp (-t * su2CasimirEigenvalue n) : Real) : Complex) *
    su2CharacterChebyshev n g * su2CharacterChebyshev n h

/-- The spectral area derivative of the concrete infinite class heat kernel. -/
def su2ClassHeatKernelAreaDerivative (t : Real) (g h : SU2) : Complex :=
  ∑' n : Nat, su2ClassHeatKernelAreaDerivativeTerm t g h n

/-- A width-independent majorant for the first area derivative on `t >= epsilon`. -/
def su2AreaDerivativeMajorant (epsilon : Real) (n : Nat) : Real :=
  ((n : Real) + 1) ^ 4 *
    Real.exp (-epsilon * ((n : Real) * ((n : Real) + 2)) / 4)

theorem summable_su2AreaDerivativeMajorant
    {epsilon : Real} (hepsilon : 0 < epsilon) :
    Summable (su2AreaDerivativeMajorant epsilon) := by
  exact summable_pow_mul_exp_neg_casimir hepsilon 4

theorem hasDerivAt_su2ClassHeatKernelTerm_time
    (t : Real) (g h : SU2) (n : Nat) :
    HasDerivAt (fun s : Real => su2ClassHeatKernelTerm s g h n)
      (su2ClassHeatKernelAreaDerivativeTerm t g h n) t := by
  let c : Real := su2CasimirEigenvalue n
  have hlinear : HasDerivAt (fun s : Real => -s * c) (-c) t := by
    convert (hasDerivAt_id t).neg.mul_const c using 1 <;> ring
  have hexpReal : HasDerivAt (fun s : Real => Real.exp (-s * c))
      (-c * Real.exp (-t * c)) t := by
    convert (Real.hasDerivAt_exp (-t * c)).comp t hlinear using 1 <;> ring
  have hexpComplex : HasDerivAt
      (fun s : Real => ((Real.exp (-s * c) : Real) : Complex))
      ((-c * Real.exp (-t * c) : Real) : Complex) t :=
    hexpReal.ofReal_comp
  have hmul := (hexpComplex.mul_const (su2CharacterChebyshev n g)).mul_const
    (su2CharacterChebyshev n h)
  simpa [su2ClassHeatKernelTerm, su2ClassHeatWeight,
    su2ClassHeatKernelAreaDerivativeTerm, su2CasimirEigenvalue, c,
    mul_assoc] using hmul

theorem norm_su2ClassHeatKernelAreaDerivativeTerm_le_majorant
    {epsilon y : Real} (hy : epsilon < y) (g h : SU2) (n : Nat) :
    ‖su2ClassHeatKernelAreaDerivativeTerm y g h n‖ <=
      su2AreaDerivativeMajorant epsilon n := by
  have hn0 : (0 : Real) <= n := Nat.cast_nonneg n
  have hc0 : 0 <= su2CasimirEigenvalue n := by
    unfold su2CasimirEigenvalue
    positivity
  have hc_le : su2CasimirEigenvalue n <= ((n : Real) + 1) ^ 2 := by
    unfold su2CasimirEigenvalue
    nlinarith
  have hexp : Real.exp (-(y * su2CasimirEigenvalue n)) <=
      Real.exp (-(epsilon * su2CasimirEigenvalue n)) := by
    apply Real.exp_le_exp.mpr
    have hmul := mul_le_mul_of_nonneg_right hy.le hc0
    nlinarith
  have hcexp :
      su2CasimirEigenvalue n * Real.exp (-(y * su2CasimirEigenvalue n)) <=
        ((n : Real) + 1) ^ 2 *
          Real.exp (-(epsilon * su2CasimirEigenvalue n)) := by
    exact mul_le_mul hc_le hexp (Real.exp_pos _).le (sq_nonneg _)
  rw [su2ClassHeatKernelAreaDerivativeTerm, norm_mul, norm_mul,
    Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonpos (mul_nonpos_of_nonpos_of_nonneg
      (neg_nonpos.mpr hc0) (Real.exp_pos _).le)]
  simp only [neg_mul, neg_neg]
  change
    (su2CasimirEigenvalue n * Real.exp (-(y * su2CasimirEigenvalue n))) *
        ‖su2CharacterChebyshev n g‖ * ‖su2CharacterChebyshev n h‖ <= _
  calc
    (su2CasimirEigenvalue n * Real.exp (-(y * su2CasimirEigenvalue n))) *
          ‖su2CharacterChebyshev n g‖ * ‖su2CharacterChebyshev n h‖ <=
        (su2CasimirEigenvalue n * Real.exp (-(y * su2CasimirEigenvalue n))) *
          ((n : Real) + 1) * ((n : Real) + 1) := by
      gcongr
      · exact abs_su2CharacterChebyshev_le n g
      · exact abs_su2CharacterChebyshev_le n h
    _ <=
        (((n : Real) + 1) ^ 2 *
          Real.exp (-(epsilon * su2CasimirEigenvalue n))) *
          ((n : Real) + 1) * ((n : Real) + 1) := by
      gcongr
    _ = su2AreaDerivativeMajorant epsilon n := by
      unfold su2AreaDerivativeMajorant su2CasimirEigenvalue
      ring_nf

/-- The infinite two-point SU(2) class heat kernel is differentiable at every
positive time, and its derivative is the explicit Casimir-weighted series. -/
theorem hasDerivAt_su2ClassHeatKernel_time
    {t : Real} (ht : 0 < t) (g h : SU2) :
    HasDerivAt (fun s : Real => su2ClassHeatKernel s g h)
      (su2ClassHeatKernelAreaDerivative t g h) t := by
  let epsilon : Real := t / 2
  have hepsilon : 0 < epsilon := by dsimp [epsilon]; linarith
  have htmem : t ∈ Set.Ioi epsilon := by
    show epsilon < t
    dsimp [epsilon]
    linarith
  have hsum0 : Summable (fun n : Nat => su2ClassHeatKernelTerm t g h n) :=
    summable_su2ClassHeatKernelTerm ht g h
  have hseries := hasDerivAt_tsum_of_isPreconnected
    (summable_su2AreaDerivativeMajorant hepsilon)
    isOpen_Ioi isPreconnected_Ioi
    (fun n y _hy => hasDerivAt_su2ClassHeatKernelTerm_time y g h n)
    (fun n y hy => norm_su2ClassHeatKernelAreaDerivativeTerm_le_majorant hy g h n)
    htmem hsum0 htmem
  simpa [su2ClassHeatKernel, su2ClassHeatKernelAreaDerivative] using hseries

theorem differentiableAt_su2ClassHeatKernel_time
    {t : Real} (ht : 0 < t) (g h : SU2) :
    DifferentiableAt Real (fun s : Real => su2ClassHeatKernel s g h) t :=
  (hasDerivAt_su2ClassHeatKernel_time ht g h).differentiableAt

/-! ## The full positive-time spectral jet -/

/-- The `r`th coefficientwise area derivative. -/
def su2ClassHeatKernelAreaJetTerm
    (r : Nat) (t : Real) (g h : SU2) (n : Nat) : Complex :=
  ((Real.exp (-t * su2CasimirEigenvalue n) : Real) : Complex) *
    (-(su2CasimirEigenvalue n : Complex)) ^ r *
      su2CharacterChebyshev n g * su2CharacterChebyshev n h

def su2ClassHeatKernelAreaJet
    (r : Nat) (t : Real) (g h : SU2) : Complex :=
  ∑' n : Nat, su2ClassHeatKernelAreaJetTerm r t g h n

def su2AreaJetMajorant (r : Nat) (epsilon : Real) (n : Nat) : Real :=
  ((n : Real) + 1) ^ (2 * r + 2) *
    Real.exp (-epsilon * ((n : Real) * ((n : Real) + 2)) / 4)

theorem summable_su2AreaJetMajorant
    (r : Nat) {epsilon : Real} (hepsilon : 0 < epsilon) :
    Summable (su2AreaJetMajorant r epsilon) := by
  exact summable_pow_mul_exp_neg_casimir hepsilon (2 * r + 2)

theorem hasDerivAt_su2ClassHeatKernelAreaJetTerm
    (r : Nat) (t : Real) (g h : SU2) (n : Nat) :
    HasDerivAt (fun s : Real => su2ClassHeatKernelAreaJetTerm r s g h n)
      (su2ClassHeatKernelAreaJetTerm (r + 1) t g h n) t := by
  let c : Real := su2CasimirEigenvalue n
  have hlinear : HasDerivAt (fun s : Real => -s * c) (-c) t := by
    convert (hasDerivAt_id t).neg.mul_const c using 1 <;> ring
  have hexpReal : HasDerivAt (fun s : Real => Real.exp (-s * c))
      (-c * Real.exp (-t * c)) t := by
    convert (Real.hasDerivAt_exp (-t * c)).comp t hlinear using 1 <;> ring
  have hexpComplex : HasDerivAt
      (fun s : Real => ((Real.exp (-s * c) : Real) : Complex))
      ((-c * Real.exp (-t * c) : Real) : Complex) t :=
    hexpReal.ofReal_comp
  have hmul :=
    (((hexpComplex.mul_const ((-(c : Complex)) ^ r)).mul_const
      (su2CharacterChebyshev n g)).mul_const (su2CharacterChebyshev n h))
  simpa [su2ClassHeatKernelAreaJetTerm, c, su2CasimirEigenvalue,
    pow_succ, mul_assoc, mul_left_comm, mul_comm] using hmul

theorem norm_su2ClassHeatKernelAreaJetTerm_le_majorant
    (r : Nat) {epsilon y : Real} (hy : epsilon < y)
    (g h : SU2) (n : Nat) :
    ‖su2ClassHeatKernelAreaJetTerm r y g h n‖ <=
      su2AreaJetMajorant r epsilon n := by
  have hc0 : 0 <= su2CasimirEigenvalue n := by
    unfold su2CasimirEigenvalue
    positivity
  have hc_le : su2CasimirEigenvalue n <= ((n : Real) + 1) ^ 2 := by
    unfold su2CasimirEigenvalue
    nlinarith [Nat.cast_nonneg (α := Real) n]
  have hcpow : su2CasimirEigenvalue n ^ r <= (((n : Real) + 1) ^ 2) ^ r :=
    pow_le_pow_left₀ hc0 hc_le r
  have hexp : Real.exp (-(y * su2CasimirEigenvalue n)) <=
      Real.exp (-(epsilon * su2CasimirEigenvalue n)) := by
    apply Real.exp_le_exp.mpr
    have hmul := mul_le_mul_of_nonneg_right hy.le hc0
    nlinarith
  rw [su2ClassHeatKernelAreaJetTerm, norm_mul, norm_mul, norm_mul,
    Complex.norm_real, Real.norm_eq_abs, abs_of_pos (Real.exp_pos _),
    norm_pow, norm_neg, Complex.norm_real, Real.norm_eq_abs,
    abs_of_nonneg hc0]
  simp only [neg_mul]
  have hmain :
      Real.exp (-(y * su2CasimirEigenvalue n)) * su2CasimirEigenvalue n ^ r <=
        Real.exp (-(epsilon * su2CasimirEigenvalue n)) *
          (((n : Real) + 1) ^ 2) ^ r := by
    exact mul_le_mul hexp hcpow (pow_nonneg hc0 r) (Real.exp_pos _).le
  calc
    Real.exp (-(y * su2CasimirEigenvalue n)) * su2CasimirEigenvalue n ^ r *
          ‖su2CharacterChebyshev n g‖ * ‖su2CharacterChebyshev n h‖ <=
        Real.exp (-(y * su2CasimirEigenvalue n)) *
          su2CasimirEigenvalue n ^ r *
          ((n : Real) + 1) * ((n : Real) + 1) := by
      gcongr
      · exact abs_su2CharacterChebyshev_le n g
      · exact abs_su2CharacterChebyshev_le n h
    _ <=
        Real.exp (-(epsilon * su2CasimirEigenvalue n)) *
          (((n : Real) + 1) ^ 2) ^ r *
          ((n : Real) + 1) * ((n : Real) + 1) := by
      gcongr
    _ = su2AreaJetMajorant r epsilon n := by
      unfold su2AreaJetMajorant su2CasimirEigenvalue
      rw [← pow_mul, pow_add]
      ring_nf

/-- Every order of the positive-time spectral jet differentiates to the next
order.  This is the kernel-checked all-order area-evolution statement. -/
theorem hasDerivAt_su2ClassHeatKernelAreaJet
    (r : Nat) {t : Real} (ht : 0 < t) (g h : SU2) :
    HasDerivAt (fun s : Real => su2ClassHeatKernelAreaJet r s g h)
      (su2ClassHeatKernelAreaJet (r + 1) t g h) t := by
  let epsilon : Real := t / 2
  have hepsilon : 0 < epsilon := by dsimp [epsilon]; linarith
  have htmem : t ∈ Set.Ioi epsilon := by
    show epsilon < t
    dsimp [epsilon]
    linarith
  have hsum0 : Summable
      (fun n : Nat => su2ClassHeatKernelAreaJetTerm r t g h n) := by
    exact Summable.of_norm_bounded
      (summable_su2AreaJetMajorant r hepsilon)
      (fun n => norm_su2ClassHeatKernelAreaJetTerm_le_majorant r htmem g h n)
  have hseries := hasDerivAt_tsum_of_isPreconnected
    (summable_su2AreaJetMajorant (r + 1) hepsilon)
    isOpen_Ioi isPreconnected_Ioi
    (fun n y _hy => hasDerivAt_su2ClassHeatKernelAreaJetTerm r y g h n)
    (fun n y hy =>
      norm_su2ClassHeatKernelAreaJetTerm_le_majorant (r + 1) hy g h n)
    htmem hsum0 htmem
  simpa [su2ClassHeatKernelAreaJet] using hseries

/-- On positive heat time, the ordinary derivative of each spectral jet is
the next jet. -/
theorem deriv_su2ClassHeatKernelAreaJet
    (r : Nat) {t : Real} (ht : 0 < t) (g h : SU2) :
    deriv (fun s : Real => su2ClassHeatKernelAreaJet r s g h) t =
      su2ClassHeatKernelAreaJet (r + 1) t g h :=
  (hasDerivAt_su2ClassHeatKernelAreaJet r ht g h).deriv

private theorem contDiffOn_su2ClassHeatKernelAreaJet_nat
    (m r : Nat) (g h : SU2) :
    ContDiffOn Real m (fun t : Real => su2ClassHeatKernelAreaJet r t g h)
      (Set.Ioi 0) := by
  induction m generalizing r with
  | zero =>
      rw [Nat.cast_zero, contDiffOn_zero]
      intro t ht
      exact (hasDerivAt_su2ClassHeatKernelAreaJet r ht g h).continuousAt.continuousWithinAt
  | succ m ihm =>
      rw [Nat.cast_succ, contDiffOn_succ_iff_deriv_of_isOpen isOpen_Ioi]
      refine ⟨?_, ?_, ?_⟩
      · intro t ht
        exact (hasDerivAt_su2ClassHeatKernelAreaJet r ht g h).differentiableAt.differentiableWithinAt
      · intro hmomega
        simp at hmomega
      · exact (ihm (r + 1)).congr fun t ht =>
          deriv_su2ClassHeatKernelAreaJet r ht g h

/-- Every spectral jet is infinitely continuously differentiable on the
positive-time half-line. -/
theorem contDiffOn_su2ClassHeatKernelAreaJet
    (r : Nat) (g h : SU2) :
    ContDiffOn Real ∞ (fun t : Real => su2ClassHeatKernelAreaJet r t g h)
      (Set.Ioi 0) := by
  exact contDiffOn_infty.2 fun m =>
    contDiffOn_su2ClassHeatKernelAreaJet_nat m r g h

theorem su2ClassHeatKernelAreaJet_zero
    (t : Real) (g h : SU2) :
    su2ClassHeatKernelAreaJet 0 t g h = su2ClassHeatKernel t g h := by
  unfold su2ClassHeatKernelAreaJet su2ClassHeatKernel
  apply tsum_congr
  intro n
  simp [su2ClassHeatKernelAreaJetTerm, su2ClassHeatKernelTerm,
    su2ClassHeatWeight, su2CasimirEigenvalue]

/-- The first spectral jet is exactly the separately exposed
Casimir-weighted area derivative. -/
theorem su2ClassHeatKernelAreaDerivative_eq_jet_one
    (t : Real) (g h : SU2) :
    su2ClassHeatKernelAreaDerivative t g h =
      su2ClassHeatKernelAreaJet 1 t g h := by
  unfold su2ClassHeatKernelAreaDerivative su2ClassHeatKernelAreaJet
  apply tsum_congr
  intro n
  simp only [su2ClassHeatKernelAreaDerivativeTerm,
    su2ClassHeatKernelAreaJetTerm, pow_one, Complex.ofReal_mul,
    Complex.ofReal_neg]
  ring

/-- Differentiated two-face Migdal merge.  The left side is the actual Haar
integral of the two infinite class heat kernels; varying either incident area
produces the Casimir-weighted derivative at the merged total area. -/
theorem hasDerivAt_integral_su2TwoFaceClassDensity_left
    {s t : Real} (hs : 0 < s) (ht : 0 < t) (g k : SU2) :
    HasDerivAt
      (fun u : Real =>
        ∫ h : SU2, su2TwoFaceClassDensity u t g k h ∂su2HaarProb)
      (su2ClassHeatKernelAreaJet 1 (s + t) g k) s := by
  have hinner : HasDerivAt (fun u : Real => u + t) 1 s := by
    simpa using (hasDerivAt_id s).add_const t
  have hkernel : HasDerivAt
      (fun u : Real => su2ClassHeatKernel (u + t) g k)
      (su2ClassHeatKernelAreaDerivative (s + t) g k) s := by
    simpa [Function.comp_def] using
      (hasDerivAt_su2ClassHeatKernel_time (add_pos hs ht) g k).scomp s hinner
  have heq :
      (fun u : Real =>
        ∫ h : SU2, su2TwoFaceClassDensity u t g k h ∂su2HaarProb) =ᶠ[nhds s]
      (fun u : Real => su2ClassHeatKernel (u + t) g k) := by
    filter_upwards [isOpen_Ioi.mem_nhds hs] with u hu
    exact su2Migdal_twoFace_class_merge hu ht g k
  simpa [su2ClassHeatKernelAreaDerivative_eq_jet_one] using
    hkernel.congr_of_eventuallyEq heq

theorem hasDerivAt_integral_su2TwoFaceClassDensity_right
    {s t : Real} (hs : 0 < s) (ht : 0 < t) (g k : SU2) :
    HasDerivAt
      (fun u : Real =>
        ∫ h : SU2, su2TwoFaceClassDensity s u g k h ∂su2HaarProb)
      (su2ClassHeatKernelAreaJet 1 (s + t) g k) t := by
  have hinner : HasDerivAt (fun u : Real => s + u) 1 t := by
    simpa using (hasDerivAt_const t s).add (hasDerivAt_id t)
  have hkernel : HasDerivAt
      (fun u : Real => su2ClassHeatKernel (s + u) g k)
      (su2ClassHeatKernelAreaDerivative (s + t) g k) t := by
    simpa [Function.comp_def] using
      (hasDerivAt_su2ClassHeatKernel_time (add_pos hs ht) g k).scomp t hinner
  have heq :
      (fun u : Real =>
        ∫ h : SU2, su2TwoFaceClassDensity s u g k h ∂su2HaarProb) =ᶠ[nhds t]
      (fun u : Real => su2ClassHeatKernel (s + u) g k) := by
    filter_upwards [isOpen_Ioi.mem_nhds ht] with u hu
    exact su2Migdal_twoFace_class_merge hs hu g k
  simpa [su2ClassHeatKernelAreaDerivative_eq_jet_one] using
    hkernel.congr_of_eventuallyEq heq

/-- Infinitesimal area transfer across a merged internal edge is invisible:
the two-face amplitude is locally constant along `(s+u,t-u)`. -/
theorem hasDerivAt_integral_su2TwoFace_areaTransfer_zero
    {s t : Real} (hs : 0 < s) (ht : 0 < t) (g k : SU2) :
    HasDerivAt
      (fun u : Real =>
        ∫ h : SU2,
          su2TwoFaceClassDensity (s + u) (t - u) g k h ∂su2HaarProb)
      0 0 := by
  have hspos : ∀ᶠ u : Real in nhds 0, 0 < s + u := by
    exact continuousAt_const.eventually_lt (by fun_prop) (by simpa using hs)
  have htpos : ∀ᶠ u : Real in nhds 0, 0 < t - u := by
    exact continuousAt_const.eventually_lt (by fun_prop) (by simpa using ht)
  have hpos : ∀ᶠ u : Real in nhds 0, 0 < s + u ∧ 0 < t - u := hspos.and htpos
  have heq :
      (fun u : Real =>
        ∫ h : SU2,
          su2TwoFaceClassDensity (s + u) (t - u) g k h ∂su2HaarProb) =ᶠ[nhds 0]
      (fun _u : Real => su2ClassHeatKernel (s + t) g k) := by
    filter_upwards [hpos] with u hu
    simpa [add_assoc, add_sub_cancel_right] using
      su2Migdal_twoFace_class_merge hu.1 hu.2 g k
  exact (hasDerivAt_const (x := 0) (su2ClassHeatKernel (s + t) g k)).congr_of_eventuallyEq heq

/-- The exact normalized simple-loop amplitude satisfies the Casimir area ODE.
The left side is the genuine Haar integral against the infinite heat kernel. -/
theorem hasDerivAt_integral_su2NormalizedWilson_mul_heatKernel
    {t : Real} (ht : 0 < t) (n : Nat) :
    HasDerivAt
      (fun s : Real =>
        ∫ g : SU2,
          su2NormalizedWilsonCharacter n g *
            heatKernelCharacterSeries su2CharacterTable s g ∂su2HaarProb)
      ((-su2CasimirEigenvalue n *
        Real.exp (-t * su2CasimirEigenvalue n) : Real) : Complex) t := by
  let c : Real := su2CasimirEigenvalue n
  have hlinear : HasDerivAt (fun s : Real => -s * c) (-c) t := by
    convert (hasDerivAt_id t).neg.mul_const c using 1 <;> ring
  have hweightReal : HasDerivAt (fun s : Real => Real.exp (-s * c))
      (-c * Real.exp (-t * c)) t := by
    convert (Real.hasDerivAt_exp (-t * c)).comp t hlinear using 1 <;> ring
  have hweight : HasDerivAt
      (fun s : Real => ((Real.exp (-s * c) : Real) : Complex))
      ((-c * Real.exp (-t * c) : Real) : Complex) t :=
    hweightReal.ofReal_comp
  have heq :
      (fun s : Real =>
        ∫ g : SU2,
          su2NormalizedWilsonCharacter n g *
            heatKernelCharacterSeries su2CharacterTable s g ∂su2HaarProb) =ᶠ[nhds t]
      (fun s : Real => ((Real.exp (-s * c) : Real) : Complex)) := by
    filter_upwards [isOpen_Ioi.mem_nhds ht] with s hs
    simpa [c, su2CasimirEigenvalue] using su2_exact_simpleLoop_areaLaw hs n
  simpa [c, su2CasimirEigenvalue] using hweight.congr_of_eventuallyEq heq

/-- ODE form of the simple-loop area evolution. -/
theorem deriv_integral_su2NormalizedWilson_mul_heatKernel
    {t : Real} (ht : 0 < t) (n : Nat) :
    deriv (fun s : Real =>
      ∫ g : SU2,
        su2NormalizedWilsonCharacter n g *
          heatKernelCharacterSeries su2CharacterTable s g ∂su2HaarProb) t =
      -(su2CasimirEigenvalue n : Complex) *
        (∫ g : SU2,
          su2NormalizedWilsonCharacter n g *
            heatKernelCharacterSeries su2CharacterTable t g ∂su2HaarProb) := by
  rw [(hasDerivAt_integral_su2NormalizedWilson_mul_heatKernel ht n).deriv]
  rw [integral_su2NormalizedWilson_mul_heatKernel ht n]
  change
    ((-su2CasimirEigenvalue n * Real.exp (-t * su2CasimirEigenvalue n) : Real) : Complex) =
      -(su2CasimirEigenvalue n : Complex) *
        ((Real.exp (-t * su2CasimirEigenvalue n) : Real) : Complex)
  rw [Complex.ofReal_mul, Complex.ofReal_neg]

end Lean2dYangMills
