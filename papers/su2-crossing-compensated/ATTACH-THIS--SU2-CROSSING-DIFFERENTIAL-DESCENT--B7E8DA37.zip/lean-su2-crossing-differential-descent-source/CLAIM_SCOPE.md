# Claim scope

## Machine-checked in the new producer

- The full physical projection
  `((a2 * a4⁻¹, a4), (a1 * a3⁻¹, a3))` preserves four-fold normalized Haar
  measure and is an explicit gauge-fixing chart.
- Its reduced part `r(a) = (a2 * a4⁻¹, a1 * a3⁻¹)` pushes four-fold Haar
  exactly to two-fold Haar.
- Every strongly measurable reduced observable therefore satisfies the exact
  quotient formula `∫ F(r(a)) dμ⁴ = ∫ F(v) dμ²`.
- Two gauge-compensated physical flows on the original four edges intertwine
  exactly with right multiplication of the reduced coordinates.
- First and mixed derivatives of the physical crossing Wilson word descend to
  the two-coordinate generators, generically and for all three Pauli axes.
- The Pauli-summed mixed generator closes pointwise into the direct and reverse
  four-edge resolutions.
- Under the six explicit dominated-flow hypotheses of the two-coordinate Ward
  theorem, the integral identity transports back to the literal four-edge
  Haar chart.

## Deliberately not claimed

- No weak four-face heat-kernel integration-by-parts identity is proved.
- No alternating four-area derivative is identified with the Pauli mixed
  generator, at normalization `κ = 2` or otherwise.
- No arbitrary embedded cellulation or complete Makeenko--Migdal equation is
  formalized.
- No continuum Yang--Mills theorem is claimed.

This is a new sequel, not a replacement. It closes the Haar-measure and
differential interface between the literal four-edge crossing chart and the
earlier two-coordinate Ward theorem.
