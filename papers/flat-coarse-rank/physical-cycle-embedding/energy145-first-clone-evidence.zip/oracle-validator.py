
import sys,pathlib,json,re
NAMES=['cycleCoordinate_sum','physicalCycleLift_gradient_norm_sq','physicalCycleLift_total_energy','physicalCycleLift_fibre_coordinate','actualCycleFullObservation_lift_norm_sq']
PAT=r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)"
def verify(raw):
 hits=list(re.finditer(PAT,raw))
 if len(hits)!=5:raise ValueError('five actual oracle outputs required')
 rows=[]
 for hit,name in zip(hits,NAMES):
  nm,axes=hit.groups();axs=[s.strip() for s in (axes or '').split(',') if s.strip()]
  if nm!='YangMills.RG.'+name or len(axs)!=len(set(axs)) or not set(axs)<={'propext','Classical.choice','Quot.sound'}:raise ValueError('unexpected endpoint/dependency')
  rows.append({'name':nm,'axioms':axs})
 return rows
raw=pathlib.Path(sys.argv[1]).read_text();rows=verify(raw);hit=list(re.finditer(PAT,raw))[0]
mutations=[raw[:hit.start()]+raw[hit.end():],raw.replace(hit.group(1),'Wrong.Endpoint',1),raw[:hit.start()]+"'"+hit.group(1)+"' depends on axioms: [sorryAx]"+raw[hit.end():]]
rejected=0
for bad in mutations:
 if bad==raw:raise RuntimeError('mutation unchanged')
 try:verify(bad)
 except ValueError:rejected+=1
 else:raise RuntimeError('accepted mutated actual oracle')
if len(rows)!=5 or rejected!=3:raise RuntimeError('explicit oracle counters')
print(json.dumps({'status':'ORACLE_PASS','accepted':5,'actual_mutations_rejected':3,'rows':rows},sort_keys=True))
