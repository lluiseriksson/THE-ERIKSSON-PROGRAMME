"""Audit the one unresolved QM9-gap moment box using the shared normalization scale."""
from fractions import Fraction as F
from pathlib import Path
import csv,io,urllib.request,hashlib,json,zipfile
pin='631296b91a0b2de790de4f4b5cb563f223e2f66b'
with urllib.request.urlopen('https://raw.githubusercontent.com/webbtheosim/data-efficient-regression/'+pin+'/size/results.csv',timeout=40) as f: data=f.read()
assert hashlib.sha1(b'blob '+str(len(data)).encode()+bytes([0])+data).hexdigest()=='385bdf612e41170ca114514dbc51776a03d5d976'
h=F(1,200000);q=F(121897,133885);p=1-q
lo=[];hi=[];target=set()
for row in csv.reader(io.StringIO(data.decode('utf-8-sig'))):
    if row[:2]!=['qm9','gap']:continue
    if tuple(row[3:7]) not in [('al','none','sv','topk'),('sf','cluster','none','none')]:continue
    a,r,z=map(F,row[9:12])
    assert min(r,z)>h
    lo.append((r-h)/(z+h));hi.append((r+h)/(z-h))
    if row[2:8]==['500','al','none','sv','topk','7']:target.add((a,r,z))
(a,r,z),=target
slo,shi=max(lo),min(hi)
assert 0<slo<=shi
def margin_holds(amax,amin,rmin,rmax):
    # For every admissible scale, the raw threshold q*sigma^2/4 is interior.
    gap=rmin*rmin-q*shi*shi/4
    if gap<=0 or amin**2<=2*rmax*rmax/133885:return False
    delta=amax-q*slo/2
    return delta<0 or delta**2<p*gap
rmin=max(r-h,(z-h)*slo)
rmax=min(r+h,(z+h)*shi)
uniform=margin_holds(a+h,a-h,rmin,rmax)
# Choose one fixed pair of exact moments strictly interior to all relevant rounding boxes.
r0=max(r-h,(z-h)*shi)
r1=min(r+h,(z+h)*slo)
witness=None
if r0<r1:
    for div in [2,10,100,1000,10000,1000000]:
        rw=r1-(r1-r0)/div
        aw=a-h+2*h/div
        if margin_holds(aw,aw,rw,rw):
            assert (r-h)<rw<(r+h) and (z-h)<rw/shi<=rw/slo<(z+h) and a-h<aw<a+h
            witness={'mae':str(aw),'rmse':str(rw)}
            break
out=Path('/content/materials-last-cell.zip')
record=dict(source=pin,N=133885,T=121897,task='qm9-gap',seed=7,arm='active',budget=500,reported=[str(x) for x in (a,r,z)],rows=len(lo),scale_bound=[str(slo),str(shi)],uniform_ambiguity=uniform,rounded_ambiguity_witness=witness)
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as arc:arc.writestr('last-cell.json',json.dumps(record,sort_keys=True))
print('archive_sha256 '+hashlib.sha256(out.read_bytes()).hexdigest())
