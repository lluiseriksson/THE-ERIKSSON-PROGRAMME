"""Tighten the common target scale using all published evaluations on the same property."""
from fractions import Fraction as F
from pathlib import Path
import urllib.request,csv,io,json,zipfile,hashlib
pin='631296b91a0b2de790de4f4b5cb563f223e2f66b'
with urllib.request.urlopen('https://raw.githubusercontent.com/webbtheosim/data-efficient-regression/'+pin+'/size/results.csv',timeout=40) as f:data=f.read()
assert hashlib.sha1(b'blob '+str(len(data)).encode()+bytes([0])+data).hexdigest()=='385bdf612e41170ca114514dbc51776a03d5d976'
h=F(1,200000);q=F(121897,133885);p=1-q
lo=[];hi=[];picked=set()
for row in csv.reader(io.StringIO(data.decode('utf-8-sig'))):
    if row[:2]!=['qm9','gap']:continue
    for j in range(8,50,6):
        try:r,z=map(F,row[j+2:j+4])
        except ValueError:continue
        if r>h and z>h:
            lo.append((r-h)/(z+h));hi.append((r+h)/(z-h))
    if row[2:8]==['500','al','none','sv','topk','7']:
        picked.add(tuple(map(F,row[9:12])))
(a,r,z),=picked
slo,shi=max(lo),min(hi);assert 0<slo<=shi and z-h>F(1,2)
# At the boundary, A/sigma <= B(z)=sqrt(p*(z^2-q/4))+q/2.
# To certify a fail using all admissible rounding errors, put A/sigma on the low side.
lowa=(a-h)/shi
delta=lowa-q/2
fail=(delta>0 and delta**2>p*((z+h)**2-q/4))
# To certify two possible decisions with the SAME moments, uniformly over all true triples.
uppera=(a+h)/slo;delta2=uppera-q/2
interior=(delta2<0 or delta2**2<p*((z-h)**2-q/4))
lower_ok=(a-h)**2>F(2,133885)*(r+h)**2
uniform=lower_ok and interior
# Conversely fix a relative RMSE inside every admissible raw/relative interval, and a low
# raw MAE. For each possible true scale this gives one exact pair rounding to both entries.
zlo=max(z-h,(r-h)/slo)
zhi=min(z+h,(r+h)/shi)
witness=None
if zlo<zhi:
    for d in [10,1000,1000000]:
        zz=zhi-(zhi-zlo)/d
        aa=a-h+2*h/d
        dx=aa/slo-q/2
        if (dx<0 or dx**2<p*(zz**2-q/4)) and aa**2>F(2,133885)*(zz*shi)**2:
            witness={'mae':str(aa),'relative_rmse':str(zz)}
            break
assert not (fail and (uniform or witness))
out=Path('/content/materials-scale-boundary.zip')
record=dict(source=pin,task='qm9-gap',seed=7,arm='active',budget=500,N=133885,T=121897,scales_from=len(lo),scale_interval=[str(slo),str(shi)],guaranteed_fail=fail,uniform_ambiguity=uniform,rounded_witness=witness)
with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as arc:arc.writestr('scale-boundary.json',json.dumps(record))
print('archive_sha256 '+hashlib.sha256(out.read_bytes()).hexdigest())
