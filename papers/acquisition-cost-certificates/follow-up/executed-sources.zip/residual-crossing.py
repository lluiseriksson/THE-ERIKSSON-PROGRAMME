"""Two 100-row random-forest reconstructions on one previously unresolved common set."""
from pathlib import Path, PurePosixPath
import ast,csv,hashlib,io,json,platform,sys,zipfile,subprocess,urllib.request
from tempfile import TemporaryDirectory
pin='631296b91a0b2de790de4f4b5cb563f223e2f66b'
root=f'https://raw.githubusercontent.com/webbtheosim/data-efficient-regression/{pin}/size/'
def fetch(rel,blob):
    with urllib.request.urlopen(root+rel,timeout=60) as res:raw=res.read()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob
    return raw
with TemporaryDirectory() as libs:
    subprocess.run([sys.executable,'-m','pip','install','--quiet','--no-deps','--only-binary=:all:','--target',libs,'scikit-learn==1.7.0'],check=True)
    sys.path.insert(0,libs)
    import sklearn,numpy as np,scipy
    from scipy.stats import pearsonr,spearmanr
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.model_selection import GridSearchCV
    from sklearn.preprocessing import StandardScaler
    from sklearn.metrics import r2_score,mean_absolute_error,root_mean_squared_error
    assert sklearn.__version__=='1.7.0'
    src=fetch('evaluate.py','0312e559bbecc2410a970fbe4aa252063d5412e4').decode()
    tree=ast.parse(src)
    definitions=[n for n in tree.body if getattr(n,'name','') in ('RandomForest','evaluate_model')]
    assert len(definitions)==2
    # Use only the archived definitions of the RF and its evaluation function.
    exec(compile(ast.Module(body=definitions,type_ignores=[]),'upstream/evaluate.py','exec'),globals())
    arr=np.load(io.BytesIO(fetch('databases/mp21-e_form.npy','bf9d546728ba0b1b1ac4c839427b5b8e6403af75')),allow_pickle=False)
    X=StandardScaler().fit_transform(arr[:,:-1]);y=arr[:,-1]
    assert len(y)==145608
    arms={'cluster':'sf-cluster','active':'al-sv-topk'}
    excluded=set();train={}
    for n,blob in [(100,'2ba639f5bfe2600805b7a2ddc12afb50bfa430f6'),(500,'0ed48b57e290efb5ecdeb721a909d3a8b073159c'),(1000,'04c9510ef438a21c6e90198274f597af3bd436d3'),(5000,'96816539b76725025c319ed27d3cd79ecbfe9061')]:
        with zipfile.ZipFile(io.BytesIO(fetch(f'datasets/size_{n}.zip',blob))) as ar:
            for arm,tag in arms.items():
                names=[nm for nm in ar.namelist() if '__MACOSX' not in PurePosixPath(nm).parts and PurePosixPath(nm).name==f'mp21-e_form-{tag}-2.npy']
                assert len(names)==1
                ids=np.load(io.BytesIO(ar.read(names[0])),allow_pickle=False)
                assert ids.dtype.kind in 'iu' and ids.shape==(n,) and min(ids)>=0 and max(ids)<len(y)
                excluded.update(ids.tolist())
                if arm=="active" and n in (500,1000):train[str(n)]=ids
    mask=np.ones(len(y),dtype=bool);mask[list(excluded)]=False
    assert sum(mask)==133481
    published={}
    data=fetch('results.csv','385bdf612e41170ca114514dbc51776a03d5d976')
    for row in csv.reader(io.StringIO(data.decode('utf-8-sig'))):
        if row[:2]!=['mp21','e_form'] or row[2] not in ('500','1000') or row[7]!='2':continue
        for arm,config in [('cluster',['sf','cluster','none','none']),('active',['al','none','sv','topk'])]:
            if arm=='active' and row[3:7]==config:
                assert row[2] not in published or published[row[2]]==row[8:14]
                published[row[2]]=row[8:14]
    results={}
    for arm,idx in sorted(train.items(),key=lambda x:int(x[0])):
        np.random.seed(2)
        rf=RandomForest()
        rf.train(X[idx],y[idx])
        predicted=rf.predict(X)
        full=[f'{v:.5f}' for v in evaluate_model(rf,X,y)]
        err=predicted-y
        residual=io.BytesIO();np.save(residual,err,allow_pickle=False)
        results[arm]=dict(expected=published[arm],reproduced=full,all_six_match=(full==published[arm]),
                          own_fit_common_rmse_rel=float(np.sqrt(np.mean(err[mask]**2))/np.std(y)),
                          full_residual_npy_sha256=hashlib.sha256(residual.getvalue()).hexdigest(),
                          parameters={k:rf.model.get_params()[k] for k in ('max_depth','max_features','n_estimators')})
        Path('/content/residual-'+arm+'.npy').write_bytes(residual.getvalue())
        if results[arm]['all_six_match'] and results[arm]['own_fit_common_rmse_rel']<0.5:break
    record=dict(source=pin,property='mp21-e_form',seed=2,arm='active',budgets=[500,1000],N=len(y),common_rows=int(mask.sum()),python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sklearn=sklearn.__version__,results=results)
    out=Path('/content/materials-residual-crossing.zip')
    with zipfile.ZipFile(out,'x',zipfile.ZIP_DEFLATED) as z:
        z.writestr('probe.json',json.dumps(record,sort_keys=True))
        for arm in results:z.write('/content/residual-'+arm+'.npy','residual-'+arm+'.npy')
    print('archive_sha256 '+hashlib.sha256(out.read_bytes()).hexdigest())
