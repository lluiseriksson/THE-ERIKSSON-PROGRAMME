
import json, pathlib, re, sys
NAMES=['weights_admissible','energy_from_actual_weights','observedSq_eq_output',
       'normalized_mean_norm','orthogonal_mean_decomposition','kernel_square_identity',
       'kernel_coercive','witness_exact_values','witness_negative_defect',
       'fixed_penalty_coercivity_false']
PREFIX='YangMills.RG.MeanPenaltyCycleObstruction.'
PATTERN=r"'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)"
def verify(raw):
    hits=list(re.finditer(PATTERN,raw))
    if len(hits)!=10: raise ValueError('exactly ten oracle readouts required')
    rows=[]
    for hit,want in zip(hits,NAMES):
        name,axs=hit.groups()
        axes=[x.strip() for x in axs.split(',') if x.strip()]
        if name!=PREFIX+want: raise ValueError('wrong or repeated endpoint')
        if len(axes)!=len(set(axes)): raise ValueError('duplicate dependency')
        if not set(axes)<= {'propext','Classical.choice','Quot.sound'}:
            raise ValueError('unapproved dependency')
        rows.append(dict(name=name,axioms=axes))
    return rows
raw=pathlib.Path(sys.argv[1]).read_text()
rows=verify(raw)
hits=list(re.finditer(PATTERN,raw))
first=hits[0]
mutations=[raw[:first.start()]+raw[first.end():],
           raw.replace(first.group(1),'Wrong.Endpoint',1),
           raw[:first.start()]+"'"+first.group(1)+"' depends on axioms: [sorryAx]"+raw[first.end():]]
rejected=0
for bad in mutations:
    if bad==raw: raise RuntimeError('mutation did not modify real oracle')
    try: verify(bad)
    except ValueError: rejected+=1
    else: raise RuntimeError('real oracle mutation accepted')
if len(rows)!=10 or rejected!=3: raise RuntimeError('explicit counters failed')
print(json.dumps(dict(status='ORACLE_VALIDATOR_PASS',accepted=10,
                     real_mutations_rejected=3,optimized=not __debug__,rows=rows),sort_keys=True))
