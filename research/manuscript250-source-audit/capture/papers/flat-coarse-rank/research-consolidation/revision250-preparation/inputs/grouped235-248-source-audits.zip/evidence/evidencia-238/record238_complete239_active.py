from pathlib import Path
import json,hashlib,os,shutil,datetime
A=Path('D:/Datos/the-eriksson-programme/autonomia');E=A/'evidencia-238';D=Path('D:/Entregas/the-eriksson-programme/2026-11-10_internal-dimension238');T=Path('papers/flat-coarse-rank/research/internal-dimension238')
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 t=p.with_name(p.name+'.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(t,p)
v=load(E/'source-audit/verdict.json');h=load(E/'source-audit/hashes.json')
if sha(E/'source-audit/hashes.json')!='dbd80e12ddd157e04c4ca8ff5832f472c12dcdd143009a610ec3ed331541ae8d' or v['blocking_findings'] or v['verdict']!='accept_with_limits':raise ValueError('Audit238')
for group in ('captures','outputs'):
 for x in h[group]:
  if sha(Path(x['path']))!=x['sha256_raw'] or Path(x['path']).stat().st_size!=x['bytes']:raise ValueError('Original238audit')
src=Path('papers/flat-coarse-rank/research/2026-11-10_internal-dimension238.txt')
if sha(src)!=v['source_sha256_raw']:raise ValueError('Source238')
u={'unit':238,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'EQUALITY_G_EQUALS_VOLUME_REMOVED_SOURCE_AUDITED','objective':'Removeequalityg=nD withoutassumingnewpartition/gap structure','source_sha':v['source_commit'],'source_sha256_raw':v['source_sha256_raw'],'results':['Allintegerg>=n²,alln>=2,D>=3: explicitcanonicalrectangles have actualrestrictedrankTheta_D(g nD-2).','SameexplicitmapnormalizedpenaltyTheta_D(cn²); fullbudgetO_D(V+g), retainingallstrongmultiplicities.'],'hypotheses_eliminated':['Exactequalityg=V=nD; replacedbyprovedlargerrangeallintegerg>=n². Growth/fixedbasis/exactprofilehypothesesremain.'],'tests':['SeparatefullinvolvedAI exactsourceaudit withallrawcaptures/hashchecked; no scientific/formalexecution.'],'refutations':[],'limits':v['limits'],'source_audit':v,'grade':None,'not_in_frozen232B':True,'new_small_paper':False,'next_action':'Keep238groupedwith235-237, sourcebranchstackedonPR210. Single bounded239 asks matchingcanonicalrankforallintegerg>=1; prioritize nativecatalogueconcurrencyfix/testing/deployment and232Bpublication.'}
for root in (D,T):
 root.mkdir(parents=True,exist_ok=True);shutil.copytree(E/'source-audit',root/'source-audit',dirs_exist_ok=True);shutil.copyfile(src,root/'internal-dimension238.txt')
(T/'.gitattributes').write_text('* -text\n',encoding='utf-8')
for root in (E,D,T):put(root/'result238-verified.json',u)
put(T/'MANIFEST.json',{'source_sha':u['source_sha'],'files':[{'file':p.relative_to(T).as_posix(),'bytes':p.stat().st_size,'sha256_raw':sha(p)} for p in sorted(T.rglob('*')) if p.is_file() and p.name!='MANIFEST.json']})
F=A/'evidencia-239';F.mkdir(exist_ok=True);q={'unit':239,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'statement':'For allintegerg>=1 on SAMEpositiveprofileH=cn², can canonicalcomponent-adaptedrectangles achieve actualrankTheta_D(V+g V/n²), removingg>=n²?','status':'Candidate mechanism only; no frozencompleteproof/audit. No preregisteredexecutionclaim.','hypotheses':'D>=3,n>=2,g>=1,actualU0^g, fixeduniformweakbasis andcanonicalrowweights; finitepenaltyallowed, no newfixed-gphysicalclaim.','mechanism':'Forg<n² aggregatehighspatialfrequencybandsintooneorthogonaltailI-P_j ratherthanpayceilperfineband; assignonefinestchannel tothattail, disjointcoarsegroups. Lowercombinesweak-subspaceinjectionrank>=d0 withgeneral-gtracekernelbound>=constgV/n². Smallboundedg canusefullsingletonfallback withD-onlythreshold.','falsifier':'Tailvariancebounduseswrongparent; groupsceilingoverbookg; regroupingchargesonechannelenergytwice; fixedgconstantshidden; noactualranklowerforthechosenclass.','abandonment':'Preserveallfailure; do not claim sharpnewpenaltybeforeproof; changeafter3unitswithoutsubstantiveprogress.','source_sha':None,'source_audit':None,'grade':None,'not_in_frozen232B':True}
put(F/'question239.json',q);s=load(A/'estado.json');s['unit238_complete']=u;s['unit238_in_progress']=u;s['latest_completed_unit']=238;s['unit239_in_progress']=q;s['active_question']=q;s['next_action']=u['next_action'];cp=A/'2026-11-10_checkpoint-238-internal-equality-eliminated.json';put(cp,{'unit238':u,'unit239':q,'native226C':s['publication226C_verified'],'232package':s['unit232_in_progress']['assessed_reproducible_package'],'catalogue_rejection':s['catalogue226C_new_helper_rejection'],'next_action':s['next_action']})
for k in ('checkpoint','last_checkpoint','latest_checkpoint'):s[k]=str(cp)
put(A/'estado.json',s);shutil.copyfile(__file__,E/'record238_complete239_active.py');print('238newg-rangeverified; originalhyp equalityremoved; no grade; oneactive239; publicationrepairremainspriority.')
