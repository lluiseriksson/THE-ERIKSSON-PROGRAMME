from pathlib import Path
import hashlib,json,zipfile,datetime,shutil
P=Path(__file__).resolve().parents[1]
E=Path(r'D:\Datos\the-eriksson-programme\autonomia\evidencia-242')
D=Path(r'D:\Entregas\the-eriksson-programme\2026-11-11_upper-delocalization242');D.mkdir(exist_ok=True)
old=Path(r'D:\Entregas\the-eriksson-programme\2026-11-11_balanced-polarization241\local-rectangles235-241-source-package.zip')
raw=old.read_bytes()
if hashlib.sha256(raw).hexdigest()!='dfb461a6ad98a194c1e08c7aa6f6e9527258b1aacaf63ed73e675c82eb7f1ab7':raise ValueError('Earlier archive changed')
files={'inputs/local-rectangles235-241-source-package.zip':raw}
root=P/'papers/flat-coarse-rank/research/upper-delocalization242'
for p in sorted(root.rglob('*')):
 if p.is_file():files['research/upper-delocalization242/'+p.relative_to(root).as_posix()]=p.read_bytes()
files['research/2026-11-11_upper-delocalization242.txt']=(root.parent/'2026-11-11_upper-delocalization242.txt').read_bytes()
files['README.txt']=('Grouped235-242 source-proof consolidation, not a new PDF or numerical assessment.\n'
 '242exactsourcee9210be23b4a6deba5ea7e09f749a7eb06857dd9 removes the positive coordinate minimum. Unitv with ONLYmaxv_alpha^2<=Lambda/g allowszeros. Sorted actualprefixes derive feasibility andcardinality from globallypaidbudget, without a replacementsubsetassumption.\n'
 'ActualcanonicalrankTheta_D,Lambda(V+gV/n^2); fixedmapleastnormalizedKTheta_D,Lambda(cmin(g,n^2)), explicitallfieldupper32cmin(g,n^2). CountingcoefficientVK.\n'
 'Separate fullanalyticalsourceauditacceptance withnonblocking N1empty-prefixwordingnote. Originalsource/fullreport and explicitbasecaseclarification retained. Not formal/numerical/independent/human verification; no priority/conditioning/application/physicalgap/continuumclaim.\n'
 'Inner235-241package includesallpriorproofinputs/rawrejections, including241Awrongcap. Allinnerlicenses/notices retained, no newblanketlicense.\n'
 'Frozen232B30-page PDF excludes234-242; its4.10grade is not a score for this source package. New243question/proof notincluded.\n').encode()
m={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha':'e9210be23b4a6deba5ea7e09f749a7eb06857dd9',
 'files':[{'path':n,'bytes':len(r),'sha256':hashlib.sha256(r).hexdigest()} for n,r in sorted(files.items())]}
zpath=D/'local-rectangles235-242-source-package.zip'
with zipfile.ZipFile(zpath,'x',compression=zipfile.ZIP_STORED) as z:
 for n,r in sorted(files.items()):z.writestr(n,r)
 z.writestr('MANIFEST.json',json.dumps(m,indent=2)+'\n')
with zipfile.ZipFile(zpath) as z:
 for x in m['files']:
  b=z.read(x['path'])
  if len(b)!=x['bytes'] or hashlib.sha256(b).hexdigest()!=x['sha256']:raise ValueError(x['path'])
out={'path':str(zpath),'bytes':zpath.stat().st_size,'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),
 'manifest_subjects_verified':len(m['files']),'scientific_execution':False,'PDF_grade':None,'scope':'Grouped235-242, no243, notfrozen232B'}
for root in(D,E):root.joinpath('grouped-source-package242-verified.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(__file__,E/'package_closed242.py');print(json.dumps(out))
