from pathlib import Path
import json,os,shutil,hashlib,zipfile
from datetime import datetime,timezone
a=Path('D:/Datos/the-eriksson-programme/autonomia');e=a/'evidencia-244'
now=datetime.now(timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,v):
 t=p.with_name(p.name+'.tmp244closed');b=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
 with t.open('wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 os.replace(t,p)
u=json.loads((e/'parent-verification244.json').read_text(encoding='utf-8'))
u.update(recorded_at=now,status='SOURCE_ACCEPTED_WITH_SCOPE',PR='https://github.com/lluiseriksson/THE-ERIKSSON-PROGRAMME/pull/213',PR_head='cefb5a9fc5812ace4985d769a64ba0fbe220b3f2',required_checks='PENDING; not merged')
d=Path('D:/Entregas/the-eriksson-programme/2026-11-11_uniform-weak-dimension244');d.mkdir(exist_ok=True)
z=d/'local-rectangles235-244-source-package.zip'
subjects={'prior/local-rectangles235-242-source-package.zip':Path('D:/Entregas/the-eriksson-programme/2026-11-11_upper-delocalization242/local-rectangles235-242-source-package.zip')}
for number in (243,244):
 root=a/('evidencia-'+str(number))
 for p in sorted((root/'source-audit').rglob('*')):
  if p.is_file():subjects[str(number)+'/source-audit/'+p.relative_to(root/'source-audit').as_posix()]=p
 for name in ('candidate'+str(number)+'.txt','parent-verification'+str(number)+'.json'):
  subjects[str(number)+'/'+name]=root/name
manifest={'scope':'Grouped source evidence235--244; no new PDF/model grade, formal verification or priority. Prior failures preserved in nested package.','source244':u,'files':[{'path':k,'bytes':p.stat().st_size,'sha256':sha(p)} for k,p in subjects.items()]}
if z.exists():raise ValueError('Do not overwrite completed package')
with zipfile.ZipFile(z,'w',compression=zipfile.ZIP_DEFLATED) as f:
 for k,p in subjects.items():f.write(p,k)
 f.writestr('manifest.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(z) as f:
 for row in manifest['files']:
  b=f.read(row['path'])
  if len(b)!=row['bytes'] or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('Package readback')
package={'path':str(z),'bytes':z.stat().st_size,'sha256':sha(z),'subjects_readback_verified':len(subjects)}
put(e/'grouped-package235-244.json',package)
s=json.loads((a/'estado.json').read_text(encoding='utf-8'))
s['unit244_completed']=u;s['grouped_package235_244']=package
s['programme_PR212_merged']={'sha':'45dca55be7224fb71d4c55f9e75712f7dc52fb0e','head':'7cad37b4d28766d4d692db0bcc114fd8a87b5abb','merged_at':'2026-11-11T00:54:41Z','required_checks':'both successful; full logs preserved; no formal claim for text proofs','logs':{n:sha(a/'evidencia-243'/n) for n in ('pr212-core-complete.log','pr212-honesty-complete.log')}}
s['active_question']={'id':245,'statement':'Does the rankOmega(V) lower persist when the positive weak projector is allowed to vary spatially, even with fixed g2,q1,Lambda2?','hypotheses':'Even n>=2,D>=3, a=c/(16D),H=cn^2; original basis/canonical rectangles/actual coexact domain retained; only constant P relaxed.','mechanism':'Checkerboard weak e1/e2 projectors. Two selected strong edge directions form2ncycles; point observations on one coordinate plane anchor them, Dirichlet gap gives restoring canonical map with O(n^(D-1)) rows.','falsifier':'Cycle or Dirichlet bound fails, observation partition is noncanonical, or kerC does not have strict Q>=c margin.','abandonment':'Three units without substantive progress then retain failures and change route or identify exact block.','status':'CANDIDATE_PROOF_TO_WRITE_AND_AUDIT','priority':'Public232B correctionC exactgate remains first.'}
s['next_action']='Read public232B correctionC exact74aae gate, then ownLinux actual normalization/controls/build/package and protected publication. Close bounded245 checkerboard counterexample under separate sourceaudit; PR213checks pending.'
cp=a/'2026-11-11_checkpoint-244-uniform-q-source-accepted.json'
put(cp,{'recorded_at':now,'objective':s['next_action'],'sha':u['source_sha'],'unit244':u,'results':[u['rank'],u['least_normalized_penalty']],'tests':['16 raw audit subjects verified; complete analytical report read; no mathematical executable/formal test'],'hypotheses_eliminated':[u['proved_hypothesis_removal']],'refutations':[],'artifacts':package,'blockers':['Public232B correctionC sourcegate pending; PR213 required checks pending'],'next_action':s['next_action'],'active_question':s['active_question'],'programme_PR212_merged':s['programme_PR212_merged'],'PR29':'20/41;TermSource=0','physical_mass_gap':'OPEN','continuum':'OPEN'})
for k in ('last_checkpoint','latest_checkpoint','checkpoint'):s[k]=str(cp)
put(a/'estado.json',s);shutil.copyfile(__file__,e/'record244_closed.py');print(json.dumps(package))
