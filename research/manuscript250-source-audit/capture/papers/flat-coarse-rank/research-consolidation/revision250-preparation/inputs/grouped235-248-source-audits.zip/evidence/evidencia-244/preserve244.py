from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parents[1];E=Path('D:/Datos/the-eriksson-programme/autonomia/evidencia-244')
R=E/'source-audit';T=P/'papers/flat-coarse-rank/research/uniform-weak-dimension244'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sha(R/'hashes.json')!='432424205841fbae5455fa4a790f21d55644585f532e33008f78eeeb27dd317b':raise ValueError('Audit identity')
m=json.loads((R/'hashes.json').read_text(encoding='utf-8'))
for x in m['files']:
 p=R/x['file']
 if sha(p)!=x['sha256'] or p.stat().st_size!=x['bytes']:raise ValueError(x['file'])
shutil.copytree(R,T/'source-audit',dirs_exist_ok=False)
T.joinpath('.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n')
shutil.copyfile(E/'candidate244.txt',T/'candidate244.txt')
shutil.copyfile(E/'primary-input-MSS244.json',T/'parent-primary-reading.json')
r={'unit':244,'source_sha':'98d1b4e230895bf03147a987d5db7545680f154a','source_sha256':sha(E/'candidate244.txt'),'verdict':'ACCEPT_UNIFORM_WEAK_DIMENSION_THEOREM_WITH_SCOPE','raw_audit_subjects_verified':len(m['files']),'full_report_read':True,'audit_manifest_sha256':sha(R/'hashes.json'),'proved_hypothesis_removal':'Rank exactly2 weak subspace extended to every1<=q<=g with constants independent ofq; actual Gram/count groups derived through classical MSS1.4, auxiliary signed count coordinate and proved recursive conditioning','rank':'Theta_(D,Lambda)(qV+gV/n^2)','least_normalized_penalty':'Theta_(D,Lambda)(cmin(g/q,n^2)); allfield upper32cmin(g/q,n^2)','retained_hypotheses':['Fixed upper coherence Paa<=Lambda q/g','Positive spatially constant a=c/(16D),H=cn^2','Fixed observed basis; canonical channel-separated integer rectangles','Actual finite flat coexact domain'],'formal_or_numerical_execution':False,'grade':None,'not_in_frozen232B':True,'priority':'UNESTABLISHED','independence_established':False,'classical_primary_input':'MSS1306.3969v4 Theorem1.4; published proof used, not re-proved'}
for root in(E,T):root.joinpath('parent-verification244.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(__file__,E/'preserve244.py');print('16 raw subjects verified; full uniform-q analytic audit preserved.')
