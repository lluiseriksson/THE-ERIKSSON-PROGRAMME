from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parents[1];E=Path(r'D:\Datos\the-eriksson-programme\autonomia\evidencia-243')
R=E/'source-audit';T=P/'papers/flat-coarse-rank/research/two-weak-directions243'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sha(R/'hashes.json')!='ff9a6468afbcb92e9b13317c51b78fe20aa9009bf9648f7d8590b57d2825974d':raise ValueError('Audit identity')
m=json.loads((R/'hashes.json').read_text(encoding='utf-8'))
for x in m['files']:
 p=R/x['file']
 if sha(p)!=x['sha256'] or p.stat().st_size!=x['bytes']:raise ValueError(x['file'])
shutil.copytree(R,T/'source-audit',dirs_exist_ok=False)
T.joinpath('.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n')
shutil.copyfile(E/'candidate243.txt',T/'candidate243.txt')
c=('Scope clarification C1: explicit singleton fallback(i) takes priority for ALL channels, including zero/discarded frame rows. Root assignment for zero/discarded/unused rows describes only angular branches(ii)/(iii). Original source and issued audit unchanged; allfield constant modes and fullrowcounts are included.\n')
for root in(E,T):root.joinpath('C1-singleton-priority.txt').write_text(c,encoding='utf-8',newline='\n')
r={'unit':243,'source_sha':'74dd6bb7938bf6a7522a84349b7a5d90fa907fc0',
 'source_sha256':'985dbb4412fa08863d1fbe68dfb883dc04511ea684e54a559c9e15a20c9e4459',
 'verdict':'ACCEPT_STATED_RANK_TWO_THEOREM_WITH_SCOPE','source_audit_manifest_sha256':sha(R/'hashes.json'),
 'raw_subjects_verified':len(m['files']),'full_report_read':True,
 'proved_extension':'One-dimensional weak subspace extended specifically to rank2; actualmatrixGramgroups derived from finiteangularbins/quantiles, notassumed.',
 'rank':'Theta_(D,Lambda)(V+gV/n^2)','least_normalized_penalty':'Theta_(D,Lambda)(cmin(g,n^2)); allfieldupper32cmin(g,n^2)',
 'retained_hypotheses':['rankEXACTLY2 weakorthoprojector','fixedP_aa<=2Lambda/g','positiveconstantprofilea=c/(16D),H=cn^2','fixedbasis and canonicalchannel-separated rows','actualfiniteflatcoexactdomain'],
 'scope_clarification':c.strip(),'constants':'Large explicitfixedK2048 andsizefallbacks; no practicalconditioning/efficientimplementation claimed.',
 'formal_or_numeric_execution':False,'grade':None,'not_in_frozen232B':True,'priority':'UNESTABLISHED'}
for root in(E,T):root.joinpath('parent-verification243.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
shutil.copyfile(__file__,E/'preserve243.py');print('Verified14 raw subjects and full rank2 source audit; scopeC1 preserved.')
