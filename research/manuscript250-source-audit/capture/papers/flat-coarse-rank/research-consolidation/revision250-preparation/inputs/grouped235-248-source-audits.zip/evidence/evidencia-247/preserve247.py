"""Prepared preservation/state handoff. NOT executed during authoring.
Default read-only; --apply-state requires the parent's exact current state hash.
Only copy/hash/JSON state bookkeeping, no science/Git/native/runtime operation.
"""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import re

A = Path('D:/Datos/the-eriksson-programme/autonomia')
E = A / 'evidencia-247'
R = E / 'source-audit'
PWT = Path('C:/Trabajo/the-eriksson-programme/perron-spec-210-20261108')
T = PWT / 'papers/flat-coarse-rank/research/point-anchors247'
REPORT = 'd620efd8c47cb4fecdb81fe1c951e60e329f3523a9902242015601b8ca47e9ab'
AUDIT_MANIFEST = 'b2ba345135c7f8d1e42573c2c075fa61f00bcca92922438de0159748c5d5de74'
VERIFICATION = '3fa7d2f23841c95d0e21a3c5b4039071e42fbda3d0b90ccece73e68afab00228'
PACKAGE = Path('D:/Entregas/the-eriksson-programme/2026-11-11_point-anchors247/local-rectangles235-247-source-audits.zip')
QUESTION248 = {
    'id': 248,
    'statement': 'For the EXACT D3 orthogonal checkerboard245, can distributed 2D point anchors give O(n log n) FULL canonical rows rather than the old O(n^2) plane count?',
    'hypotheses': 'Even n>=2,c>0,D3,g2,q1,Lambda2; same positive a=c/48,H=cn^2; original observed basis, actual source-weighted forward graph, per-channel integer rectangles and actual U0^2. Finite, not size-uniform, penalty allowed.',
    'mechanism': 'Derive finite 2D point-Poincare of order L^2(1+log L), verify the REAL paired-component graph/target norms and quantile mesh, and isolate actual original-coordinate anchors with linear rectangle count. No supplied graph/region gap.',
    'falsifier': 'Critical point cost requires worse than the claimed logarithm/count, or real strong-graph/source/target comparison or canonical original-rectangle realization fails.',
    'abandonment': 'After three bounded units without substantive advance, preserve every attempt/failure and change mechanism or identify a precise blocker.',
    'status': 'ACTIVE_STATEMENT_ONLY_NO_248_PROOF_SOURCE_OR_AUDIT_CLAIM',
    'priority': 'One bounded question; no separate small paper or score transfer. Parent-controlled live catalogue qualification remains separate.'
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def atomic_json(path, value):
    temporary = path.with_name(path.name + '.tmp247')
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with temporary.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    # Close before JSON validation/atomic replacement; never infer success from existence.
    require(temporary.read_bytes() == raw and json.loads(temporary.read_text(encoding='utf-8')) == value,
            'Closed temporary JSON validation failed')
    os.replace(temporary, path)
    require(path.read_bytes() == raw, 'Atomic JSON readback failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply-state', action='store_true')
    parser.add_argument('--expected-state-sha256')
    args = parser.parse_args()
    require(sha(R / 'fullreport.txt') == REPORT and sha(R / 'hashes.json') == AUDIT_MANIFEST,
            'Exact original247 audit binding')
    manifest = load(R / 'hashes.json')['files']
    require(len(manifest) == 18, 'Exactly18 audited subjects')
    for entry in manifest:
        for root in (R, T / 'source-audit'):
            file = root / entry['file']
            require(file.stat().st_size == entry['bytes'] and sha(file) == entry['sha256'], 'Raw audit subject mismatch')
    require(sha(T / 'source-audit/hashes.json') == AUDIT_MANIFEST, 'Copied audit manifest differs')
    require(sha(E / 'parent-verification247.json') == VERIFICATION
            and sha(T / 'parent-verification247.json') == VERIFICATION, 'Preservation verification binding')
    verified = load(E / 'parent-verification247.json')
    package = load(E / 'grouped-package235-247.json')
    require(package['path'] == str(PACKAGE) and package['sha256'] == sha(PACKAGE)
            and package['bytes'] == PACKAGE.stat().st_size, 'Actual preserved grouped package binding')
    plan = {'completed247': verified, 'active_question': QUESTION248,
            'PR214': {'head': '6a92bea5a0b6804cc459d404276afe262e9950a8',
                      'main_sha': '840ced72102bbe5c2db8998c34cc72017b93ea88',
                      'merged_at': '2026-11-11T02:00:54Z', 'required_checks': 'both actual SUCCESS; full core/honesty logs in evidencia-246'},
            'state_applied': False}
    if not args.apply_state:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
        return
    require(isinstance(args.expected_state_sha256, str)
            and re.fullmatch('[a-f0-9]{64}', args.expected_state_sha256), 'Parent exact current state hash required')
    state_path = A / 'estado.json'
    before = state_path.read_bytes()
    require(hashlib.sha256(before).hexdigest() == args.expected_state_sha256, 'State changed; no overwrite/retry')
    state = json.loads(before)
    require(state.get('active_question', {}).get('id') in (None, 247), 'Do not replace another active question')
    checkpoint = A / '2026-11-11_checkpoint-247-d4-point-anchors-accepted.json'
    backup = E / 'estado-before247.json'
    require(not checkpoint.exists() and not backup.exists(), 'Preserve prior application evidence; inspect instead of retry')
    with backup.open('xb') as stream:
        stream.write(before)
        stream.flush()
        os.fsync(stream.fileno())
    require(backup.read_bytes() == before, 'Exact old-state backup readback')
    state['unit247_completed'] = verified
    state['programme_PR214_merged'] = plan['PR214']  # Actual facts supplied by parent, not a new remote query.
    state['active_question'] = QUESTION248
    state['next_action'] = ('Preserve exact247 audit/source through ordinary source PR; one bounded248 statement only. '
                            'No248 source/proof yet. Cataloguev15 fullissuer qualification/protected route remains parent controlled; no standalone paper or regrade.')
    record = {'recorded_at': datetime.now(timezone.utc).isoformat(), 'objective': state['next_action'],
              'source_commit': verified['source_commit'], 'source_sha256': verified['source_sha256'],
              'results': [verified['result']], 'verification': ['Complete original audit report/verdict read;18 raw subjects hash-verified;copy/hash preservation only'],
              'limits': ['Exact D4 orthogonal checkerboard only; finite not uniform penalty; no optimal rank, all-angle/general projector/priority/formal/physical claim'],
              'package': package, 'PR214': plan['PR214'], 'active_question': QUESTION248,
              'grade': None, 'mathematical_execution': False,
              'publication_232B_context': 'Parent separately reports actual public/native closure; no fresh publication query by this script',
              'operational_limit': 'Checkpoint and state are separately atomic, not a multi-file transaction. No arbitrary concurrent writer protection; recheck and inspect partial failures.'}
    atomic_json(checkpoint, record)
    require(state_path.read_bytes() == before, 'State changed after backup/checkpoint; retain partial evidence for inspection')
    for key in ('last_checkpoint', 'latest_checkpoint', 'checkpoint'):
        state[key] = str(checkpoint)
    atomic_json(state_path, state)
    print('247 preservation recorded; single248 QUESTION ONLY. No proof, grade, science execution or physical claim.')


if __name__ == '__main__':
    main()
