from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parents[1]
E=Path(r'D:\Datos\the-eriksson-programme\autonomia\evidencia-241')
target=P/'papers/flat-coarse-rank/research/balanced-polarization241'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for folder,expected in [('source-audit','31199d7c4fc39679ef660d1b33fb5a525f80c5348313fc23e6e06b1af8f75a25'),
                        ('source-audit-b','177d42fb429e129cd93cd00b0ea20769f24600b7e09b57a3894f119e1bd9cd40')]:
    root=E/folder
    if sha(root/'hashes.json')!=expected:raise ValueError('Audit manifest changed')
    m=json.loads((root/'hashes.json').read_text(encoding='utf-8'))
    for item in m['files']:
        p=root/item['file']
        if p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256']:raise ValueError(item['file'])
    shutil.copytree(root,target/folder,dirs_exist_ok=False)
target.joinpath('.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n')
for name in ('candidate241A-rejected.txt','candidate241B.txt','limited-primary-comparison241.txt'):
    shutil.copyfile(E/name,target/name)
r={'unit':'241B','source_sha':'e40c0920f8aa7298aa95e03c3c8618f1ed0703a4',
 'source_sha256':'d62cae0af036aab0236bfa5ba47ccd1d59054f5cbda7a999ac4861bdd8c50d03',
 'source_audit_manifest_sha256':'177d42fb429e129cd93cd00b0ea20769f24600b7e09b57a3894f119e1bd9cd40',
 'verified_A_subjects':12,'verified_B_subjects':14,
 'original_A_verdict':'REJECT_UNCHANGED','B_verdict':'ACCEPT_EXACT_CORRECTED_SOURCE_WITH_STATED_SCOPE',
 'full_report_read':True,'original_failure':'Inherited cap alpha_D wrong; D4n2g2 uniform F337 vs claimed65537/256',
 'correction':'Original cap restored; Sections1-6 unchanged; all proof claims reread by separate auditor',
 'scope':'Unit balanced v withfixednu/g<=v_alpha^2<=Lambda/g, fixedbasis positiveconstantfamily actualflatcoexactdomain canonicalrectangleweights',
 'rank':'Theta_(D,nu,Lambda)(V+gV/n^2)',
 'least_normalized_penalty':'Theta_(D,nu,Lambda)(c min(g,n^2)); explicit32cmin(g,n^2) allfields',
 'proved_relaxation':'Exact uniform polarization unnecessary inside the stated balanced class; balance is not derived from general data.',
 'unbalanced_boundary':'v=e1 has rankd0 viaoneweak-singletonchannel+strongroots, so universal unbalanced gV/n^2 lower false',
 'novelty':'UNESTABLISHED; new2019operatoradapteddifferentialforms predecessor identified fromprimaryabstract; fullPDF notread inlaterlookup',
 'formal_or_numeric_execution':False,'new_PDF_or_grade':False,'not_in_frozen232B':True}
for root in (E,target):root.joinpath('parent-verification241B.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print('Both immutable audits and full sources preserved;26 raw subjects verified.')
