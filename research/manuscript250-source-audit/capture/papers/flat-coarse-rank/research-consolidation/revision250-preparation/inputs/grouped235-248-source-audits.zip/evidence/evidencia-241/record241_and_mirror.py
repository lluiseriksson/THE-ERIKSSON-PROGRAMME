from pathlib import Path
import datetime,json,os,hashlib,shutil
A=Path(r'D:\Datos\the-eriksson-programme\autonomia')
E=A/'evidencia-241';F=A/'evidencia-226';p=A/'estado.json'
def load(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def put(p,v):
 t=p.with_name(p.name+'.atomic.tmp')
 with t.open('w',encoding='utf-8',newline='\n') as h:
  json.dump(v,h,ensure_ascii=False,indent=2);h.write('\n');h.flush();os.fsync(h.fileno())
 os.replace(t,p)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
s=load(p);v=load(E/'parent-verification241B.json');mirror=load(F/'public-AIRR-post-aa3fac-verification226C.json')
if mirror['canonical_pdf_sha256']!='28cb2a7502e05cd8588aa6294f07a7eca5e0e452cce1bf5e4f09e9ec3c89e1a6' or not mirror['actual_release_timestamp_verified']:
 raise ValueError('Actual mirror gate failed')
mirror['deploy_run']='https://github.com/arr-research/arr-research.github.io/actions/runs/42923481148'
mirror['deployment_commit']='aa3fac26d52df621679fa0d8be71483afc3c82a1'
mirror['original_PDF_page_report_stars_timestamp_predicates']='UNCHANGED; now actual positive HTTP200 and exact bytes after previously failed deployments'
mirror['proof']=r'D:\Capturas\the-eriksson-programme\2026-11-10_contract226\public-v14-assessment-verified.png'
put(F/'public-AIRR-post-aa3fac-verification226C-consolidated.json',mirror)
unit={'unit':241,'variant':'B','recorded_at':now,'status':'SOURCE_AUDITED_WITH_SCOPE',
 'objective':'Remove exact-uniform polarization requirement while deriving canonical local observation groups and matching rank/penalty',
 'source_sha':v['source_sha'],'source_sha256':v['source_sha256'],
 'results':[v['rank'],v['least_normalized_penalty'],v['proved_relaxation'],v['unbalanced_boundary']],
 'tests':['Separate complete exact-source reread;14Brawsubjects and12originalArawsubjects verified; no mathematical executable/formal replay.'],
 'hypotheses_eliminated':[{'hypothesis':'Exact uniform v_alpha=1/sqrt(g)',
  'scope':'Replaced by explicit balanced unit-vector class, not arbitrary coefficients; actual grouping and coercivity proved, not assumed.',
  'witness':'Sections2-6 of exact241B; separate source auditacceptance'}],
 'retained_hypotheses':['fixednu>0 andLambda>=1 bounds on squared coordinates','positive constant rank-one weak coefficient family','fixedinternalbasis/canonicalchannel-separable rows','finite actualflatcoexactdomain'],
 'refutations':[s['unit241_original_rejection']],
 'source_audit':load(E/'source-audit-b/verdict.json'),'source_audit_manifest':v['source_audit_manifest_sha256'],
 'PR':{'number':212,'url':'https://github.com/lluiseriksson/THE-ERIKSSON-PROGRAMME/pull/212','head':'17159b12906fc88246b26ff932c8fa4ad3d6bd21','merged':False,'checks':'PENDING'},
 'new_PDF':False,'numerical_grade':None,'not_in_frozen232B':True,
 'novelty':'UNESTABLISHED; later primary differential-form predecessor comparison remainsOPEN',
 'next_action':'Group235-241; requiredCIbeforemerge; publication232Bpriority. One new bounded question242 asks whetherlowerbalance nu/g can be derived-away with actual sortedmass groups.'}
question={'unit':242,'recorded_at':now,
 'statement':'Can the same fixedcanonical local rank and penalty orders be proved for every unitv with ONLY v_alpha^2<=Lambda/g, allowingzero/arbitrarilytinycoordinates, without assuming nu/g?',
 'hypotheses':'D>=3,n>=2,g>=1,c>0,fixedLambda>=1; samea=c/(16D),H=cn^2,fixedbasispositivefamily andactualflatcoexactdomain. No unrestricted concentration claim.',
 'mechanism':'Order actual channel weights nonincreasingly; total feasibility overshoot leaves uniform positive residual mass; derive prefix-cardinality bounds from its average rather than positive minimum coordinate; pay all tail/root/rounding costs.',
 'falsifier':'Admissible upper-delocalized unitvector defeats group feasibility or economical rowcount, or forces unbounded penalty beyondmin(g,n^2); arbitrarye1outsidefixedLambda/g is not a falsifier.',
 'abandonment':'After3 substantive units without derived reduction/usefulcounterexample, preserve failures and changeroute or identifyconcreteblocker. No newpartition hypothesis may be assumed.',
 'status':'ACTIVE boundedquestion; no frozen auditedsource yet','source_sha':None,'grade':None,
 'publication_priority':'Actual232Bpublicpackage currently under separate technicalgate; no242scoretransfer.'}
put(E/'unit241B-source-qualified.json',unit)
(A/'evidencia-242').mkdir(exist_ok=True);put(A/'evidencia-242/question242.json',question)
s['unit241_completed']=unit;s['active_question']=question
s['native226C_AIRR_mirror_now_verified']=mirror;s['last_completed_unit']=241;s['updated_at']=now
s['next_action']='Complete exact232B publictechnicalsourcegate/ownColab nativevalidation/build then protectedPR/release/publicbytes/nativepublication; preserve genuine4.10major3OPEN. PR212awaitrequiredCI; one researchquestion242 lowerbalance removal. v14AIRRmirror now genuinelyverified, oldfailedattempts retained.'
cp=A/'2026-11-11_checkpoint-241B-and-public-v14-mirror.json'
put(cp,{'recorded_at':now,'objective':s['next_action'],'programme_main_sha':'0e22b7e9f5b7133336ef6e48d70c86964f3f151c',
 'airr_deployed_sha':'aa3fac26d52df621679fa0d8be71483afc3c82a1','unit241':unit,'active_question242':question,
 'native232B':load(A/'evidencia-232/native-intake232B-verified.json'),
 'actual232B_release_gates':load(A/'evidencia-232/native232B-release-gates-observed.json'),
 'v14publicmirror':mirror,'blockers':['232Bpublicpackage notyetqualified/released; technicalgate underway.3materialobjectionsOPEN, noacceptance.'],
 'PR29':'20/41;TermSource=0','physical_mass_gap':'OPEN','continuum':'OPEN'})
for k in ('last_checkpoint','latest_checkpoint','checkpoint'):s[k]=str(cp)
put(p,s);shutil.copyfile(__file__,E/'record241_and_mirror.py')
print(json.dumps({'closed_source_unit':241,'active_question':242,'v14_AIRR_mirror':'verified actual','v15':'notyetpublished','checkpoint':str(cp)}))
