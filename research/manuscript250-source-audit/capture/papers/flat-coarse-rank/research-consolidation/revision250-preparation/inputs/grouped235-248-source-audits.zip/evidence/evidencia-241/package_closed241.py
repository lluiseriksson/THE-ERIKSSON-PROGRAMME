from pathlib import Path
import hashlib,json,zipfile,datetime
P=Path(__file__).resolve().parents[1]
R=P/'papers/flat-coarse-rank/research'
E=Path(r'D:\Datos\the-eriksson-programme\autonomia\evidencia-241')
D=Path(r'D:\Entregas\the-eriksson-programme\2026-11-11_balanced-polarization241')
D.mkdir(exist_ok=True)
Z=D/'local-rectangles235-241-source-package.zip'
if Z.exists():raise ValueError('Never overwrite prior package')
files={}
old=Path(r'D:\Entregas\the-eriksson-programme\2026-11-10_rank-penalty237\local-rectangles235-237-proof-package.zip')
if hashlib.sha256(old.read_bytes()).hexdigest()!='5e815bd38c03343868bcf9d5c4956494db2582645985669dcbfbc62f438e8f64':
 raise ValueError('Original grouped input changed')
files['inputs/local-rectangles235-237-proof-package.zip']=old.read_bytes()
for folder in ('internal-dimension238','all-internal-dimensions239','all-dimension-penalty240','balanced-polarization241'):
 for p in sorted((R/folder).rglob('*')):
  if p.is_file():files['research/'+folder+'/'+p.relative_to(R/folder).as_posix()]=p.read_bytes()
for name in ('2026-11-10_internal-dimension238.txt','2026-11-10_all-internal-dimensions239.txt',
             '2026-11-11_all-dimension-penalty240.txt','2026-11-11_balanced-polarization241.txt',
             '2026-11-11_primary-comparison241.txt'):
 files['research/'+name]=(R/name).read_bytes()
files['LICENSE-REPOSITORY.txt']=(P/'LICENSE').read_bytes()
files['README.txt']=('Grouped235-241 analytical source package, not a new small paper or PDF assessment.\n'
 'Closed claims: actual canonical local rank Theta(V+gV/n^2) and least normalized penalty Theta(cmin(g,n^2)) for the specified positive weak-rank-one family;241B permits balanced unit polarizations with fixednu,Lambda.\n'
 'Corrected241Bsourcee40c0920f8aa7298aa95e03c3c8618f1ed0703a4; rawd62cae0af036aab0236bfa5ba47ccd1d59054f5cbda7a999ac4861bdd8c50d03. Separate role source acceptance is not formal/numerical/independent verification.\n'
 'Original236A normalization,240A case-coverage and241A capped-budget errors remain preserved with full rejection reports and counterexamples.\n'
 'Exact basis/class/canonical weights/positive finite coefficients/coexact domain/balance limits remain. Priority/usefulness/conditioning/generalcoefficients/physicalgap/continuum open.2019primarypredecessor needs full comparison; later abstract lookup does not establish novelty.\n'
 '242 candidate is excluded and still undergoing its own audit. Frozen30-page232B has none of234-241 and its4.10score cannot transfer to this package.\n'
 'No document/Lean/numerical test was run for241. Existing source/code licenses are retained; no blanket relicensing of thirdparty material or manuscript permission is implied.\n').encode()
manifest={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_sha':'e40c0920f8aa7298aa95e03c3c8618f1ed0703a4','files':[
 {'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()} for name,raw in sorted(files.items())]}
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_STORED) as z:
 for name,raw in sorted(files.items()):z.writestr(name,raw)
 z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(Z) as z:
 for spec in manifest['files']:
  raw=z.read(spec['path'])
  if len(raw)!=spec['bytes'] or hashlib.sha256(raw).hexdigest()!=spec['sha256']:raise ValueError(spec['path'])
result={'path':str(Z),'bytes':Z.stat().st_size,'sha256':hashlib.sha256(Z.read_bytes()).hexdigest(),
 'manifest_subjects_verified':len(manifest['files']),'scientific_execution':False,'PDF_grade':None,
 'scope':'Grouped235-241closedsourceproofs/fulladversehistory;242excluded;notfrozen232B.'}
for root in (D,E):root.joinpath('grouped-source-package241-verified.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result))
