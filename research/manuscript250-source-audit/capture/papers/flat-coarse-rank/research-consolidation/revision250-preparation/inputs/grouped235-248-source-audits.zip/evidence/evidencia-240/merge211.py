from pathlib import Path
import subprocess,json,os,shutil
P=Path(__file__).resolve().parents[1];E=Path('D:/Datos/the-eriksson-programme/autonomia/evidencia-240');R='lluiseriksson/THE-ERIKSSON-PROGRAMME';HEAD='ce2fbdc69b55ce86bd46186f2ffccb92e57e43ef'
def run(args,name):
 p=subprocess.run(args,cwd=P,capture_output=True);(E/(name+'.stdout')).write_bytes(p.stdout);(E/(name+'.stderr')).write_bytes(p.stderr);t=E/(name+'.exit.tmp');t.write_text(str(p.returncode)+'\n');os.replace(t,E/(name+'.exit'))
 if p.returncode:raise ValueError(name+' failed; originals retained')
 return p.stdout
v=json.loads(run(['gh','pr','view','211','--repo',R,'--json','state,headRefOid,statusCheckRollup,mergeStateStatus'],'pr211-final-checks'))
if v['headRefOid']!=HEAD or v['state']!='OPEN' or v['mergeStateStatus']!='CLEAN' or len(v['statusCheckRollup'])<2 or not all(x['status']=='COMPLETED' and x['conclusion']=='SUCCESS' for x in v['statusCheckRollup']):raise ValueError('Exact211 all-green up-to-date gate')
for rid in ('42921227457','42921227362'):run(['gh','run','view',rid,'--repo',R,'--log'],'pr211-run-'+rid+'-full-log')
run(['gh','pr','merge','211','--repo',R,'--merge','--match-head-commit',HEAD],'pr211-merge')
r=json.loads(run(['gh','pr','view','211','--repo',R,'--json','state,headRefOid,mergeCommit,mergedAt,url'],'pr211-merge-readback'))
if r['state']!='MERGED':raise ValueError('Actual merge missing')
(E/'pr211-merge.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
run(['git','-c','gc.auto=0','-c','http.lowSpeedLimit=1','-c','http.lowSpeedTime=45','fetch','origin','main'],'pr211-fetch-main');run(['git','-c','gc.auto=0','merge-base','--is-ancestor',HEAD,'origin/main'],'pr211-certified-head-ancestor')
shutil.copyfile(__file__,E/'merge211.py');print(json.dumps({'merged':r,'new_formal_theorem':False}))
