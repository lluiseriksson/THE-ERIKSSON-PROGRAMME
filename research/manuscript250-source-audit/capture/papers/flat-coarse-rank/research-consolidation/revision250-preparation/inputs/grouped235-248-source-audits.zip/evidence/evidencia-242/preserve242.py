from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parents[1]
E=Path(r'D:\Datos\the-eriksson-programme\autonomia\evidencia-242')
R=E/'source-audit';T=P/'papers/flat-coarse-rank/research/upper-delocalization242'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sha(R/'hashes.json')!='47b60b5d2a9735b495a229792a36f78df74283b320ca97b9679a1e82f0d4c78a':raise ValueError('Audit identity')
m=json.loads((R/'hashes.json').read_text(encoding='utf-8'))
for x in m['files']:
 p=R/x['file']
 if sha(p)!=x['sha256'] or p.stat().st_size!=x['bytes']:raise ValueError(x['file'])
shutil.copytree(R,T/'source-audit',dirs_exist_ok=False)
T.joinpath('.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n')
shutil.copyfile(E/'candidate242.txt',T/'candidate242.txt')
clarification=('Nonblocking N1 clarification; original source and issued audit unchanged.\n'
 'Before the first requested group, spent mass and the empty preceding budget are BOTH0.\n'
 'The base case is unusedmass1>the total upper budget<15/16. After at least one completed group, spentmass is STRICTLYbelow its preceding upper budget.\n'
 'This supplies the explicit base case used by the issued full analytical audit. No theorem/partition/rank/penalty change, new grade, scientific execution or independent verification is claimed. Future manuscript prose should state this base case explicitly.\n')
for root in(E,T):root.joinpath('N1-base-case-clarification.txt').write_text(clarification,encoding='utf-8',newline='\n')
r={'unit':242,'source_sha':'e9210be23b4a6deba5ea7e09f749a7eb06857dd9',
 'source_sha256':'1016e0c7edc1bbc131e9ff1d925969df1f0db8653fdca4bd08bd92158d1742fc',
 'verdict':'ACCEPT_WITH_NONBLOCKING_BASE_CASE_WORDING_NOTE','source_audit_manifest_sha256':sha(R/'hashes.json'),
 'raw_subjects_verified':len(m['files']),'full_report_read':True,
 'hypothesis_removed':'Positive minimum coordinate nu/g; zero coordinates nowallowed',
 'derived_mechanism':'Sorted actualweights + globallypaid budget<15/16 derive residual>1/16 and prefixcardinalityceil(16g lambda), not a newassumedsubsetmass',
 'retained_hypotheses':['unitv andfixedmaxv_alpha^2<=Lambda/g','positiveconstant rankoneweakfamily','fixedbasis/channelseparablecanonicalweights','finiteactualflatcoexactdomain'],
 'rank':'Theta_(D,Lambda)(V+gV/n^2)',
 'least_normalized_penalty':'Theta_(D,Lambda)(c min(g,n^2)); allfieldexplicitupper32cmin(g,n^2)',
 'nonblocking_note':'N1 initialemptyspentmass comparison equality; directbasecase supplied in fullaudit and companionclarification; originalsourceunchanged',
 'formal_numeric_execution':False,'grade':None,'not_in_frozen232B':True,'priority':'UNESTABLISHED'}
for root in(E,T):root.joinpath('parent-verification242.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print('Verified13 raw audit subjects; accepted source and full N1 preserved.')
