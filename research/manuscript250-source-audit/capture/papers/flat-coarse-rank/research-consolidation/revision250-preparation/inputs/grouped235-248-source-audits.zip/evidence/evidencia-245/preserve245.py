from pathlib import Path
import json,hashlib,shutil,os
from datetime import datetime,timezone
p=Path(__file__).resolve().parents[1];a=Path('D:/Datos/the-eriksson-programme/autonomia');e=a/'evidencia-245';r=e/'source-audit';t=p/'papers/flat-coarse-rank/research/checkerboard-projector245'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sha(r/'hashes.json')!='b61e2002afc710c36584b520e29f663b80a94601b1a1cb83b84ef7576d533a84':raise ValueError('Audit identity')
m=json.loads((r/'hashes.json').read_text(encoding='utf-8'))
for x in m['files']:
 f=r/x['file']
 if f.stat().st_size!=x['bytes'] or sha(f)!=x['sha256']:raise ValueError(x['file'])
shutil.copytree(r,t/'source-audit',dirs_exist_ok=False)
(t/'.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n')
for name in ('candidate245.txt','limited-primary-comparison245.txt'):shutil.copyfile(e/name,t/name)
v=json.loads((r/'verdict.json').read_text(encoding='utf-8'))
o={'recorded_at':datetime.now(timezone.utc).isoformat(),'source_sha':v['source_commit'],'source_sha256':v['source_sha256'],'verdict':v['verdict'],'complete_report_read':True,'raw_audit_subjects_verified':len(m['files']),'manifest_sha256':sha(r/'hashes.json'),'result':'Positive spatially varying coherent checkerboard admits canonical all-field finite-penalty restoration with actualrank<=2D(n^(D-1)+1)=o(V)','refuted_hypothesis':'Universal per-profile Omega(V) lower after dropping only spatialconstancy P, with arbitraryfinitepenalties','not_refuted':v['not_refuted'],'retained_hypotheses':'g2,q1,Lambda2; positive a=c/(16D),H=cn^2; originalfixedbasis/weights/channelrectangles/actualcoexactdomain; evenn>=2,D>=3','penalty':'FiniteexplicitK_n=M+2M^2/delta_n; no uniform/optimalpenaltyclaim','formal_execution':False,'grade':None,'priority':'UNESTABLISHED; limited primary1406.1752 introduction read only','independence_established':False}
for root in(e,t):(root/'parent-verification245.json').write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
def put(path,value):
 tmp=path.with_name(path.name+'.tmp245');b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
 with tmp.open('wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
s=json.loads((a/'estado.json').read_text(encoding='utf-8'));s['unit245_completed']=o
s['active_question']={'id':246,'statement':'Does the o(V) restoring-rank escape persist for ANY two distinct fixed weak lines at alternating parities, including arbitrarily small fixed angles, in the original observed basis?','hypotheses':'Fixedtheta in(0,pi/2], g2,q1,Lambda2; evenn,D>=3; samepositivea/H; canonicaloriginalchannelrectangle observations. No sizeuniformpenalty requirement.','mechanism':'Auxiliary invertible map of two strong normals, smallestGram eigenvalue kappa=1-|cos(theta)|; O_theta(1) observedcoordinateplanes give shorter anchoredcycles, then finitequadraticcompletion. Auxiliarymap is notanobservedrowrotation.','falsifier':'No uniformin n cycleDirichletbound after planeanchor mesh, or actual observation mixesinternalbasis/canonicalpartition fails.','abandonment':'Three units withoutsubstantiveadvance thenpreservefailures andchange route orname concreteblocker.','status':'PROOF_TO_WRITE_AND_AUDIT','priority':'Public232BPR419exactrequiredchecks/release/publicverification first.'}
s['next_action']='Public232BPR419protectedchecks exactdc8585, officialrelease/publicbytes/nativepublishedreadback; preserve245newbranch and PR213checks; bounded246smallangleescape next.'
cp=a/'2026-11-11_checkpoint-245-spatial-constancy-extension-refuted.json'
put(cp,{'recorded_at':o['recorded_at'],'objective':s['next_action'],'sha':o['source_sha'],'results':[o['result']],'tests':['Complete analytical sourceaudit and16rawsubjects checked; no mathematicalexecution/formaltest'],'hypotheses_eliminated':[],'refutations':[o['refuted_hypothesis']],'artifacts':[str(r),str(e/'parent-verification245.json')],'blockers':['Public419requiredchecks pending; not publicationyet'],'active_question':s['active_question'],'next_action':s['next_action'],'PR29':'20/41;TermSource=0','physical_mass_gap':'OPEN','continuum':'OPEN'})
for k in('last_checkpoint','latest_checkpoint','checkpoint'):s[k]=str(cp)
put(a/'estado.json',s);shutil.copyfile(__file__,e/'preserve245.py');print('245counterexampleacceptedwithlimits;16rawsubjectschecked; nextsinglequestion246.')
