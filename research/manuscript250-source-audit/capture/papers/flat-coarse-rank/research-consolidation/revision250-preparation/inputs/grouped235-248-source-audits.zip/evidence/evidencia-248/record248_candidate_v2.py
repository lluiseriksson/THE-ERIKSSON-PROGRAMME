from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil
a=Path('D:/Datos/the-eriksson-programme/autonomia'); e=a/'evidencia-248'
p=a/'estado.json'; before=p.read_bytes(); s=json.loads(before)
if s.get('active_question',{}).get('id')!=248: raise ValueError('Another question active')
source=e/'candidate248.txt'
if hashlib.sha256(source.read_bytes()).hexdigest()!='93786fa89262fd20d21596f1fdde5799f67518a93d1ab4446a06f9e98638b675': raise ValueError('Source differs')
s['active_question'].update(status='EXACT_SOURCE_DIFFERENT_ROLE_AUDIT_PENDING',source_sha='457d356199e5d1fe99ebc24eb8964a0793cf9738',source_sha256='93786fa89262fd20d21596f1fdde5799f67518a93d1ab4446a06f9e98638b675',artifact=str(source))
s['programme_PR215']={'url':'https://github.com/lluiseriksson/THE-ERIKSSON-PROGRAMME/pull/215','head':'a6a45036a2d556c27f991d0c230495b8c11ad4e1','state':'OPEN_REQUIRED_CORE_CHECK_PENDING','source_audit247':'ACCEPT; complete report read and 18 raw subjects verified','not_new_formal_theorem':True}
s['catalogue_v15_v2_actual_run']={'source':'36e6c804fac9bc3c6891ff64047ab94ede9b4ce3','archive_sha256':'45cb7c04bb7b307a27e752cd4c7c8e623b4ef7502f129ce26656216be8182543','archive_bytes':67159,'payloads_verified':34,'inventory_members':35,'bootstrap_actual_zero_children':9,'compact_actual_zero_children':4,'historical_each_mode':35,'programme_each_mode':107,'compact_new_each_mode':13,'compact_protocol_each_mode':2,'all_full_child_logs_read_by_parent':True,'actual_exit_files_read':18,'skips':0,'source42_and_compact17_unchanged':True,'requested_at':'2026-11-11T02:06:23.5800029Z','runner_started_at':'2026-11-11T02:07:17.362420Z','runner_finished_at':'2026-11-11T02:13:44.864663Z','release_finished_at':'2026-11-11T02:13:48.7051530Z','request_to_release_seconds':445.1251501,'billing_units':None,'billing_seconds':None,'backend_separate_actual_exit':0,'backend_literal':'[colab] No active sessions found on server.','returned_role_gate':'PENDING','native_apply':False,'V1_nonatomic_history_retained':True}
next_action='Read complete returned gate then protected421 merge/exact helper download and host readonly/global-zero-unused/apply/readback/backup/offsite. Complete exact248 source audit. PR215 core CI pending; no PDF rescore or duplicate deposit.'
s['next_action']=next_action
cp=a/'2026-11-11_checkpoint-248-candidate-and232-v2-observed.json'
record={'recorded_at':datetime.now(timezone.utc).isoformat(),'objective':next_action,'sha':s['active_question']['source_sha'],'results':['247 analytical result preserved in PR215; 248 is a new UNACCEPTED author candidate','V2 actual compact and full issuer suites passed; runtime released and backend separately inactive'],'tests':s['catalogue_v15_v2_actual_run'],'hypotheses_eliminated':[],'refutations':['V1 atomic-compliance not claimed; original direct-sentinel evidence retained'],'artifacts':[str(source),str(a/'evidencia-232/catalogue-v15-full-followup-preparation/attempt-a')],'blockers':[],'pending':['Returned-role gate, protected421 merge, guarded live catalogue operation','248 analytical audit and PR215 core check'],'active_question':s['active_question'],'next_action':next_action,'PR29':'20/41;TermSource=0','physical_mass_gap':'OPEN','continuum':'OPEN'}
def put(path,value):
    tmp=path.with_name(path.name+'.tmp248candidate'); raw=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
    with tmp.open('xb') as f: f.write(raw);f.flush();os.fsync(f.fileno())
    if json.loads(tmp.read_bytes())!=value:raise ValueError('Closed JSON differs')
    os.replace(tmp,path)
    if path.read_bytes()!=raw:raise ValueError('JSON readback differs')
put(cp,record)
if p.read_bytes()!=before:raise ValueError('State changed; inspect partial checkpoint')
for k in ('last_checkpoint','latest_checkpoint','checkpoint'):s[k]=str(cp)
put(p,s);shutil.copyfile(__file__,e/'record248_candidate_v2.py')
print('Atomic state:248 exact-source audit pending; actual V2 raw passes and released backend recorded, live catalogue not yet applied.')
