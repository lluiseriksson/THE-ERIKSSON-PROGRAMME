import json, os, hashlib, shutil
from pathlib import Path
from datetime import datetime, timezone
a=Path('D:/Datos/the-eriksson-programme/autonomia')
e=a/'evidencia-244';e.mkdir(exist_ok=True)
p=a/'estado.json';s=json.loads(p.read_text(encoding='utf-8'))
now=datetime.now(timezone.utc).isoformat()
def put(p,v):
 t=p.with_name(p.name+'.tmp244'); data=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode()
 with t.open('wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
 os.replace(t,p)
source=e/'candidate244.txt'
unit=dict(recorded_at=now,source_sha='98d1b4e230895bf03147a987d5db7545680f154a',source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),status='DIFFERENT_ROLE_EXACT_SOURCE_AUDIT_PENDING',candidate_only=True,mechanism='Classical MSS1.4 plus auxiliary signed count coordinate, actual Gram/cardinality halving and proved recursive conditioning; finite spatial stopping',target='uniform q rank Theta(qV+gV/n^2), K Theta(cmin(g/q,n^2))',hypotheses='1<=q<=g; fixed Lambda upper coherence; actual flat coexact domain; positive constant a/H; canonical fixed-basis per-channel rectangle rows',falsifier='Failure of simultaneous count/Gram lemma, recursive conditioning, any boundary/counterexample or exact theorem input',abandonment='After three units without substantive progress, preserve failure and change route or identify concrete blocker',formal_execution=False,independence_established=False,score=None)
s['unit244_candidate']=unit
s['active_question']={'id':244,**unit}
s['public232B_technical_gate']={'source_sha':'8d8b3a79b8fc0adfe7b62426a25249e62b25493c','status':'CORRECTED_SOURCE_EXACT_AUDIT_PENDING','previous_source':'04eb3e26dbceaf4f1660e12802c2cfaf08b3df4d','previous_verdict':'REJECT_M1_PRESERVED','actual_leak_found':False,'tests_planned':{'methods':24,'positive':1,'negative':23,'modes':['normal','optimized']},'execution':False,'publication':False,'normalizer_not_yet_run':True,'next_action':'Read full new exact-source audit; only accepted source then push and ownColab actual validation, protected PR, officialrelease, public exactbytes and native mark-published'}
s['next_action']='Priority public232B exact8d8b technicalgate then ownLinux actual normalization/controls/build/package, protected release/public verification. Separately pending244 exactsource analyticalaudit. No PDF rescore.'
cp=a/'2026-11-11_checkpoint-244-source-and-public232B-correction-pending.json'
put(cp,{'recorded_at':now,'objective':s['next_action'],'unit244':unit,'public232B':s['public232B_technical_gate'],'hypotheses_eliminated_this_pending_candidate':[],'tests':[],'refutations':['Public04eb M1 REJECT preserved; no actual leaked payload detected'],'artifacts':[str(source),str(a/'evidencia-232/public-v15-preparation/correction-b/source-freeze8d8b.json')],'blockers':['Different-role exact-source technical gate still pending before publication runtime'],'next_action':s['next_action'],'PR29':'20/41;TermSource=0','physical_mass_gap':'OPEN','continuum':'OPEN'})
for k in ('last_checkpoint','latest_checkpoint','checkpoint'):s[k]=str(cp)
put(p,s);shutil.copyfile(__file__,e/'record244_pending.py')
print('244 candidate preserved; both exact source gates pending; no execution/publication falsely recorded.')
