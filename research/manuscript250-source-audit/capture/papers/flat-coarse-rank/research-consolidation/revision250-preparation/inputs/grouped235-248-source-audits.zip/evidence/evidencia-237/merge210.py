from pathlib import Path
import subprocess,json,os,shutil
P=Path(__file__).resolve().parents[1];E=Path('D:/Datos/the-eriksson-programme/autonomia/evidencia-237');R='lluiseriksson/THE-ERIKSSON-PROGRAMME';HEAD='2bb4f7ca7fd400d5286d9680e39a74bebd7d1a2d'
def run(args,name):
 p=subprocess.run(args,cwd=P,capture_output=True);(E/(name+'.stdout')).write_bytes(p.stdout);(E/(name+'.stderr')).write_bytes(p.stderr);t=E/(name+'.exit.tmp');t.write_text(str(p.returncode)+'\n');os.replace(t,E/(name+'.exit'))
 if p.returncode:raise ValueError(name+' failed; originals retained')
 return p.stdout
v=json.loads(run(['gh','pr','view','210','--repo',R,'--json','state,headRefOid,statusCheckRollup,mergeStateStatus'],'pr210-final-checks'))
if v['headRefOid']!=HEAD or v['state']!='OPEN' or v['mergeStateStatus']!='CLEAN' or len(v['statusCheckRollup'])<2 or not all(x['status']=='COMPLETED' and x['conclusion']=='SUCCESS' for x in v['statusCheckRollup']):raise ValueError('Exact210 all-green up-to-date gate')
for rid in ('42917038650','42917038649'):run(['gh','run','view',rid,'--repo',R,'--log'],'pr210-run-'+rid+'-full-log')
run(['gh','pr','merge','210','--repo',R,'--merge','--match-head-commit',HEAD],'pr210-merge')
r=json.loads(run(['gh','pr','view','210','--repo',R,'--json','state,headRefOid,mergeCommit,mergedAt,url'],'pr210-merge-readback'))
if r['state']!='MERGED':raise ValueError('Actual merge missing')
(E/'pr210-merge.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
run(['git','-c','gc.auto=0','-c','http.lowSpeedLimit=1','-c','http.lowSpeedTime=45','fetch','origin','main'],'pr210-fetch-main');run(['git','-c','gc.auto=0','merge-base','--is-ancestor',HEAD,'origin/main'],'pr210-certified-head-ancestor')
shutil.copyfile(__file__,E/'merge210.py');print(json.dumps({'merged':r,'new_formal_theorem':False}))
