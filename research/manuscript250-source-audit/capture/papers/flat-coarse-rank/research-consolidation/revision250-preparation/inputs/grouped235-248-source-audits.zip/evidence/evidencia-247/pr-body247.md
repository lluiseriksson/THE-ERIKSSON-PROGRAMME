The exact orthogonal checkerboard in four dimensions admits finite-penalty restoration with at most `2^25 n^2` full canonical rows, improving the previous `O(n^3)` plane construction. A finite point-Poincare estimate on the actual three-dimensional strong components supplies the gap; isolating the anchors uses original-coordinate, per-channel rectangle partitions.

The complete different-role analytical audit binds source `4d120ad03bd6dc9a5828e780bb2873eaf144a9c5`, raw SHA256 `e2ab6a1db6816693617c7e214b98281610b23755a66c4d2f088c12eb0ed17e03`. All 18 audit subjects and original raw captures are retained. The parent read the full report and verified the hashes. Earlier 245/246 sources remain unchanged.

This is an upper bound for this exact D=4 family, with a finite penalty that may grow with size. Optimal rank, all-angle extensions and historical originality remain unestablished. The analytical review is involved AI work within a shared account/provider, without demonstrated independence or human peer review. No new Lean theorem, numerical execution, PDF assessment, physical mass gap or continuum result is claimed. These related results are retained for one future consolidation, not a separate small paper.

Validation: separate exact-source analytical audit accepted; required protected CI remains required before merge. PR29 remains 20/41 with TermSource=0.
