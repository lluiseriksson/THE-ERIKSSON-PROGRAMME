"""Prepared preservation bookkeeping ONLY; not run during source preparation.
Default read-only. Explicit --apply-state requires parent's exact current hash.
"""
from pathlib import Path
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
import re

A = Path('D:/Datos/the-eriksson-programme/autonomia')
E = A / 'evidencia-248'
R = E / 'source-audit'
T = Path('C:/Trabajo/the-eriksson-programme/perron-spec-210-20261108/papers/flat-coarse-rank/research/critical-point-anchors248')
REPORT = 'a6faea7524e92b500f591cb755aac97805bc88bfc62d1b943764bc12decade89'
MANIFEST = 'aa1e446dfa74e56fb40d34af3c4aceec313a5b95a28e9b0d1a03a0979882f144'
VERIFICATION = '0288e423afcfb08330c9a39dd95c747250609e5faa1a073f39a82c880c5876df'
PACKAGE = Path('D:/Entregas/the-eriksson-programme/2026-11-11_critical-point-anchors248/local-rectangles235-248-source-audits.zip')
QUESTION249 = {
    'id': 249,
    'statement': 'For exact D3/D4 TWO-DISTINCT-LINE checkerboard at every fixed nonzero angle theta, can original-basis canonical fullrows be O_theta(n(1+ln n))/O_theta(n^2), respectively, with finite K?',
    'hypotheses': 'Even n>=2,c>0,D3 or D4,g2,q1,Lambda2; a=c/(16D),H=cn^2; alternating fixed weak lines with principal angle theta in (0,pi/2], fixed independently of n. Original observed basis, actual positive source-weighted forward stack, canonical per-channel integer rectangles and same actual U0^2. No size-uniform penalty requirement.',
    'mechanism': 'Use the positive strong-normal Gram minimum kappa>0 with shared ORIGINAL point anchors in BOTH observed channels; derive the real paired-component point/graph gap and original canonical rectangle realization. Auxiliary proof coordinates are not mixed observed rows.',
    'falsifier': 'Proposed observations require noncanonical channel mixing, angle loss cannot be paid by the claimed fixed-theta row order/finite penalty, or the actual source/target strong graph conflicts with the proposed estimate.',
    'abandonment': 'After three bounded units without substantive advance, preserve all attempts/failures and change mechanism or identify a precise blocker.',
    'status': 'ACTIVE_STATEMENT_ONLY_NO_249_PROOF_SOURCE_OR_AUDIT_CLAIM',
    'priority': 'Single bounded question for future grouped consolidation; no new small paper or frozen232B/grade change. Parent-controlled offsitebackup0 remains pending.'
}


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def atomic_json(path, value):
    temporary = path.with_name(path.name + '.tmp248')
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with temporary.open('xb') as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    require(temporary.read_bytes() == raw and json.loads(temporary.read_text(encoding='utf-8')) == value,
            'Closed temporary JSON validation failed')
    os.replace(temporary, path)
    require(path.read_bytes() == raw, 'Atomic JSON readback failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--apply-state', action='store_true')
    parser.add_argument('--expected-state-sha256')
    args = parser.parse_args()
    require(sha(R / 'fullreport.txt') == REPORT and sha(R / 'hashes.json') == MANIFEST, 'Original248 audit identity')
    entries = load(R / 'hashes.json')['files']
    require(len(entries) == 19, 'Exactly19 raw audit subjects')
    for entry in entries:
        for root in (R, T / 'source-audit'):
            file = root / entry['file']
            require(file.stat().st_size == entry['bytes'] and sha(file) == entry['sha256'], 'Raw audit subject mismatch')
    require(sha(T / 'source-audit/hashes.json') == MANIFEST, 'Copied raw manifest differs')
    for root in (E, T):
        require(sha(root / 'parent-verification248.json') == VERIFICATION, 'Prepared verification binding')
    verified = load(E / 'parent-verification248.json')
    package = load(E / 'grouped-package235-248.json')
    require(package['path'] == str(PACKAGE) and package['sha256'] == sha(PACKAGE)
            and package['bytes'] == PACKAGE.stat().st_size, 'Actual grouped package binding')
    plan = {'completed248': verified, 'active_question': QUESTION249, 'state_applied': False,
            'native_context': 'Parent separately reports actual catalogue apply, readonly and noop0,93 preserved/globalunused0; no query here; offsitebackup0 pending'}
    if not args.apply_state:
        print(json.dumps(plan, ensure_ascii=False, indent=2))
        return
    require(isinstance(args.expected_state_sha256, str) and re.fullmatch('[a-f0-9]{64}', args.expected_state_sha256),
            'Parent exact current state hash required')
    path = A / 'estado.json'
    before = path.read_bytes()
    require(hashlib.sha256(before).hexdigest() == args.expected_state_sha256, 'State changed; refuse overwrite/retry')
    state = json.loads(before)
    require(state.get('active_question', {}).get('id') in (None, 248), 'Do not replace another active question')
    checkpoint = A / '2026-11-11_checkpoint-248-d3-critical-point-anchors-accepted.json'
    backup = E / 'estado-before248.json'
    require(not checkpoint.exists() and not backup.exists(), 'Preserve prior application evidence; inspect partial state')
    with backup.open('xb') as stream:
        stream.write(before)
        stream.flush()
        os.fsync(stream.fileno())
    require(backup.read_bytes() == before, 'Old state exactbackup readback')
    state['unit248_completed'] = verified
    state['active_question'] = QUESTION249
    state['next_action'] = ('Preserve248 exact source/audit through ordinary source PR; single249 STATEMENT ONLY until next explicit fabrication. '
                            'Group235-248 later; no new paper/PDF/rescore. Parent-controlled offsitebackup0 remains pending; no native action here.')
    record = {'recorded_at': datetime.now(timezone.utc).isoformat(), 'objective': state['next_action'],
              'source_commit': verified['source_commit'], 'source_sha256': verified['source_sha256'],
              'results': [verified['result']], 'verification': ['Complete original audit report/verdict read by parent and preservation role;19 rawsubjects exactsize/hash verified'],
              'limits': verified['not_claimed'], 'package': package, 'active_question': QUESTION249,
              'grade': None, 'mathematical_execution': False, 'native_context': plan['native_context'],
              'operational_limit': 'Checkpoint and state individually atomic, not a multi-file transaction or arbitrary concurrent writer exclusion. Preserve partial failures; no blind retry.'}
    atomic_json(checkpoint, record)
    require(path.read_bytes() == before, 'State changed after backup/checkpoint; inspect preserved partial evidence')
    for key in ('last_checkpoint', 'latest_checkpoint', 'checkpoint'):
        state[key] = str(checkpoint)
    atomic_json(path, state)
    print('248 preserved; single249 QUESTION ONLY. No proof, grade, science execution, native action or physical claim.')


if __name__ == '__main__':
    main()
