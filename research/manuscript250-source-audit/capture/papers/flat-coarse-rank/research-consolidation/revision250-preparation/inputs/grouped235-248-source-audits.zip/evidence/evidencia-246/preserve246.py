from pathlib import Path
import json,hashlib,shutil,os
from datetime import datetime,timezone
p=Path(__file__).resolve().parents[1];a=Path('D:/Datos/the-eriksson-programme/autonomia');e=a/'evidencia-246';r=e/'source-audit';t=p/'papers/flat-coarse-rank/research/small-angle-projector246'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sha(r/'hashes.json')!='fad05c9e5441ed5614419259e345d7ab8724ec1368636a7cfa1bd8d5d764cb4e':raise ValueError('Audit identity')
m=json.loads((r/'hashes.json').read_text(encoding='utf-8'))
for x in m['files']:
 f=r/x['file']
 if f.stat().st_size!=x['bytes'] or sha(f)!=x['sha256']:raise ValueError(x['file'])
shutil.copytree(r,t/'source-audit',dirs_exist_ok=False)
(t/'.gitattributes').write_text('* -text\n',encoding='utf-8',newline='\n');shutil.copyfile(e/'candidate246.txt',t/'candidate246.txt')
v=json.loads((r/'verdict.json').read_text(encoding='utf-8'))
o={'recorded_at':datetime.now(timezone.utc).isoformat(),'source_sha':v['source_commit'],'source_sha256':v['source_sha256'],'verdict':v['verdict'],'complete_report_read':True,'raw_audit_subjects_verified':len(m['files']),'manifest_sha256':sha(r/'hashes.json'),'result':'Any fixed nonzero weak-line angle admits original-basis canonical restoration with finiteK and rankO_D,theta(n^(D-1))=o(V)','proved_extension':'245orthogonal line alternation extended to arbitrary fixed theta>0 by actual plane-mesh anchor construction and paid kappa loss','retained_hypotheses':'Evenn; fixedtheta>0; sameg2q1Lambda2; originalpositivea/H; fixedobservedbasis/channelrectangles/actualcoexactdomain; no uniformpenalty requirement','no_theta_n_claim':True,'no_optimal_rank_claim':True,'formal_execution':False,'grade':None,'priority':'UNESTABLISHED','independence_established':False}
for root in(e,t):(root/'parent-verification246.json').write_text(json.dumps(o,indent=2)+'\n',encoding='utf-8')
def put(path,value):
 tmp=path.with_name(path.name+'.tmp246');b=(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode()
 with tmp.open('wb') as f:f.write(b);f.flush();os.fsync(f.fileno())
 os.replace(tmp,path)
s=json.loads((a/'estado.json').read_text(encoding='utf-8'));s['unit246_completed']=o
s['programme_PR213_merged']={'head':'cefb5a9fc5812ace4985d769a64ba0fbe220b3f2','main_sha':'f21b4f29f947cecbdbb7bdcc979b6153ab2bf791','merged_at':'2026-11-11T01:19:40Z','required_checks':'bothsuccess; fullcore/honestylogs in evidencia244; no formalclaimfornewtextproof'}
s['active_question']={'id':247,'statement':'In the explicit orthogonal checkerboard245 at D=4, can canonical all-field restoration be achieved with O(n^2) actual full rows instead of O(n^3), with finite penalties?','hypotheses':'Evenn>=2; g2q1Lambda2;a=c/(16D),H=cn^2; exact245sourceweightedfamily, originalbasis and actualcoexactdomain; finite notuniformpenalty.','mechanism':'Distributed point anchors on each three-dimensional strong component; derive finite point-Poincare/capacity bound, realize anchors as an actual O(numberpoints) rectanglepartition. No supplied graphgap/anchor hypothesis.','falsifier':'Criticalcapacity/logarithmicloss prevents n^2 count; incompatible actualstronggraph or canonical partition; lowertrace obstructs.','abandonment':'After3unitswithoutsubstantiveadvance preserveallattempts andchange route or identify preciseblocker.','status':'ACTIVE_STATEMENT_ONLY_NO_PROOF_CLAIM','priority':'Public232B realtimestamp/AIRRmirror/nativepublished; no more tiny standalone papers.'}
s['next_action']='PR420realrelease timestampprotectedchecks/main/Pages; exactAIRRPDF/fullreports/stars/date thenexistingguardednative markpublished+HTTPSreceipt. Preparecataloguev15exactguardedroute. PR214group245-246 requiredchecks next; one active247.'
cp=a/'2026-11-11_checkpoint-246-fixed-angle-counterexample-accepted.json'
put(cp,{'recorded_at':o['recorded_at'],'objective':s['next_action'],'sha':o['source_sha'],'results':[o['result']],'tests':['17rawauditfilesverified; fullanalyticalreportread; no mathematicalexecution/formaltest'],'hypotheses_eliminated':[o['proved_extension']],'refutations':[v['falsified_extension']],'artifacts':[str(r),str(e/'parent-verification246.json')],'blockers':['AIRRrealdatePR420protectedchecks pending; no mirror/nativepublicationclaim yet'],'active_question':s['active_question'],'next_action':s['next_action'],'PR29':'20/41;TermSource=0','physical_mass_gap':'OPEN','continuum':'OPEN'})
for k in('last_checkpoint','latest_checkpoint','checkpoint'):s[k]=str(cp)
put(a/'estado.json',s);shutil.copyfile(__file__,e/'preserve246.py');print('246fixedanglecounterexampleaccepted;17rawsubjectschecked; nextsinglequestion247.')
